import { logger } from "./logger";

const CIRCLE_BASE_URL = "https://api.circle.com/v1";

export function getCircleHeaders() {
  const key = process.env.CIRCLE_API_KEY;
  if (!key) {
    throw new Error("CIRCLE_API_KEY environment variable is not set");
  }
  return {
    "Authorization": `Bearer ${key}`,
    "Content-Type": "application/json",
    "Accept": "application/json",
  };
}

export async function circleGet<T>(path: string): Promise<T> {
  const url = `${CIRCLE_BASE_URL}${path}`;
  logger.debug({ path }, "Circle API GET");

  const res = await fetch(url, {
    method: "GET",
    headers: getCircleHeaders(),
  });

  if (!res.ok) {
    const body = await res.text();
    logger.error({ status: res.status, path, body }, "Circle API error");
    throw new CircleApiError(res.status, body);
  }

  const json = await res.json() as { data: T };
  return json.data;
}

export async function circlePost<T>(path: string, body: unknown): Promise<T> {
  const url = `${CIRCLE_BASE_URL}${path}`;
  logger.debug({ path }, "Circle API POST");

  const res = await fetch(url, {
    method: "POST",
    headers: getCircleHeaders(),
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const responseBody = await res.text();
    logger.error({ status: res.status, path, body: responseBody }, "Circle API error");
    throw new CircleApiError(res.status, responseBody);
  }

  const json = await res.json() as { data: T };
  return json.data;
}

export class CircleApiError extends Error {
  constructor(public status: number, public body: string) {
    super(`Circle API error ${status}: ${body}`);
    this.name = "CircleApiError";
  }
}

export function isCircleApiKeyConfigured(): boolean {
  return !!CIRCLE_API_KEY;
}
