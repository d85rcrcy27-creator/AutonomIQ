---
name: Dependency remediation
description: Compatibility rules for security upgrades in this workspace.
---

Prefer the first patched release that preserves the current API, and use narrowly scoped pnpm overrides for compatible transitive fixes. Keep code generators pinned when a newer generator changes generated output or assumes a different library major.

**Why:** Security upgrades can introduce unrelated generated-code or runtime API changes even when the vulnerability fix itself is small.

**How to apply:** Update direct parents when they provide the fix, pin transitive packages only within their supported major, and run code generation plus full typechecking before accepting the lockfile.