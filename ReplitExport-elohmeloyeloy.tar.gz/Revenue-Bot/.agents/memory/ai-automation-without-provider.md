---
name: AI-optional automation
description: How revenue automation should behave when an AI provider is unavailable or unaffordable.
---

Automation must remain usable without a provider key or provider credits: use AI opportunistically, then fall back to source-grounded server-generated drafts. The fallback must not claim customer approval, external work, payment, or revenue growth.

**Why:** The managed AI integration may be unavailable for the account tier, and direct provider credentials can be invalid or out of credits. Blocking discovery-to-checkout on either condition makes the product unusable.

**How to apply:** Keep provider calls optional in negotiation and execution, log provider failures, and preserve the guarded payment state machine. Only verified Stripe payment may mark a job paid or advance the next job.