import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, agentsTable, agentLogsTable } from "@workspace/db";
import {
  CreateAgentBody,
  UpdateAgentBody,
  GetAgentParams,
  UpdateAgentParams,
  DeleteAgentParams,
  ListAgentLogsParams,
  RunAgentParams,
  ListAgentsResponse,
  GetAgentResponse,
  CreateAgentResponse,
  UpdateAgentResponse,
  GetAgentStatsResponse,
  ListAgentLogsResponse,
} from "@workspace/api-zod";
import { getOpenAIClient } from "../../lib/openai";

const router: IRouter = Router();

router.get("/agents", async (req, res): Promise<void> => {
  const agents = await db.select().from(agentsTable).orderBy(desc(agentsTable.createdAt));
  res.json(ListAgentsResponse.parse(agents));
});

router.get("/agents/stats", async (req, res): Promise<void> => {
  const agents = await db.select().from(agentsTable);
  const stats = {
    totalAgents: agents.length,
    runningAgents: agents.filter((a) => a.status === "running").length,
    totalTasksCompleted: agents.reduce((sum, a) => sum + a.tasksCompleted, 0),
    totalRevenueGenerated: agents.reduce((sum, a) => sum + a.revenueGenerated, 0),
  };
  res.json(GetAgentStatsResponse.parse(stats));
});

router.post("/agents", async (req, res): Promise<void> => {
  const parsed = CreateAgentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [agent] = await db.insert(agentsTable).values(parsed.data).returning();
  res.status(201).json(CreateAgentResponse.parse(agent));
});

router.get("/agents/:id", async (req, res): Promise<void> => {
  const params = GetAgentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [agent] = await db.select().from(agentsTable).where(eq(agentsTable.id, params.data.id));
  if (!agent) {
    res.status(404).json({ error: "Agent not found" });
    return;
  }
  res.json(GetAgentResponse.parse(agent));
});

router.patch("/agents/:id", async (req, res): Promise<void> => {
  const params = UpdateAgentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateAgentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [agent] = await db.update(agentsTable).set(parsed.data).where(eq(agentsTable.id, params.data.id)).returning();
  if (!agent) {
    res.status(404).json({ error: "Agent not found" });
    return;
  }
  res.json(UpdateAgentResponse.parse(agent));
});

router.delete("/agents/:id", async (req, res): Promise<void> => {
  const params = DeleteAgentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [agent] = await db.delete(agentsTable).where(eq(agentsTable.id, params.data.id)).returning();
  if (!agent) {
    res.status(404).json({ error: "Agent not found" });
    return;
  }
  res.sendStatus(204);
});

router.get("/agents/:id/logs", async (req, res): Promise<void> => {
  const params = ListAgentLogsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const logs = await db
    .select()
    .from(agentLogsTable)
    .where(eq(agentLogsTable.agentId, params.data.id))
    .orderBy(desc(agentLogsTable.createdAt))
    .limit(100);
  res.json(ListAgentLogsResponse.parse(logs));
});

router.post("/agents/:id/run", async (req, res): Promise<void> => {
  const params = RunAgentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [agent] = await db.select().from(agentsTable).where(eq(agentsTable.id, params.data.id));
  if (!agent) {
    res.status(404).json({ error: "Agent not found" });
    return;
  }

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  // Mark agent as running
  await db.update(agentsTable).set({ status: "running", lastRunAt: new Date() }).where(eq(agentsTable.id, agent.id));

  const sendChunk = (content: string) => res.write(`data: ${JSON.stringify({ content })}\n\n`);

  try {
    const openai = getOpenAIClient();
    const agentPrompts: Record<string, string> = {
      finder: `You are a revenue opportunity finder AI agent named ${agent.name}. Analyze the current market and identify 3-5 specific revenue-generating opportunities. Be concrete, practical, and focus on autonomous execution. Format each opportunity clearly.`,
      coder: `You are a code generation AI agent named ${agent.name}. ${agent.description}. Generate a practical revenue-generating script or service. Include setup instructions and expected revenue potential.`,
      manager: `You are a revenue management AI agent named ${agent.name}. ${agent.description}. Review current operations, identify bottlenecks, and provide actionable recommendations to optimize revenue generation.`,
      analyst: `You are a revenue analytics AI agent named ${agent.name}. ${agent.description}. Perform a deep analysis of revenue patterns, growth opportunities, and risk factors. Provide data-driven recommendations.`,
    };

    const systemPrompt = agentPrompts[agent.type] ?? `You are an AI agent named ${agent.name}. ${agent.description}. Execute your assigned task and report results.`;

    const stream = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      max_completion_tokens: 1024,
      messages: [{ role: "user", content: systemPrompt }],
      stream: true,
    });

    let fullOutput = "";
    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content;
      if (content) {
        fullOutput += content;
        sendChunk(content);
      }
    }

    // Update agent stats and store log
    await db.update(agentsTable).set({
      status: "idle",
      tasksCompleted: agent.tasksCompleted + 1,
    }).where(eq(agentsTable.id, agent.id));

    await db.insert(agentLogsTable).values({
      agentId: agent.id,
      message: `Run completed. Output: ${fullOutput.slice(0, 200)}...`,
      level: "success",
    });

  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    sendChunk(`\n\n[ERROR] ${msg}`);
    await db.update(agentsTable).set({ status: "error" }).where(eq(agentsTable.id, agent.id));
    await db.insert(agentLogsTable).values({ agentId: agent.id, message: `Run failed: ${msg}`, level: "error" });
  }

  res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
  res.end();
});

export default router;
