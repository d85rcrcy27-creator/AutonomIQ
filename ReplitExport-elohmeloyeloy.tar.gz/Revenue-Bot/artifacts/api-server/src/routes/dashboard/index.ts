import { Router, type IRouter } from "express";
import { desc } from "drizzle-orm";
import { db, agentsTable, opportunitiesTable, tasksTable, revenueStreamsTable } from "@workspace/db";
import { GetDashboardSummaryResponse, GetRecentActivityResponse } from "@workspace/api-zod";
import { sql } from "drizzle-orm";

const router: IRouter = Router();

router.get("/dashboard/summary", async (_req, res): Promise<void> => {
  const [agents, streams, opportunities, tasks] = await Promise.all([
    db.select().from(agentsTable),
    db.select().from(revenueStreamsTable),
    db.select().from(opportunitiesTable),
    db.select().from(tasksTable).where(
      sql`DATE(${tasksTable.createdAt}) = CURRENT_DATE`
    ),
  ]);

  const activeStreams = streams.filter((s) => s.status === "active");
  const totalRevenue = streams.reduce((sum, s) => sum + s.totalRevenue, 0);
  const monthlyRevenue = activeStreams.reduce((sum, s) => sum + s.monthlyRevenue, 0);
  // Historical revenue snapshots are not stored yet, so do not invent a trend.
  const revenueGrowthPercent = 0;

  const summary = {
    totalRevenue,
    monthlyRevenue,
    activeStreams: activeStreams.length,
    totalStreams: streams.length,
    runningAgents: agents.filter((a) => a.status === "running").length,
    totalAgents: agents.length,
    pendingOpportunities: opportunities.filter((o) => o.status === "pending").length,
    tasksToday: tasks.length,
    revenueGrowthPercent: Math.round(revenueGrowthPercent * 10) / 10,
  };

  res.json(GetDashboardSummaryResponse.parse(summary));
});

router.get("/dashboard/activity", async (_req, res): Promise<void> => {
  const [recentTasks, recentOpportunities, recentStreams] = await Promise.all([
    db.select().from(tasksTable).orderBy(desc(tasksTable.createdAt)).limit(5),
    db.select().from(opportunitiesTable).orderBy(desc(opportunitiesTable.createdAt)).limit(5),
    db.select().from(revenueStreamsTable).orderBy(desc(revenueStreamsTable.createdAt)).limit(3),
  ]);

  const activities = [
    ...recentTasks.map((t) => ({
      id: t.id * 100,
      type: "task_completed" as const,
      title: t.title,
      description: `Task ${t.status} — ${t.description.slice(0, 80)}`,
      createdAt: t.createdAt.toISOString(),
    })),
    ...recentOpportunities.map((o) => ({
      id: o.id * 100 + 1,
      type: "opportunity_found" as const,
      title: o.title,
      description: `${o.category} opportunity — $${o.estimatedMonthlyRevenue.toLocaleString()}/mo estimated`,
      createdAt: o.createdAt.toISOString(),
    })),
    ...recentStreams.map((s) => ({
      id: s.id * 100 + 2,
      type: "stream_created" as const,
      title: s.name,
      description: `Revenue stream ${s.status} — $${s.monthlyRevenue.toLocaleString()}/mo`,
      createdAt: s.createdAt.toISOString(),
    })),
  ].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).slice(0, 15);

  res.json(GetRecentActivityResponse.parse(activities));
});

export default router;
