import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import { eq } from "drizzle-orm";
import {
  generateRegistrationOptions,
  verifyRegistrationResponse,
  generateAuthenticationOptions,
  verifyAuthenticationResponse,
  type AuthenticatorTransportFuture,
} from "@simplewebauthn/server";
import jwt from "jsonwebtoken";
import { db, vaultCredentialsTable } from "@workspace/db";
import { getUncachableStripeClient, getStripePublishableKey } from "../../lib/stripeClient";
import {
  validateAmount,
  generateIdempotencyKey,
  sendSafeError,
  paymentLimiter,
  vaultAuthLimiter,
} from "../../middleware/security";

const router: IRouter = Router();

// ─── JWT ─────────────────────────────────────────────────────────────────────
function getSecret(): string {
  const s = process.env.SESSION_SECRET;
  if (!s) throw new Error("SESSION_SECRET not configured");
  return s;
}

function issueToken(credentialId: string): string {
  return jwt.sign({ sub: "vault", credentialId }, getSecret(), { expiresIn: "30m" });
}

// ─── One-time challenge store (in-memory, 60 s TTL) ──────────────────────────
const challenges = new Map<string, { value: string; expiry: number }>();
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of challenges) if (v.expiry < now) challenges.delete(k);
}, 5 * 60_000).unref();

function storeChallenge(ip: string, value: string): void {
  challenges.set(ip, { value, expiry: Date.now() + 60_000 });
}

function consumeChallenge(ip: string): string | null {
  const e = challenges.get(ip);
  if (!e || e.expiry < Date.now()) { challenges.delete(ip); return null; }
  challenges.delete(ip); // single-use
  return e.value;
}

// ─── RPID / origin helpers ───────────────────────────────────────────────────
function getRPID(req: Request): string {
  const src =
    (req.headers.origin as string | undefined) ||
    (req.headers.host ? `https://${req.headers.host}` : "");
  try {
    return new URL(src.startsWith("http") ? src : `https://${src}`).hostname;
  } catch {
    return "localhost";
  }
}

function getOrigin(req: Request): string {
  const o = req.headers.origin as string | undefined;
  if (o) return o;
  const h = getRPID(req);
  return h === "localhost" ? "http://localhost" : `https://${h}`;
}

function clientIP(req: Request): string {
  return (req.ip ?? req.socket.remoteAddress ?? "unknown").replace("::ffff:", "");
}

// ─── Vault session middleware ─────────────────────────────────────────────────
function requireVaultSession(req: Request, res: Response, next: NextFunction): void {
  const auth = req.headers.authorization;
  if (!auth?.startsWith("Bearer ")) {
    res.status(401).json({ error: "Unauthorized: vault session required" });
    return;
  }
  try {
    (req as Request & { vaultSession: unknown }).vaultSession = jwt.verify(
      auth.slice(7),
      getSecret(),
    );
    next();
  } catch {
    res.status(401).json({ error: "Unauthorized: invalid or expired session" });
  }
}

// ─── Registration status ──────────────────────────────────────────────────────
router.get("/vault/status", async (_req, res): Promise<void> => {
  const rows = await db
    .select({ id: vaultCredentialsTable.id })
    .from(vaultCredentialsTable);
  res.json({ registered: rows.length > 0 });
});

// ─── WebAuthn: Registration ───────────────────────────────────────────────────
router.get("/vault/register/options", vaultAuthLimiter, async (req, res): Promise<void> => {
  const rpID = getRPID(req);
  const ip = clientIP(req);

  const existing = await db
    .select({ id: vaultCredentialsTable.id })
    .from(vaultCredentialsTable);

  const options = await generateRegistrationOptions({
    rpName: "AutonomIQ Vault",
    rpID,
    userID: new TextEncoder().encode("vault-owner"),
    userName: "vault-owner",
    attestationType: "none",
    authenticatorSelection: {
      authenticatorAttachment: "platform",
      userVerification: "required",
      residentKey: "preferred",
    },
    excludeCredentials: existing.map((c) => ({ id: c.id })),
  });

  storeChallenge(ip, options.challenge);
  res.json(options);
});

router.post("/vault/register/verify", vaultAuthLimiter, async (req, res): Promise<void> => {
  const rpID = getRPID(req);
  const ip = clientIP(req);
  const challenge = consumeChallenge(ip);

  if (!challenge) {
    res.status(400).json({ error: "Challenge expired or not found. Request new options." });
    return;
  }

  try {
    const { verified, registrationInfo } = await verifyRegistrationResponse({
      response: req.body,
      expectedChallenge: challenge,
      expectedOrigin: getOrigin(req),
      expectedRPID: rpID,
      requireUserVerification: true,
    });

    if (!verified || !registrationInfo) {
      res.status(400).json({ error: "Registration verification failed" });
      return;
    }

    const {
      credential: { id: credentialID, publicKey: credentialPublicKey, counter },
      credentialBackedUp,
    } = registrationInfo;
    // Extract transports from the response body (not present in registrationInfo).
    const transports: string[] = req.body?.response?.transports ?? req.body?.transports ?? [];
    const publicKeyB64 = Buffer.from(credentialPublicKey).toString("base64url");

    await db
      .insert(vaultCredentialsTable)
      .values({
        id: credentialID,
        publicKey: publicKeyB64,
        counter,
        transports: JSON.stringify(transports),
        backedUp: credentialBackedUp,
      })
      .onConflictDoUpdate({
        target: vaultCredentialsTable.id,
        set: {
          publicKey: publicKeyB64,
          counter,
          transports: JSON.stringify(transports),
          backedUp: credentialBackedUp,
        },
      });

    res.json({ verified: true, sessionToken: issueToken(credentialID) });
  } catch (err) {
    sendSafeError(res, err, 400);
  }
});

// ─── WebAuthn: Authentication ─────────────────────────────────────────────────
router.get("/vault/auth/options", vaultAuthLimiter, async (req, res): Promise<void> => {
  const rpID = getRPID(req);
  const ip = clientIP(req);

  const stored = await db.select().from(vaultCredentialsTable);
  if (!stored.length) {
    res.status(404).json({ error: "No vault credentials registered. Set up biometric access first." });
    return;
  }

  const options = await generateAuthenticationOptions({
    rpID,
    userVerification: "required",
    allowCredentials: stored.map((c) => ({
      id: c.id,
      transports: JSON.parse(c.transports) as AuthenticatorTransportFuture[],
    })),
  });

  storeChallenge(ip, options.challenge);
  res.json(options);
});

router.post("/vault/auth/verify", vaultAuthLimiter, async (req, res): Promise<void> => {
  const rpID = getRPID(req);
  const ip = clientIP(req);
  const challenge = consumeChallenge(ip);

  if (!challenge) {
    res.status(400).json({ error: "Challenge expired. Request new options." });
    return;
  }

  const [cred] = await db
    .select()
    .from(vaultCredentialsTable)
    .where(eq(vaultCredentialsTable.id, req.body.id));

  if (!cred) {
    res.status(401).json({ error: "Credential not recognized" });
    return;
  }

  try {
    const { verified, authenticationInfo } = await verifyAuthenticationResponse({
      response: req.body,
      expectedChallenge: challenge,
      expectedOrigin: getOrigin(req),
      expectedRPID: rpID,
      credential: {
        id: cred.id,
        publicKey: Buffer.from(cred.publicKey, "base64url"),
        counter: cred.counter,
        transports: JSON.parse(cred.transports) as AuthenticatorTransportFuture[],
      },
      requireUserVerification: true,
    });

    if (!verified) {
      res.status(401).json({ error: "Authentication failed" });
      return;
    }

    // Update signature counter — prevents replay attacks
    await db
      .update(vaultCredentialsTable)
      .set({ counter: authenticationInfo.newCounter, lastUsedAt: new Date() })
      .where(eq(vaultCredentialsTable.id, cred.id));

    res.json({ verified: true, sessionToken: issueToken(cred.id) });
  } catch (err) {
    sendSafeError(res, err, 401);
  }
});

// ─── Delete credential ────────────────────────────────────────────────────────
router.delete("/vault/credential", requireVaultSession, async (req, res): Promise<void> => {
  const session = (req as Request & { vaultSession: { credentialId: string } }).vaultSession;
  await db
    .delete(vaultCredentialsTable)
    .where(eq(vaultCredentialsTable.id, session.credentialId));
  res.json({ deleted: true });
});

// ─── Stripe config ────────────────────────────────────────────────────────────
router.get("/vault/config", requireVaultSession, async (_req, res): Promise<void> => {
  try {
    const publishableKey = await getStripePublishableKey();
    res.json({ publishableKey });
  } catch (err) {
    sendSafeError(res, err, 503);
  }
});

// ─── Bank Transfer ────────────────────────────────────────────────────────────
router.post("/vault/transfer", requireVaultSession, paymentLimiter, async (req, res): Promise<void> => {
  try {
    const amountCents = validateAmount(req.body.amount);
    const destination: string = (req.body.destination ?? "").trim();
    if (!destination) { res.status(400).json({ error: "Destination account is required" }); return; }

    const stripe = await getUncachableStripeClient();
    const intent = await stripe.paymentIntents.create(
      {
        amount: amountCents,
        currency: "usd",
        confirm: false,
        metadata: { type: "vault_transfer" },
      },
      { idempotencyKey: generateIdempotencyKey("transfer") },
    );

    res.json({ id: intent.id, status: intent.status, amountUsd: amountCents / 100 });
  } catch (err) {
    sendSafeError(res, err);
  }
});

// ─── Apple Pay / Payment Request ──────────────────────────────────────────────
router.post("/vault/payment-intent", requireVaultSession, paymentLimiter, async (req, res): Promise<void> => {
  try {
    const amountCents = validateAmount(req.body.amount);
    const stripe = await getUncachableStripeClient();
    const intent = await stripe.paymentIntents.create(
      {
        amount: amountCents,
        currency: "usd",
        payment_method_types: ["card"],
        metadata: { type: "vault_apple_pay" },
      },
      { idempotencyKey: generateIdempotencyKey("apple-pay") },
    );
    res.json({ clientSecret: intent.client_secret });
  } catch (err) {
    sendSafeError(res, err);
  }
});

// ─── Bitcoin: live rate (public — no auth) ────────────────────────────────────
router.get("/vault/bitcoin/rate", async (_req, res): Promise<void> => {
  try {
    const r = await fetch("https://api.coinbase.com/v2/prices/BTC-USD/spot", {
      headers: { "CB-VERSION": "2016-02-18" },
      signal: AbortSignal.timeout(5_000),
    });
    if (!r.ok) throw new Error("Rate unavailable");
    const { data } = (await r.json()) as { data: { amount: string } };
    res.json({ btcUsd: parseFloat(data.amount) });
  } catch (err) {
    sendSafeError(res, err, 503);
  }
});

// ─── Bitcoin: Coinbase Commerce charge ───────────────────────────────────────
router.post("/vault/bitcoin/charge", requireVaultSession, paymentLimiter, async (req, res): Promise<void> => {
  const apiKey = process.env.COINBASE_COMMERCE_API_KEY;
  if (!apiKey) {
    res.status(503).json({
      error: "Bitcoin not configured. Add COINBASE_COMMERCE_API_KEY to secrets.",
    });
    return;
  }

  try {
    const amountCents = validateAmount(req.body.amount);
    const amountUsd = (amountCents / 100).toFixed(2);

    const r = await fetch("https://api.commerce.coinbase.com/charges", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CC-Api-Key": apiKey,
        "X-CC-Version": "2018-03-22",
      },
      body: JSON.stringify({
        name: "AutonomIQ Vault — BTC",
        description: `Convert $${amountUsd} USD to Bitcoin`,
        pricing_type: "fixed_price",
        local_price: { amount: amountUsd, currency: "USD" },
        metadata: { type: "vault_btc" },
      }),
      signal: AbortSignal.timeout(10_000),
    });

    if (!r.ok) {
      const body = await r.json().catch(() => ({})) as { error?: { message?: string } };
      throw new Error(body.error?.message ?? "Charge creation failed");
    }

    const { data } = (await r.json()) as {
      data: { id: string; hosted_url: string; expires_at: string; addresses?: { bitcoin?: string } };
    };

    res.json({
      chargeId: data.id,
      hostedUrl: data.hosted_url,
      btcAddress: data.addresses?.bitcoin ?? null,
      expiresAt: data.expires_at,
      amountUsd: parseFloat(amountUsd),
    });
  } catch (err) {
    sendSafeError(res, err);
  }
});

// ─── General withdrawal ───────────────────────────────────────────────────────
router.post("/vault/withdraw", requireVaultSession, paymentLimiter, async (req, res): Promise<void> => {
  try {
    const amountCents = validateAmount(req.body.amount);
    const method: string = req.body.method ?? "";
    const destination: string = (req.body.destination ?? "").trim();

    if (!["applepay", "bank", "paypal", "cashapp"].includes(method)) {
      res.status(400).json({ error: "Invalid withdrawal method" });
      return;
    }
    if (!destination) {
      res.status(400).json({ error: "Destination is required" });
      return;
    }

    if (method === "applepay" || method === "bank") {
      const stripe = await getUncachableStripeClient();
      const intent = await stripe.paymentIntents.create(
        {
          amount: amountCents,
          currency: "usd",
          payment_method_types: ["card"],
          metadata: { type: `vault_withdraw_${method}` },
        },
        { idempotencyKey: generateIdempotencyKey(`withdraw-${method}`) },
      );
      res.json({ id: intent.id, clientSecret: intent.client_secret, method, amountUsd: amountCents / 100 });
      return;
    }

    // PayPal / Cash App — initiation record; activate via PAYPAL_CLIENT_ID + PAYPAL_CLIENT_SECRET
    res.json({
      id: `${method}-${Date.now()}`,
      status: "pending_integration",
      method,
      amountUsd: amountCents / 100,
      message: `Add ${method === "paypal" ? "PAYPAL_CLIENT_ID + PAYPAL_CLIENT_SECRET" : "CASHAPP_API_KEY"} to secrets to activate.`,
    });
  } catch (err) {
    sendSafeError(res, err);
  }
});

export default router;
