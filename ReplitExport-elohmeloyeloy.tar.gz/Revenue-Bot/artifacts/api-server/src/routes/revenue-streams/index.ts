import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, revenueStreamsTable } from "@workspace/db";
import {
  CreateRevenueStreamBody,
  UpdateRevenueStreamBody,
  GetRevenueStreamParams,
  UpdateRevenueStreamParams,
  DeleteRevenueStreamParams,
  ListRevenueStreamsResponse,
  GetRevenueStreamResponse,
  CreateRevenueStreamResponse,
  UpdateRevenueStreamResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/revenue-streams", async (_req, res): Promise<void> => {
  const streams = await db.select().from(revenueStreamsTable).orderBy(desc(revenueStreamsTable.createdAt));
  res.json(ListRevenueStreamsResponse.parse(streams));
});

router.post("/revenue-streams", async (req, res): Promise<void> => {
  const parsed = CreateRevenueStreamBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [stream] = await db.insert(revenueStreamsTable).values(parsed.data).returning();
  res.status(201).json(CreateRevenueStreamResponse.parse(stream));
});

router.get("/revenue-streams/:id", async (req, res): Promise<void> => {
  const params = GetRevenueStreamParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [stream] = await db.select().from(revenueStreamsTable).where(eq(revenueStreamsTable.id, params.data.id));
  if (!stream) {
    res.status(404).json({ error: "Revenue stream not found" });
    return;
  }
  res.json(GetRevenueStreamResponse.parse(stream));
});

router.patch("/revenue-streams/:id", async (req, res): Promise<void> => {
  const params = UpdateRevenueStreamParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateRevenueStreamBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [stream] = await db.update(revenueStreamsTable).set(parsed.data).where(eq(revenueStreamsTable.id, params.data.id)).returning();
  if (!stream) {
    res.status(404).json({ error: "Revenue stream not found" });
    return;
  }
  res.json(UpdateRevenueStreamResponse.parse(stream));
});

router.delete("/revenue-streams/:id", async (req, res): Promise<void> => {
  const params = DeleteRevenueStreamParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [stream] = await db.delete(revenueStreamsTable).where(eq(revenueStreamsTable.id, params.data.id)).returning();
  if (!stream) {
    res.status(404).json({ error: "Revenue stream not found" });
    return;
  }
  res.sendStatus(204);
});

export default router;
