import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, revenueStreamsTable, opportunitiesTable } from "@workspace/db";
import {
  AiDiscoverOpportunitiesBody,
  AiGenerateCodeBody,
  AiAnalyzeStreamBody,
  AiAnalyzeStreamResponse,
} from "@workspace/api-zod";
import { getOpenAIClient } from "../../lib/openai";

const router: IRouter = Router();

router.post("/ai/discover-opportunities", async (req, res): Promise<void> => {
  const parsed = AiDiscoverOpportunitiesBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  const { count, category, agentId } = parsed.data;
  const categoryFilter = category ? `Focus specifically on the "${category}" category.` : "Cover a variety of categories (affiliate, saas, content, api, automation, ecommerce, consulting).";

  try {
    const openai = getOpenAIClient();
    const stream = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      max_completion_tokens: 2048,
      messages: [
        {
          role: "system",
          content: `You are an autonomous revenue discovery AI. Generate exactly ${count} specific, actionable revenue opportunities for an autonomous AI platform. ${categoryFilter}

For each opportunity, provide:
- Title (concise, action-oriented)
- Description (2-3 sentences explaining the opportunity and how to monetize it)  
- Category (one of: affiliate, saas, content, api, automation, ecommerce, consulting)
- Estimated monthly revenue in USD (realistic figure)

Format each opportunity as a JSON object on a new line:
{"title":"...","description":"...","category":"...","estimatedMonthlyRevenue":number}

Output only the JSON objects, one per line, no other text.`,
        },
        { role: "user", content: `Generate ${count} revenue opportunities.` },
      ],
      stream: true,
    });

    let buffer = "";
    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content ?? "";
      buffer += content;
      res.write(`data: ${JSON.stringify({ content })}\n\n`);

      // Try to parse and save complete JSON lines
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith("{")) continue;
        try {
          const opp = JSON.parse(trimmed);
          if (opp.title && opp.description && opp.category && opp.estimatedMonthlyRevenue) {
            await db.insert(opportunitiesTable).values({
              title: opp.title,
              description: opp.description,
              category: opp.category,
              estimatedMonthlyRevenue: Number(opp.estimatedMonthlyRevenue),
              status: "pending",
              discoveredByAgentId: agentId ?? null,
            });
          }
        } catch {
          // not a complete JSON yet, skip
        }
      }
    }
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    res.write(`data: ${JSON.stringify({ content: `\n[ERROR] ${msg}` })}\n\n`);
  }

  res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
  res.end();
});

router.post("/ai/generate-code", async (req, res): Promise<void> => {
  const parsed = AiGenerateCodeBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  const { prompt, language = "javascript", streamId } = parsed.data;

  let streamContext = "";
  if (streamId) {
    const [stream] = await db.select().from(revenueStreamsTable).where(eq(revenueStreamsTable.id, streamId));
    if (stream) {
      streamContext = `\nContext: This code is for the revenue stream "${stream.name}" (${stream.type}). ${stream.description}`;
    }
  }

  try {
    const openai = getOpenAIClient();
    const codeStream = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      max_completion_tokens: 2048,
      messages: [
        {
          role: "system",
          content: `You are an expert autonomous revenue-generating code generator. Write production-ready ${language} code that can generate revenue autonomously.${streamContext}

Always include:
- Complete, runnable code with no placeholders
- Clear comments explaining the revenue mechanism
- Setup instructions as comments
- Expected revenue potential in the code comments`,
        },
        { role: "user", content: prompt },
      ],
      stream: true,
    });

    for await (const chunk of codeStream) {
      const content = chunk.choices[0]?.delta?.content;
      if (content) {
        res.write(`data: ${JSON.stringify({ content })}\n\n`);
      }
    }
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    res.write(`data: ${JSON.stringify({ content: `\n[ERROR] ${msg}` })}\n\n`);
  }

  res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
  res.end();
});

router.post("/ai/analyze-stream", async (req, res): Promise<void> => {
  const parsed = AiAnalyzeStreamBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [stream] = await db.select().from(revenueStreamsTable).where(eq(revenueStreamsTable.id, parsed.data.streamId));
  if (!stream) {
    res.status(404).json({ error: "Revenue stream not found" });
    return;
  }

  try {
    const openai = getOpenAIClient();
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      max_completion_tokens: 1024,
      messages: [
        {
          role: "system",
          content: `You are an expert revenue analyst AI. Analyze the given revenue stream and provide strategic insights.
          
Respond with a JSON object exactly like this:
{
  "summary": "2-3 sentence strategic summary",
  "recommendations": ["recommendation 1", "recommendation 2", "recommendation 3"],
  "projectedGrowth": 15.5,
  "riskLevel": "low"
}

riskLevel must be one of: low, medium, high
projectedGrowth is a percentage (e.g. 15.5 means 15.5% growth)
Output only the JSON object, no other text.`,
        },
        {
          role: "user",
          content: `Analyze this revenue stream:
Name: ${stream.name}
Type: ${stream.type}
Status: ${stream.status}
Monthly Revenue: $${stream.monthlyRevenue}
Total Revenue: $${stream.totalRevenue}
Description: ${stream.description}`,
        },
      ],
    });

    const raw = response.choices[0]?.message?.content ?? "{}";
    let analysis: unknown;
    try {
      analysis = JSON.parse(raw);
    } catch {
      analysis = {
        summary: raw,
        recommendations: ["Review stream performance", "Monitor conversion rates", "Test pricing models"],
        projectedGrowth: 10,
        riskLevel: "medium",
      };
    }

    res.json(AiAnalyzeStreamResponse.parse(analysis));
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    res.status(500).json({ error: `AI analysis failed: ${msg}` });
  }
});

export default router;
