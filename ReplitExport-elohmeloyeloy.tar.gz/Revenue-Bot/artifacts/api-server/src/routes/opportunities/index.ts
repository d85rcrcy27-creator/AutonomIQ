import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, opportunitiesTable } from "@workspace/db";
import {
  CreateOpportunityBody,
  UpdateOpportunityBody,
  GetOpportunityParams,
  UpdateOpportunityParams,
  DeleteOpportunityParams,
  ApproveOpportunityParams,
  RejectOpportunityParams,
  ListOpportunitiesResponse,
  GetOpportunityResponse,
  CreateOpportunityResponse,
  UpdateOpportunityResponse,
  ApproveOpportunityResponse,
  RejectOpportunityResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/opportunities", async (_req, res): Promise<void> => {
  const opps = await db.select().from(opportunitiesTable).orderBy(desc(opportunitiesTable.createdAt));
  res.json(ListOpportunitiesResponse.parse(opps));
});

router.post("/opportunities", async (req, res): Promise<void> => {
  const parsed = CreateOpportunityBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [opp] = await db.insert(opportunitiesTable).values(parsed.data).returning();
  res.status(201).json(CreateOpportunityResponse.parse(opp));
});

router.get("/opportunities/:id", async (req, res): Promise<void> => {
  const params = GetOpportunityParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [opp] = await db.select().from(opportunitiesTable).where(eq(opportunitiesTable.id, params.data.id));
  if (!opp) {
    res.status(404).json({ error: "Opportunity not found" });
    return;
  }
  res.json(GetOpportunityResponse.parse(opp));
});

router.patch("/opportunities/:id", async (req, res): Promise<void> => {
  const params = UpdateOpportunityParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateOpportunityBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [opp] = await db.update(opportunitiesTable).set(parsed.data).where(eq(opportunitiesTable.id, params.data.id)).returning();
  if (!opp) {
    res.status(404).json({ error: "Opportunity not found" });
    return;
  }
  res.json(UpdateOpportunityResponse.parse(opp));
});

router.delete("/opportunities/:id", async (req, res): Promise<void> => {
  const params = DeleteOpportunityParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [opp] = await db.delete(opportunitiesTable).where(eq(opportunitiesTable.id, params.data.id)).returning();
  if (!opp) {
    res.status(404).json({ error: "Opportunity not found" });
    return;
  }
  res.sendStatus(204);
});

router.post("/opportunities/:id/approve", async (req, res): Promise<void> => {
  const params = ApproveOpportunityParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [opp] = await db
    .update(opportunitiesTable)
    .set({ status: "approved" })
    .where(eq(opportunitiesTable.id, params.data.id))
    .returning();
  if (!opp) {
    res.status(404).json({ error: "Opportunity not found" });
    return;
  }
  res.json(ApproveOpportunityResponse.parse(opp));
});

router.post("/opportunities/:id/reject", async (req, res): Promise<void> => {
  const params = RejectOpportunityParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [opp] = await db
    .update(opportunitiesTable)
    .set({ status: "rejected" })
    .where(eq(opportunitiesTable.id, params.data.id))
    .returning();
  if (!opp) {
    res.status(404).json({ error: "Opportunity not found" });
    return;
  }
  res.json(RejectOpportunityResponse.parse(opp));
});

export default router;
