import { Router, type IRouter } from "express";
import healthRouter from "./health";
import agentsRouter from "./agents";
import opportunitiesRouter from "./opportunities";
import tasksRouter from "./tasks";
import revenueStreamsRouter from "./revenue-streams";
import dashboardRouter from "./dashboard";
import aiRouter from "./ai";
import vaultRouter from "./vault";
import automationRouter from "./automation";

const router: IRouter = Router();

router.use(healthRouter);
router.use(agentsRouter);
router.use(opportunitiesRouter);
router.use(tasksRouter);
router.use(revenueStreamsRouter);
router.use(dashboardRouter);
router.use(aiRouter);
router.use(vaultRouter);
router.use(automationRouter);

export default router;
