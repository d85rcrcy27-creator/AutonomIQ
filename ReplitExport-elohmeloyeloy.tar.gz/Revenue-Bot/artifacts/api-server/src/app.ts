import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import { WebhookHandlers } from "./lib/webhookHandlers";
import router from "./routes";
import { logger } from "./lib/logger";
import { helmetMiddleware, globalLimiter } from "./middleware/security";

const app: Express = express();

// ─── Security headers (helmet) ─────────────────────────────────────────────
// Must come before all routes so every response gets security headers.
app.use(helmetMiddleware);

// ─── Trust Replit's reverse-proxy so req.ip is the real client IP ──────────
app.set("trust proxy", 1);

// ─── Stripe webhook — MUST be before express.json() ──────────────────────
// Stripe requires the raw Buffer; express.json() would parse and destroy it.
app.post(
  "/api/stripe/webhook",
  express.raw({ type: "application/json" }),
  async (req, res) => {
    const sig = req.headers["stripe-signature"];
    if (!sig) {
      res.status(400).json({ error: "Missing stripe-signature header" });
      return;
    }
    const signature = Array.isArray(sig) ? sig[0] : sig;
    if (!Buffer.isBuffer(req.body)) {
      logger.error("Stripe webhook body is not a Buffer — middleware ordering issue");
      res.status(500).json({ error: "Webhook configuration error" });
      return;
    }
    try {
      await WebhookHandlers.processWebhook(req.body as Buffer, signature);
      res.status(200).json({ received: true });
    } catch (err) {
      logger.error({ err }, "Stripe webhook processing error");
      res.status(400).json({ error: "Webhook processing error" });
    }
  },
);

// ─── CORS — restrict to our own Replit domain(s) ──────────────────────────
const allowedOrigins = new Set<string>();
(process.env.REPLIT_DOMAINS ?? "").split(",").forEach((d) => {
  const h = d.trim();
  if (h) allowedOrigins.add(`https://${h}`);
});
// Also allow localhost for local development
allowedOrigins.add("http://localhost");
allowedOrigins.add("http://127.0.0.1");

app.use(
  cors({
    origin: (origin, cb) => {
      // Allow requests with no origin (server-to-server, curl, Replit health checks)
      if (!origin) return cb(null, true);
      if (allowedOrigins.has(origin)) return cb(null, true);
      // Also allow any *.replit.dev / *.repl.co subdomain (dev previews)
      if (/^https:\/\/[a-z0-9-]+\.(replit\.dev|repl\.co)$/.test(origin)) return cb(null, true);
      cb(new Error(`CORS: origin not allowed: ${origin}`));
    },
    methods: ["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
    credentials: true,
  }),
);

// ─── Request logging (pino) ────────────────────────────────────────────────
app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return { id: req.id, method: req.method, url: req.url?.split("?")[0] };
      },
      res(res) {
        return { statusCode: res.statusCode };
      },
    },
    // Never log Authorization headers — they contain vault session tokens
    redact: ["req.headers.authorization", "req.headers.cookie"],
  }),
);

// ─── Global rate limiter ──────────────────────────────────────────────────
app.use(globalLimiter);

// ─── Body parsing — AFTER webhook route ───────────────────────────────────
app.use(express.json({ limit: "64kb" })); // small limit; we don't accept file uploads
app.use(express.urlencoded({ extended: true, limit: "16kb" }));

// ─── API routes ───────────────────────────────────────────────────────────
app.use("/api", router);

export default app;
