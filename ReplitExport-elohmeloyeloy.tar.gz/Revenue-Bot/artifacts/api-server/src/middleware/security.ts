import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { type Response } from "express";
import { randomBytes } from "crypto";

// ─── Security Headers ─────────────────────────────────────────────────────────
// CSP allows Stripe.js (required for Payment Request / Apple Pay),
// blocks inline scripts, blocks framing by default.
export const helmetMiddleware = helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "https://js.stripe.com", "https://cdn.jsdelivr.net"],
      frameSrc: ["'self'", "https://js.stripe.com", "https://hooks.stripe.com"],
      connectSrc: [
        "'self'",
        "https://api.stripe.com",
        "https://api.commerce.coinbase.com",
        "https://api.coinbase.com",
      ],
      imgSrc: ["'self'", "data:", "https:"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      fontSrc: ["'self'", "data:", "https:"],
      objectSrc: ["'none'"],
      baseUri: ["'self'"],
    },
  },
  hsts: { maxAge: 31_536_000, includeSubDomains: true, preload: true },
  referrerPolicy: { policy: "strict-origin-when-cross-origin" },
  // Disable COEP so Stripe iframes load correctly
  crossOriginEmbedderPolicy: false,
});

// ─── Rate Limiters ────────────────────────────────────────────────────────────
const limiterDefaults = {
  standardHeaders: "draft-7" as const,
  legacyHeaders: false,
} as const;

/** General API: 120 requests / min per IP */
export const globalLimiter = rateLimit({
  ...limiterDefaults,
  windowMs: 60_000,
  max: 120,
  message: { error: "Too many requests. Please try again shortly." },
  skip: (req) => req.method === "OPTIONS",
});

/** Payment operations: 10 requests / min per IP */
export const paymentLimiter = rateLimit({
  ...limiterDefaults,
  windowMs: 60_000,
  max: 10,
  message: { error: "Too many payment requests. Please try again shortly." },
});

/** Vault auth (WebAuthn / PIN): 5 failures / 15 min per IP — brute-force guard */
export const vaultAuthLimiter = rateLimit({
  ...limiterDefaults,
  windowMs: 15 * 60_000,
  max: 5,
  skipSuccessfulRequests: true,
  message: { error: "Too many authentication attempts. Please wait 15 minutes." },
});

// ─── Amount Validation ────────────────────────────────────────────────────────
const MIN_AMOUNT_USD = 1;
const MAX_AMOUNT_USD = 50_000;

/**
 * Validates a monetary amount.
 * - Must be a positive, finite number with ≤ 2 decimal places
 * - Minimum: $1.00 | Maximum: $50,000.00
 * Returns the amount in **cents** (integer) ready for Stripe.
 */
export function validateAmount(raw: unknown): number {
  const n = typeof raw === "string" ? parseFloat(raw) : Number(raw);
  if (!Number.isFinite(n) || isNaN(n)) throw new Error("Amount must be a valid number");
  if (n < MIN_AMOUNT_USD) throw new Error(`Minimum amount is $${MIN_AMOUNT_USD.toFixed(2)}`);
  if (n > MAX_AMOUNT_USD) throw new Error(`Maximum amount is $${MAX_AMOUNT_USD.toLocaleString()} per transaction`);
  const str = n.toString();
  const decimals = (str.split(".")[1] ?? "").length;
  if (decimals > 2) throw new Error("Amount must not have more than 2 decimal places");
  return Math.round(n * 100); // safe integer cents
}

// ─── Idempotency Keys ─────────────────────────────────────────────────────────
/** Generates a cryptographically random idempotency key for Stripe calls */
export function generateIdempotencyKey(prefix: string): string {
  return `${prefix}-${Date.now()}-${randomBytes(8).toString("hex")}`;
}

// ─── Safe Error Responses ─────────────────────────────────────────────────────
/**
 * Responds with a safe error that does not expose internal stack traces.
 * Always logs the full error server-side.
 */
export function sendSafeError(res: Response, err: unknown, defaultStatus = 500): void {
  const msg = err instanceof Error ? err.message : "An unexpected error occurred";

  // Map well-known messages to appropriate HTTP codes
  const status =
    msg.startsWith("Amount") ||
    msg.startsWith("Minimum") ||
    msg.startsWith("Maximum") ||
    msg.startsWith("Invalid")
      ? 400
      : msg.startsWith("Unauthorized") || msg.startsWith("Session")
        ? 401
        : msg.includes("not found") || msg.includes("Not found")
          ? 404
          : msg.includes("not configured") || msg.includes("not connected")
            ? 503
            : defaultStatus;

  res.status(status).json({ error: msg });
}
