export type PublicDiscoverySource = "hackernews" | "github";

export type PublicDiscoveryItem = {
  source: PublicDiscoverySource;
  sourceUrl: string;
  title: string;
  excerpt: string;
  category: "affiliate" | "saas" | "content" | "api" | "automation" | "ecommerce" | "consulting";
  opportunityTitle: string;
  estimatedMonthlyRevenue: number;
};

const CATEGORY_TERMS: Record<string, string> = {
  affiliate: "affiliate marketing",
  saas: "SaaS startup",
  content: "content creator",
  api: "API integration",
  automation: "automation workflow",
  ecommerce: "ecommerce store",
  consulting: "consulting service",
};

function categoryFor(text: string, requested?: string): PublicDiscoveryItem["category"] {
  if (
    requested &&
    ["affiliate", "saas", "content", "api", "automation", "ecommerce", "consulting"].includes(requested)
  ) {
    return requested as PublicDiscoveryItem["category"];
  }
  const value = text.toLowerCase();
  if (/\b(api|sdk|integration|developer)\b/.test(value)) return "api";
  if (/\b(automat|workflow|bot|agent|scrap)\w*/.test(value)) return "automation";
  if (/\b(shop|store|commerce|product|catalog)\w*/.test(value)) return "ecommerce";
  if (/\b(affiliate|referral|commission)\w*/.test(value)) return "affiliate";
  if (/\b(content|newsletter|creator|video|blog)\w*/.test(value)) return "content";
  if (/\b(consult|agency|freelance|service)\w*/.test(value)) return "consulting";
  return "saas";
}

function estimateMonthlyRevenue(category: PublicDiscoveryItem["category"], score: number): number {
  const baseline = {
    affiliate: 900,
    saas: 2400,
    content: 1200,
    api: 3200,
    automation: 2800,
    ecommerce: 1800,
    consulting: 2200,
  }[category];
  return Math.round((baseline + Math.min(Math.max(score, 0), 100) * 18) / 100) * 100;
}

async function getJson<T>(url: string, headers: Record<string, string> = {}): Promise<T> {
  const response = await fetch(url, {
    headers: { Accept: "application/json", ...headers },
    signal: AbortSignal.timeout(8_000),
  });
  if (!response.ok) throw new Error(`Public source returned ${response.status}`);
  return (await response.json()) as T;
}

async function searchHackerNews(category?: string, limit = 10): Promise<PublicDiscoveryItem[]> {
  const query = CATEGORY_TERMS[category ?? ""] ?? "freelance startup automation API";
  const url = `https://hn.algolia.com/api/v1/search_by_date?tags=story&hitsPerPage=${limit}&query=${encodeURIComponent(query)}`;
  const data = await getJson<{
    hits?: Array<{ objectID?: string; title?: string; url?: string; story_text?: string; points?: number }>;
  }>(url);

  return (data.hits ?? [])
    .filter((hit) => hit.title && hit.objectID)
    .map((hit) => {
      const text = `${hit.title} ${hit.story_text ?? ""}`;
      const selectedCategory = categoryFor(text, category);
      const score = hit.points ?? 0;
      return {
        source: "hackernews",
        sourceUrl: hit.url || `https://news.ycombinator.com/item?id=${hit.objectID}`,
        title: hit.title!,
        excerpt: (hit.story_text ?? "Public Hacker News discussion").replace(/<[^>]+>/g, "").slice(0, 500),
        category: selectedCategory,
        opportunityTitle: `Build a revenue service around: ${hit.title!.slice(0, 120)}`,
        estimatedMonthlyRevenue: estimateMonthlyRevenue(selectedCategory, score),
      };
    });
}

async function searchGithub(category?: string, limit = 10): Promise<PublicDiscoveryItem[]> {
  const topic = CATEGORY_TERMS[category ?? ""] ?? "good first issue revenue automation";
  const query = encodeURIComponent(`"${topic}" is:issue is:open`);
  const data = await getJson<{
    items?: Array<{ html_url?: string; title?: string; body?: string; comments?: number }>;
  }>(`https://api.github.com/search/issues?q=${query}&per_page=${limit}`, {
    "User-Agent": "AutonomIQ-public-discovery/1.0",
  });

  return (data.items ?? [])
    .filter((item) => item.title && item.html_url)
    .map((item) => {
      const text = `${item.title} ${item.body ?? ""}`;
      const selectedCategory = categoryFor(text, category);
      return {
        source: "github",
        sourceUrl: item.html_url!,
        title: item.title!,
        excerpt: (item.body ?? "Public GitHub issue").slice(0, 500),
        category: selectedCategory,
        opportunityTitle: `Deliver an implementation for: ${item.title!.slice(0, 120)}`,
        estimatedMonthlyRevenue: estimateMonthlyRevenue(selectedCategory, item.comments ?? 0),
      };
    });
}

/**
 * Uses public, unauthenticated endpoints. No customer accounts, OAuth tokens,
 * or per-source registrations are required. A failed source is isolated so a
 * temporary upstream outage does not take down the other source.
 */
export async function discoverPublicOpportunities(
  source: "all" | PublicDiscoverySource = "all",
  category?: string,
  count = 6,
): Promise<PublicDiscoveryItem[]> {
  const perSource = Math.max(1, Math.ceil(count / (source === "all" ? 2 : 1)));
  const searches: Array<Promise<PublicDiscoveryItem[]>> = [];
  if (source === "all" || source === "hackernews") searches.push(searchHackerNews(category, perSource));
  if (source === "all" || source === "github") searches.push(searchGithub(category, perSource));

  const results = await Promise.allSettled(searches);
  const items = results.flatMap((result) => (result.status === "fulfilled" ? result.value : []));
  const seen = new Set<string>();
  return items.filter((item) => {
    if (seen.has(item.sourceUrl)) return false;
    seen.add(item.sourceUrl);
    return true;
  }).slice(0, count);
}