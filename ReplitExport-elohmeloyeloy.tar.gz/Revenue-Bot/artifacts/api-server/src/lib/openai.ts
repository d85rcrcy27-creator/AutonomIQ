import OpenAI from "openai";

let _client: OpenAI | null = null;

export function getOptionalOpenAIClient(): OpenAI | null {
  const apiKey = process.env.OPENAI_API_KEY?.trim();
  if (!apiKey) return null;
  if (!_client) {
    _client = new OpenAI({ apiKey });
  }
  return _client;
}

export function getOpenAIClient(): OpenAI {
  const client = getOptionalOpenAIClient();
  if (!client) {
    throw new Error("OPENAI_API_KEY environment variable is not set. Please add your OpenAI API key to use AI features.");
  }
  return client;
}
