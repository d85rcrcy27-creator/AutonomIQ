import { getStripeSync } from "./stripeClient";
import { getUncachableStripeClient, getStripeWebhookSecret } from "./stripeClient";
import { db, automationJobsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { logger } from "./logger";
import { markJobPaidAndAdvance } from "../routes/automation";

export class WebhookHandlers {
  /**
   * Processes a Stripe webhook event.
   * payload MUST be the raw Buffer — register this route BEFORE express.json().
   */
  static async processWebhook(payload: Buffer, signature: string): Promise<void> {
    if (!Buffer.isBuffer(payload)) {
      throw new Error(
        "STRIPE WEBHOOK ERROR: Payload must be a Buffer. " +
          "Ensure the webhook route is registered BEFORE app.use(express.json()).",
      );
    }
    const sync = await getStripeSync();
    await sync.processWebhook(payload, signature);

    // Keep the pipeline state truthful: only Stripe can move a job to paid.
    const stripe = await getUncachableStripeClient();
    const event = stripe.webhooks.constructEvent(payload, signature, await getStripeWebhookSecret());
    const object = event.data.object as {
      metadata?: { automationJobId?: string };
      payment_status?: string;
      payment_intent?: string | null;
    };
    const jobId = Number(object.metadata?.automationJobId);
    if (Number.isInteger(jobId) && jobId > 0) {
      if (event.type === "checkout.session.completed" || event.type === "payment_intent.succeeded") {
        const transition = await markJobPaidAndAdvance(jobId);
        logger.info(
          { jobId, advancedJobId: transition.next?.job?.id ?? null },
          "Automation payment confirmed",
        );
      } else if (event.type === "checkout.session.expired") {
        await db.update(automationJobsTable).set({ paymentStatus: "expired" })
          .where(eq(automationJobsTable.id, jobId));
      }
    }
  }
}
