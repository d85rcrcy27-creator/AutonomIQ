/**
 * Server-side WebAuthn vault authentication.
 * Uses @simplewebauthn/browser to handle the platform authenticator ceremony,
 * then verifies on the server (avoiding client-only security).
 * Returns a short-lived JWT session token on success — stored in memory only.
 */
import { useState, useCallback } from "react";
import { startRegistration, startAuthentication } from "@simplewebauthn/browser";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");
const api = (path: string) => `${BASE}${path}`;

async function apiJson<T>(path: string, opts?: RequestInit): Promise<T> {
  const res = await fetch(api(path), {
    ...opts,
    headers: { "Content-Type": "application/json", ...(opts?.headers ?? {}) },
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.error ?? `Request failed: ${res.status}`);
  return json as T;
}

export type VaultAuthState = "idle" | "loading" | "error";

export function useVaultAuth() {
  const [state, setState] = useState<VaultAuthState>("idle");
  const [error, setError] = useState("");

  const reset = useCallback(() => {
    setState("idle");
    setError("");
  }, []);

  /** Check if a credential is registered on the server */
  const checkRegistered = useCallback(async (): Promise<boolean> => {
    try {
      const { registered } = await apiJson<{ registered: boolean }>("/api/vault/status");
      return registered;
    } catch {
      return false;
    }
  }, []);

  /** Register device biometric — returns session token or null on failure */
  const register = useCallback(async (): Promise<string | null> => {
    setState("loading");
    setError("");
    try {
      // 1. Get challenge + options from server
      const options = await apiJson<object>("/api/vault/register/options");

      // 2. Trigger platform authenticator (Face ID / Touch ID / Windows Hello)
      const attestation = await startRegistration(options as Parameters<typeof startRegistration>[0]);

      // 3. Send assertion to server for cryptographic verification
      const { sessionToken } = await apiJson<{ verified: boolean; sessionToken: string }>(
        "/api/vault/register/verify",
        { method: "POST", body: JSON.stringify(attestation) },
      );

      setState("idle");
      return sessionToken;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Registration failed";
      // Translate browser-standard WebAuthn error codes to friendly messages
      const friendly =
        msg.includes("NotAllowedError") || msg.includes("cancelled") || msg.includes("abort")
          ? "Biometric prompt dismissed. Please try again."
          : msg.includes("InvalidStateError")
            ? "This device is already registered."
            : msg.includes("NotSupportedError")
              ? "This device does not support biometric authentication."
              : msg;
      setError(friendly);
      setState("error");
      return null;
    }
  }, []);

  /** Authenticate with registered biometric — returns session token or null */
  const authenticate = useCallback(async (): Promise<string | null> => {
    setState("loading");
    setError("");
    try {
      const options = await apiJson<object>("/api/vault/auth/options");
      const assertion = await startAuthentication(options as Parameters<typeof startAuthentication>[0]);
      const { sessionToken } = await apiJson<{ verified: boolean; sessionToken: string }>(
        "/api/vault/auth/verify",
        { method: "POST", body: JSON.stringify(assertion) },
      );
      setState("idle");
      return sessionToken;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Authentication failed";
      const friendly =
        msg.includes("NotAllowedError") || msg.includes("cancelled") || msg.includes("abort")
          ? "Biometric prompt dismissed. Try again."
          : msg.includes("No vault credentials")
            ? "No biometric registered. Set up vault access first."
            : msg;
      setError(friendly);
      setState("error");
      return null;
    }
  }, []);

  /** Remove the registered credential from the server */
  const clearCredential = useCallback(async (sessionToken: string): Promise<void> => {
    await fetch(api("/api/vault/credential"), {
      method: "DELETE",
      headers: { Authorization: `Bearer ${sessionToken}` },
    }).catch(() => {});
  }, []);

  return { state, error, reset, checkRegistered, register, authenticate, clearCredential };
}

/** Authenticated fetch helper — attaches the vault session token */
export async function vaultFetch(
  path: string,
  sessionToken: string,
  opts?: RequestInit,
): Promise<Response> {
  const base = import.meta.env.BASE_URL.replace(/\/$/, "");
  return fetch(`${base}${path}`, {
    ...opts,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${sessionToken}`,
      ...(opts?.headers ?? {}),
    },
  });
}
