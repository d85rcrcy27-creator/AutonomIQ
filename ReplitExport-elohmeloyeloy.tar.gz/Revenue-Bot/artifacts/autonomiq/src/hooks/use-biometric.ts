import { useState, useCallback } from "react";

const CRED_KEY = "autonomiq_vault_cred_v1";
const PIN_KEY = "autonomiq_vault_pin_v1";

function b64encode(buf: ArrayBuffer): string {
  return btoa(String.fromCharCode(...new Uint8Array(buf)))
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=/g, "");
}

function b64decode(str: string): Uint8Array {
  const base64 = str.replace(/-/g, "+").replace(/_/g, "/");
  const bin = atob(base64);
  return new Uint8Array([...bin].map((c) => c.charCodeAt(0)));
}

async function hashPin(pin: string): Promise<string> {
  const data = new TextEncoder().encode(`autonomiq-vault-${pin}`);
  const buf = await crypto.subtle.digest("SHA-256", data);
  return b64encode(buf);
}

export type BiometricState = "idle" | "registering" | "authenticating" | "success" | "error";

export function useBiometric() {
  const [state, setState] = useState<BiometricState>("idle");
  const [errorMsg, setErrorMsg] = useState("");

  const isWebAuthnSupported =
    typeof window !== "undefined" &&
    !!window.PublicKeyCredential &&
    typeof navigator.credentials?.create === "function";

  const hasCredential = () => !!localStorage.getItem(CRED_KEY);
  const hasPin = () => !!localStorage.getItem(PIN_KEY);

  // --- WebAuthn ---
  const registerBiometric = useCallback(async (): Promise<boolean> => {
    setState("registering");
    setErrorMsg("");
    try {
      const challenge = crypto.getRandomValues(new Uint8Array(32));
      const userId = crypto.getRandomValues(new Uint8Array(16));
      const hostname = window.location.hostname;

      const credential = (await navigator.credentials.create({
        publicKey: {
          challenge,
          rp: { name: "AutonomIQ Vault", id: hostname },
          user: { id: userId, name: "vault-owner", displayName: "Vault Owner" },
          pubKeyCredParams: [
            { type: "public-key", alg: -7 },
            { type: "public-key", alg: -257 },
          ],
          authenticatorSelection: {
            authenticatorAttachment: "platform",
            userVerification: "required",
            residentKey: "preferred",
          },
          timeout: 60000,
          attestation: "none",
        },
      })) as PublicKeyCredential | null;

      if (!credential) throw new Error("No credential returned");
      localStorage.setItem(CRED_KEY, b64encode(credential.rawId));
      setState("success");
      return true;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Registration failed";
      if (msg.includes("cancelled") || msg.includes("abort") || msg.includes("NotAllowedError")) {
        setErrorMsg("Biometric prompt was dismissed. Try again.");
      } else {
        setErrorMsg(msg);
      }
      setState("error");
      return false;
    }
  }, []);

  const authenticateBiometric = useCallback(async (): Promise<boolean> => {
    setState("authenticating");
    setErrorMsg("");
    try {
      const stored = localStorage.getItem(CRED_KEY);
      if (!stored) throw new Error("No credential registered");

      const challenge = crypto.getRandomValues(new Uint8Array(32));
      const hostname = window.location.hostname;

      const assertion = (await navigator.credentials.get({
        publicKey: {
          challenge,
          rpId: hostname,
          allowCredentials: [
            {
              type: "public-key",
               id: b64decode(stored) as unknown as BufferSource,
              transports: ["internal"],
            },
          ],
          userVerification: "required",
          timeout: 60000,
        },
      })) as PublicKeyCredential | null;

      if (!assertion) throw new Error("Authentication failed");
      setState("success");
      return true;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Authentication failed";
      if (msg.includes("cancelled") || msg.includes("abort") || msg.includes("NotAllowedError")) {
        setErrorMsg("Biometric prompt dismissed. Try again.");
      } else {
        setErrorMsg(msg);
      }
      setState("error");
      return false;
    }
  }, []);

  // --- PIN fallback ---
  const registerPin = useCallback(async (pin: string): Promise<boolean> => {
    setState("registering");
    try {
      const hash = await hashPin(pin);
      localStorage.setItem(PIN_KEY, hash);
      setState("success");
      return true;
    } catch {
      setState("error");
      return false;
    }
  }, []);

  const authenticatePin = useCallback(async (pin: string): Promise<boolean> => {
    setState("authenticating");
    try {
      const stored = localStorage.getItem(PIN_KEY);
      if (!stored) throw new Error("No PIN registered");
      const hash = await hashPin(pin);
      if (hash !== stored) throw new Error("Incorrect PIN");
      setState("success");
      return true;
    } catch (err: unknown) {
      setErrorMsg(err instanceof Error ? err.message : "Incorrect PIN");
      setState("error");
      return false;
    }
  }, []);

  const reset = useCallback(() => {
    setState("idle");
    setErrorMsg("");
  }, []);

  const clearAll = useCallback(() => {
    localStorage.removeItem(CRED_KEY);
    localStorage.removeItem(PIN_KEY);
    setState("idle");
    setErrorMsg("");
  }, []);

  return {
    isWebAuthnSupported,
    hasCredential,
    hasPin,
    state,
    errorMsg,
    reset,
    clearAll,
    registerBiometric,
    authenticateBiometric,
    registerPin,
    authenticatePin,
  };
}
