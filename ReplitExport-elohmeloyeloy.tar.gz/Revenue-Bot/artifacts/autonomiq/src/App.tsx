import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, Router as WouterRouter } from 'wouter';

import { Layout } from './components/layout';
import Dashboard from './pages/dashboard';
import Agents from './pages/agents';
import AgentDetail from './pages/agent-detail';
import Opportunities from './pages/opportunities';
import Tasks from './pages/tasks';
import Streams from './pages/streams';
import CodeGenerator from './pages/code';
import Vault from './pages/vault';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: 1,
    },
  },
});

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/agents" component={Agents} />
        <Route path="/agents/:id" component={AgentDetail} />
        <Route path="/opportunities" component={Opportunities} />
        <Route path="/tasks" component={Tasks} />
        <Route path="/streams" component={Streams} />
        <Route path="/code" component={CodeGenerator} />
        <Route path="/vault" component={Vault} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
