import { Link, useLocation } from "wouter";
import { Activity, Bot, Code, LayoutDashboard, LineChart, Lock, Target, Zap } from "lucide-react";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  const navItems = [
    { href: "/", label: "Command Center", icon: LayoutDashboard },
    { href: "/agents", label: "Agent Fleet", icon: Bot },
    { href: "/opportunities", label: "Opportunities", icon: Target },
    { href: "/tasks", label: "Task Queue", icon: Activity },
    { href: "/streams", label: "Revenue Streams", icon: LineChart },
    { href: "/code", label: "Code Generator", icon: Code },
    { href: "/vault", label: "Vault", icon: Lock },
  ];

  return (
    <div className="flex min-h-screen flex-col overflow-hidden bg-background text-foreground md:h-screen md:flex-row">
      <header className="flex h-16 shrink-0 items-center justify-between border-b border-border bg-sidebar px-4 md:hidden">
        <div className="flex items-center gap-2">
          <Zap className="h-5 w-5 text-primary" />
          <span className="font-display text-base font-bold tracking-tight text-white">
            AUTONOM<span className="text-primary">IQ</span>
          </span>
        </div>
        <span className="font-mono text-[10px] uppercase tracking-wider text-primary">System online</span>
      </header>

      {/* Sidebar */}
      <aside className="relative z-10 hidden w-64 shrink-0 flex-col border-r border-border bg-sidebar md:flex">
        {/* Logo/Brand */}
        <div className="h-16 flex items-center px-6 border-b border-border">
          <div className="flex items-center gap-2">
            <Zap className="w-6 h-6 text-primary" />
            <span className="font-display font-bold text-lg tracking-tight text-white uppercase">
              AUTONOM<span className="text-primary">IQ</span>
            </span>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 py-6 px-3 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
            return (
              <Link key={item.href} href={item.href}>
                <div
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-md cursor-pointer transition-colors duration-200 ${
                    isActive
                      ? "bg-primary/10 text-primary font-medium border border-primary/20"
                      : "text-muted-foreground hover:bg-white/5 hover:text-white"
                  }`}
                >
                  <item.icon className={`w-5 h-5 ${isActive ? "text-primary" : ""}`} />
                  <span className="text-sm font-medium">{item.label}</span>
                </div>
              </Link>
            );
          })}
        </nav>

        {/* User / System Status */}
        <div className="p-4 border-t border-border">
          <div className="flex items-center justify-between p-3 rounded-md bg-secondary/50 border border-border/50">
            <div className="flex items-center gap-3">
              <div className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-primary"></span>
              </div>
              <div className="flex flex-col">
                <span className="text-xs font-semibold text-white uppercase font-mono">System Online</span>
                <span className="text-[10px] text-muted-foreground font-mono">ALL SYSTEMS NOMINAL</span>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="relative min-w-0 flex-1 overflow-y-auto pb-16 md:pb-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-primary/5 via-background to-background pointer-events-none -z-10" />
        <div className="mx-auto min-h-full max-w-7xl p-4 sm:p-6 md:p-8">
          {children}
        </div>
      </main>

      <nav className="fixed inset-x-0 bottom-0 z-20 flex gap-1 overflow-x-auto border-t border-border bg-sidebar/95 px-2 py-2 backdrop-blur md:hidden">
        {navItems.map((item) => {
          const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
          return (
            <Link key={item.href} href={item.href} className="min-w-[68px] flex-1">
              <div className={`flex min-h-12 flex-col items-center justify-center gap-1 rounded-md px-1 ${
                isActive ? "bg-primary/10 text-primary" : "text-muted-foreground"
              }`}>
                <item.icon className="h-4 w-4" />
                <span className="whitespace-nowrap text-[9px] font-medium">{item.label}</span>
              </div>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
