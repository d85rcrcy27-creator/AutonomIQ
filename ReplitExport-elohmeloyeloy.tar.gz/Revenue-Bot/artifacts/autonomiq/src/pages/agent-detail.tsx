import { useGetAgent, useListAgentLogs, useRunAgent, getGetAgentQueryKey, getListAgentLogsQueryKey } from "@workspace/api-client-react";
import { useRoute, Link } from "wouter";
import { useEffect, useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Play, SquareTerminal, Terminal } from "lucide-react";
import { formatCurrency } from "../components/ui-helpers";
import { format } from "date-fns";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

export default function AgentDetail() {
  const [, params] = useRoute("/agents/:id");
  const agentId = params?.id ? parseInt(params.id, 10) : 0;
  
  const { data: agent, isLoading: isLoadingAgent } = useGetAgent(agentId, { query: { queryKey: getGetAgentQueryKey(agentId), enabled: !!agentId } });
  const { data: logs, isLoading: isLoadingLogs } = useListAgentLogs(agentId, { query: { queryKey: getListAgentLogsQueryKey(agentId), enabled: !!agentId } });
  const runAgent = useRunAgent();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const [liveOutput, setLiveOutput] = useState<string>("");
  const [isRunning, setIsRunning] = useState(false);
  const logsEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (logsEndRef.current) {
      logsEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [logs, liveOutput]);

  const handleRun = async () => {
    if (!agentId) return;
    setIsRunning(true);
    setLiveOutput("");
    
    toast({
      title: "Agent Stream Started",
      description: "Connecting to agent console...",
    });

    try {
      const response = await fetch(`/api/agents/${agentId}/run`, {
        method: "POST",
      });

      if (!response.body) throw new Error("No response body");

      const reader = response.body.getReader();
      const decoder = new TextDecoder("utf-8");

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split("\n").filter(Boolean);
        
        for (const line of lines) {
          if (line.startsWith("data: ")) {
            try {
              const data = JSON.parse(line.slice(6));
              if (data.done) {
                break;
              }
              if (data.content) {
                setLiveOutput((prev) => prev + data.content);
              }
            } catch (e) {
              // ignore parse errors for partial chunks
            }
          }
        }
      }
    } catch (error) {
      console.error("Stream error:", error);
      toast({
        title: "Stream Disconnected",
        description: "Connection to agent lost.",
        variant: "destructive",
      });
    } finally {
      setIsRunning(false);
      queryClient.invalidateQueries({ queryKey: getGetAgentQueryKey(agentId) });
    }
  };

  if (isLoadingAgent) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!agent) {
    return <div>Agent not found</div>;
  }

  const getLogLevelColor = (level: string) => {
    switch (level) {
      case "error": return "text-destructive";
      case "warn": return "text-amber-500";
      case "success": return "text-primary";
      default: return "text-muted-foreground";
    }
  };

  return (
    <div className="space-y-6 h-full flex flex-col animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center gap-4">
        <Link href="/agents">
          <Button variant="outline" size="icon" className="border-border hover:bg-secondary">
            <ArrowLeft className="w-4 h-4" />
          </Button>
        </Link>
        <div className="flex-1">
          <h1 className="text-2xl font-bold font-display tracking-tight text-white flex items-center gap-3">
            {agent.name}
            <Badge variant="outline" className="border-primary/20 text-primary font-mono uppercase text-[10px]">
              {agent.type}
            </Badge>
          </h1>
          <p className="text-muted-foreground font-mono text-xs mt-1">ID: {agent.id} | STATUS: {agent.status.toUpperCase()}</p>
        </div>
        <div className="flex gap-4 items-center">
          <div className="text-right">
            <div className="text-xs text-muted-foreground uppercase font-mono">Revenue Generated</div>
            <div className="font-bold text-primary font-mono text-lg">{formatCurrency(agent.revenueGenerated)}</div>
          </div>
          <Button 
            onClick={handleRun} 
            disabled={isRunning || agent.status === "running"}
            className="bg-primary text-primary-foreground hover:bg-primary/90 font-mono font-bold"
          >
            {isRunning ? (
              <><div className="w-2 h-2 rounded-full bg-primary-foreground mr-2 animate-pulse" /> RUNNING...</>
            ) : (
              <><Play className="w-4 h-4 mr-2" /> RUN AGENT</>
            )}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1 min-h-0">
        <div className="col-span-1 flex flex-col gap-6">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-sm font-display uppercase tracking-wider text-muted-foreground">Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="text-xs text-muted-foreground font-mono mb-1">Description</div>
                <p className="text-sm text-white">{agent.description}</p>
              </div>
              <div className="grid grid-cols-2 gap-4 border-t border-border pt-4">
                <div>
                  <div className="text-xs text-muted-foreground font-mono mb-1">Tasks Completed</div>
                  <div className="text-xl font-bold text-white font-mono">{agent.tasksCompleted}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground font-mono mb-1">Last Run</div>
                  <div className="text-sm text-white font-mono mt-1">
                    {agent.lastRunAt ? format(new Date(agent.lastRunAt), "MM/dd HH:mm") : "Never"}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="col-span-1 lg:col-span-2 flex flex-col">
          <Card className="bg-[#0c0c0c] border-border flex-1 flex flex-col overflow-hidden relative">
            <CardHeader className="border-b border-border bg-card/50 py-3">
              <CardTitle className="font-mono text-sm flex items-center gap-2 text-primary">
                <Terminal className="w-4 h-4" />
                AGENT_TERMINAL_OUTPUT
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0 flex-1 overflow-y-auto font-mono text-xs relative">
              <div className="p-4 space-y-2">
                {logs?.map((log) => (
                  <div key={log.id} className="flex gap-3">
                    <span className="text-muted-foreground shrink-0 select-none">
                      [{format(new Date(log.createdAt), "HH:mm:ss")}]
                    </span>
                    <span className={getLogLevelColor(log.level)}>{log.message}</span>
                  </div>
                ))}
                
                {liveOutput && (
                  <div className="mt-4 pt-4 border-t border-dashed border-border/50">
                    <div className="text-primary/50 mb-2">--- LIVE STREAM ACTIVE ---</div>
                    <div className="whitespace-pre-wrap text-white/90 leading-relaxed font-mono">
                      {liveOutput}
                      <span className="inline-block w-2 h-3 ml-1 bg-primary animate-pulse" />
                    </div>
                  </div>
                )}
                <div ref={logsEndRef} />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
