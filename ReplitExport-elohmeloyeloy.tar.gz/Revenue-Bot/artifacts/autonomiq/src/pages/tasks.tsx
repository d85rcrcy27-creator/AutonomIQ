import { useListTasks } from "@workspace/api-client-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { formatCurrency } from "../components/ui-helpers";
import { formatDistanceToNow } from "date-fns";
import { Activity, AlertTriangle, CheckCircle2, Clock } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

export default function Tasks() {
  const { data: tasks, isLoading } = useListTasks();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed": return <CheckCircle2 className="w-4 h-4 text-primary" />;
      case "running": return <Activity className="w-4 h-4 text-primary animate-pulse" />;
      case "failed": return <AlertTriangle className="w-4 h-4 text-destructive" />;
      default: return <Clock className="w-4 h-4 text-muted-foreground" />;
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h1 className="text-3xl font-bold font-display tracking-tight text-white mb-2">Task Queue</h1>
        <p className="text-muted-foreground font-mono text-sm">AUTONOMOUS OPERATIONS LOG</p>
      </div>

      <div className="border border-border rounded-lg bg-card overflow-hidden">
        <Table>
          <TableHeader className="bg-secondary/50">
            <TableRow className="border-border hover:bg-transparent">
              <TableHead className="font-mono text-xs uppercase tracking-wider text-muted-foreground">ID</TableHead>
              <TableHead className="font-mono text-xs uppercase tracking-wider text-muted-foreground">Status</TableHead>
              <TableHead className="font-mono text-xs uppercase tracking-wider text-muted-foreground">Task</TableHead>
              <TableHead className="font-mono text-xs uppercase tracking-wider text-muted-foreground">Impact</TableHead>
              <TableHead className="font-mono text-xs uppercase tracking-wider text-muted-foreground">Time</TableHead>
              <TableHead className="font-mono text-xs uppercase tracking-wider text-muted-foreground text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {tasks?.map((task) => (
              <TableRow key={task.id} className="border-border border-b hover:bg-secondary/30 transition-colors">
                <TableCell className="font-mono text-xs text-muted-foreground">#{task.id.toString().padStart(4, '0')}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    {getStatusIcon(task.status)}
                    <span className="font-mono text-xs uppercase capitalize text-white">{task.status}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="font-semibold text-white">{task.title}</div>
                  <div className="text-xs text-muted-foreground truncate max-w-[300px]">{task.description}</div>
                </TableCell>
                <TableCell>
                  <span className={`font-mono font-bold ${task.revenueImpact ? 'text-primary' : 'text-muted-foreground'}`}>
                    {task.revenueImpact ? formatCurrency(task.revenueImpact) : '-'}
                  </span>
                </TableCell>
                <TableCell className="text-xs text-muted-foreground font-mono">
                  {formatDistanceToNow(new Date(task.createdAt), { addSuffix: true })}
                </TableCell>
                <TableCell className="text-right">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" className="h-8 border-border text-xs font-mono">VIEW LOG</Button>
                    </DialogTrigger>
                    <DialogContent className="bg-[#0c0c0c] border-border text-foreground max-w-2xl font-mono">
                      <DialogHeader>
                        <DialogTitle className="text-primary font-display flex items-center gap-2">
                          <Activity className="w-5 h-5" /> Task #{task.id} Execution Log
                        </DialogTitle>
                        <DialogDescription className="font-sans text-muted-foreground">
                          {task.title}
                        </DialogDescription>
                      </DialogHeader>
                      <div className="bg-black border border-border/50 rounded p-4 h-64 overflow-y-auto text-xs whitespace-pre-wrap text-white/90 leading-relaxed mt-4">
                        {task.output || "No output generated for this task."}
                      </div>
                    </DialogContent>
                  </Dialog>
                </TableCell>
              </TableRow>
            ))}
            {tasks?.length === 0 && (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-muted-foreground font-mono">
                  QUEUE EMPTY
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
