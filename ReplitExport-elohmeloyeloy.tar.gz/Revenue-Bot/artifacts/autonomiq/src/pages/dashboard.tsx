import { useGetDashboardSummary, useGetRecentActivity, useListRevenueStreams } from "@workspace/api-client-react";
import { Activity, ArrowUpRight, Bot, DollarSign, Target, TrendingUp, Zap } from "lucide-react";
import { StatCard, formatCurrency } from "../components/ui-helpers";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatDistanceToNow } from "date-fns";
import { Badge } from "@/components/ui/badge";

export default function Dashboard() {
  const { data: summary, isLoading: isLoadingSummary } = useGetDashboardSummary();
  const { data: activities, isLoading: isLoadingActivities } = useGetRecentActivity();
  const { data: streams, isLoading: isLoadingStreams } = useListRevenueStreams();

  if (isLoadingSummary || isLoadingActivities || isLoadingStreams) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  const topStreams = [...(streams ?? [])].sort((a, b) => b.monthlyRevenue - a.monthlyRevenue).slice(0, 4);

  return (
    <div className="space-y-6 sm:space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h1 className="mb-2 font-display text-2xl font-bold tracking-tight text-white sm:text-3xl">Command Center</h1>
        <p className="max-w-xl text-xs leading-5 text-muted-foreground font-mono sm:text-sm">REAL-TIME REVENUE GENERATION FLEET STATUS</p>
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Revenue"
          value={formatCurrency(summary?.totalRevenue || 0)}
          icon={DollarSign}
          description={summary?.revenueGrowthPercent ? `+${summary.revenueGrowthPercent}% from last month` : "Historical comparison unavailable"}
        />
        <StatCard
          title="Monthly Run Rate"
          value={formatCurrency(summary?.monthlyRevenue || 0)}
          icon={TrendingUp}
        />
        <StatCard
          title="Active Agents"
          value={`${summary?.runningAgents || 0} / ${summary?.totalAgents || 0}`}
          icon={Bot}
          description="Fleet operational capacity"
        />
        <StatCard
          title="Tasks Today"
          value={summary?.tasksToday || 0}
          icon={Zap}
          description="Autonomous actions executed"
        />
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3 lg:gap-8">
        <div className="col-span-1 min-w-0 space-y-8 lg:col-span-2">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="font-display flex items-center gap-2">
                <Target className="w-5 h-5 text-primary" />
                Top Revenue Streams
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topStreams.map((stream) => (
                   <div key={stream.id} className="flex flex-col gap-3 rounded-lg border border-border/50 bg-secondary/30 p-4 transition-colors hover:border-primary/30 sm:flex-row sm:items-center sm:justify-between">
                    <div className="flex items-center gap-4">
                      <div className="p-2 rounded-md bg-background border border-border">
                        <Activity className="w-4 h-4 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-white">{stream.name}</h4>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="outline" className="text-[10px] uppercase font-mono border-primary/20 text-primary">
                            {stream.type}
                          </Badge>
                          <span className="text-xs text-muted-foreground font-mono">
                            ID: {stream.id.toString().padStart(4, '0')}
                          </span>
                        </div>
                      </div>
                    </div>
                     <div className="text-left sm:text-right">
                      <div className="font-mono font-bold text-white">
                        {formatCurrency(stream.monthlyRevenue)}<span className="text-muted-foreground text-sm font-sans">/mo</span>
                      </div>
                      <div className="text-xs text-primary font-mono mt-1 flex items-center justify-end gap-1">
                        <ArrowUpRight className="w-3 h-3" /> Active
                      </div>
                    </div>
                  </div>
                ))}
                {topStreams.length === 0 && (
                  <div className="text-center p-8 text-muted-foreground border border-dashed border-border rounded-lg">
                    No active revenue streams. Deploy agents to discover opportunities.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="col-span-1">
          <Card className="bg-card border-border h-full flex flex-col">
            <CardHeader>
              <CardTitle className="font-display flex items-center gap-2">
                <Activity className="w-5 h-5 text-primary" />
                Live Activity Feed
              </CardTitle>
            </CardHeader>
            <CardContent className="flex-1 overflow-y-auto">
              <div className="space-y-6 relative before:absolute before:inset-0 before:ml-2 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-border before:to-transparent">
                {activities?.map((activity) => (
                  <div key={activity.id} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                    <div className="flex items-center justify-center w-5 h-5 rounded-full border border-primary bg-background shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 z-10">
                      <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                    </div>
                    <div className="w-[calc(100%-2.5rem)] md:w-[calc(50%-1.25rem)] p-3 rounded-md bg-secondary/30 border border-border/50">
                           <div className="mb-1 flex flex-wrap items-center justify-between gap-2">
                        <span className="text-xs font-semibold text-white">{activity.title}</span>
                        <span className="text-[10px] text-muted-foreground font-mono">
                          {formatDistanceToNow(new Date(activity.createdAt), { addSuffix: true })}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground">{activity.description}</p>
                    </div>
                  </div>
                ))}
                {(!activities || activities.length === 0) && (
                  <div className="text-center p-4 text-muted-foreground text-sm">
                    Awaiting agent activity...
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
