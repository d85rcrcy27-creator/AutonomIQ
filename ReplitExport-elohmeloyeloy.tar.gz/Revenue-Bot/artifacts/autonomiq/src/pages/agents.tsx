import { 
  useListAgents, 
  useGetAgentStats, 
  useRunAgent, 
  useCreateAgent,
  useUpdateAgent,
  useDeleteAgent,
  getListAgentsQueryKey 
} from "@workspace/api-client-react";
import { Link } from "wouter";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { formatCurrency } from "../components/ui-helpers";
import { Bot, Play, Pause, AlertTriangle, CheckCircle2, ChevronRight, Server, Plus, MoreVertical, Pencil, Trash2 } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

export default function Agents() {
  const { data: agents, isLoading: isLoadingAgents } = useListAgents();
  const { data: stats } = useGetAgentStats();
  
  const runAgent = useRunAgent();
  const createAgent = useCreateAgent();
  const updateAgent = useUpdateAgent();
  const deleteAgent = useDeleteAgent();
  
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [newAgent, setNewAgent] = useState({ name: "", type: "coder" as any, description: "" });

  const handleRun = (id: number) => {
    runAgent.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Agent Started", description: `Agent ${id} is now running.` });
        queryClient.invalidateQueries({ queryKey: getListAgentsQueryKey() });
      },
      onError: (err: any) => {
        toast({ title: "Failed to start agent", description: err.message, variant: "destructive" });
      },
    });
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    createAgent.mutate({ data: newAgent }, {
      onSuccess: () => {
        toast({ title: "Agent created successfully" });
        setIsCreateOpen(false);
        setNewAgent({ name: "", type: "coder", description: "" });
        queryClient.invalidateQueries({ queryKey: getListAgentsQueryKey() });
      }
    });
  };

  const handleDelete = (id: number) => {
    deleteAgent.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Agent decommissioned" });
        queryClient.invalidateQueries({ queryKey: getListAgentsQueryKey() });
      }
    });
  };

  const handlePause = (id: number) => {
    updateAgent.mutate({ id, data: { status: "paused" } }, {
      onSuccess: () => {
        toast({ title: "Agent paused" });
        queryClient.invalidateQueries({ queryKey: getListAgentsQueryKey() });
      }
    });
  };

  if (isLoadingAgents) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "running": return "text-primary border-primary bg-primary/10";
      case "idle": return "text-muted-foreground border-border bg-secondary";
      case "paused": return "text-amber-500 border-amber-500/50 bg-amber-500/10";
      case "error": return "text-destructive border-destructive bg-destructive/10";
      default: return "text-muted-foreground border-border";
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold font-display tracking-tight text-white mb-2">Agent Fleet</h1>
          <p className="text-muted-foreground font-mono text-sm">MANAGE AUTONOMOUS WORKFORCE</p>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-4 bg-secondary/50 border border-border px-4 py-2 rounded-lg">
            <div className="text-center px-4 border-r border-border">
              <div className="text-xs text-muted-foreground uppercase font-mono mb-1">Total</div>
              <div className="font-bold text-white">{stats?.totalAgents || 0}</div>
            </div>
            <div className="text-center px-4 border-r border-border">
              <div className="text-xs text-muted-foreground uppercase font-mono mb-1">Active</div>
              <div className="font-bold text-primary">{stats?.runningAgents || 0}</div>
            </div>
            <div className="text-center px-4">
              <div className="text-xs text-muted-foreground uppercase font-mono mb-1">Generated</div>
              <div className="font-bold text-white">{formatCurrency(stats?.totalRevenueGenerated || 0)}</div>
            </div>
          </div>
          
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary text-primary-foreground font-mono font-bold tracking-wider hover:bg-primary/90">
                <Plus className="w-4 h-4 mr-2" /> DEPLOY AGENT
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-border">
              <DialogHeader>
                <DialogTitle className="font-display tracking-tight">Deploy New Agent</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleCreate} className="space-y-4 pt-4">
                <div className="space-y-2">
                  <label className="text-xs font-mono text-muted-foreground">DESIGNATION</label>
                  <Input 
                    required 
                    value={newAgent.name} 
                    onChange={e => setNewAgent({...newAgent, name: e.target.value})} 
                    className="bg-secondary/50 font-mono" 
                    placeholder="e.g. ALPHA-FINDER-01" 
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-mono text-muted-foreground">CLASS</label>
                  <Select value={newAgent.type} onValueChange={v => setNewAgent({...newAgent, type: v as any})}>
                    <SelectTrigger className="bg-secondary/50 font-mono uppercase">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="finder">Finder (Market Research)</SelectItem>
                      <SelectItem value="coder">Coder (Implementation)</SelectItem>
                      <SelectItem value="manager">Manager (Orchestration)</SelectItem>
                      <SelectItem value="analyst">Analyst (Data processing)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-mono text-muted-foreground">DIRECTIVE</label>
                  <Input 
                    required 
                    value={newAgent.description} 
                    onChange={e => setNewAgent({...newAgent, description: e.target.value})} 
                    className="bg-secondary/50" 
                    placeholder="Primary function description..." 
                  />
                </div>
                <Button type="submit" className="w-full font-bold font-mono" disabled={createAgent.isPending}>
                  {createAgent.isPending ? "INITIALIZING..." : "INITIALIZE UNIT"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {agents?.map((agent) => (
          <Card key={agent.id} className="bg-card border-border hover:border-primary/30 transition-all flex flex-col group relative">
            <CardHeader className="pb-4">
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-lg bg-secondary border border-border group-hover:border-primary/50 transition-colors">
                    <Server className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-lg font-bold text-white">{agent.name}</CardTitle>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="outline" className="text-[10px] uppercase font-mono border-primary/20 text-primary">
                        {agent.type}
                      </Badge>
                      <span className="text-xs text-muted-foreground font-mono">ID: {agent.id}</span>
                    </div>
                  </div>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-white">
                      <MoreVertical className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="bg-popover border-border">
                    <DropdownMenuItem onClick={() => handlePause(agent.id)} disabled={agent.status !== "running"}>
                      <Pause className="w-4 h-4 mr-2" /> Suspend
                    </DropdownMenuItem>
                    <DropdownMenuItem className="text-destructive focus:text-destructive focus:bg-destructive/10" onClick={() => handleDelete(agent.id)}>
                      <Trash2 className="w-4 h-4 mr-2" /> Decommission
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col">
              <p className="text-sm text-muted-foreground mb-6 flex-1">{agent.description}</p>
              
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-background rounded p-3 border border-border">
                  <div className="text-xs text-muted-foreground font-mono mb-1">Tasks</div>
                  <div className="font-mono text-white font-bold">{agent.tasksCompleted}</div>
                </div>
                <div className="bg-background rounded p-3 border border-border">
                  <div className="text-xs text-muted-foreground font-mono mb-1">Revenue</div>
                  <div className="font-mono text-primary font-bold">{formatCurrency(agent.revenueGenerated)}</div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-border">
                <div className="flex items-center">
                  <Badge variant="outline" className={`capitalize font-mono text-xs ${getStatusColor(agent.status)}`}>
                    {agent.status === "running" && <div className="w-1.5 h-1.5 rounded-full bg-primary mr-1.5 animate-pulse" />}
                    {agent.status}
                  </Badge>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    size="icon"
                    variant="outline"
                    className="h-8 w-8 border-border hover:border-primary hover:text-primary transition-colors"
                    onClick={() => handleRun(agent.id)}
                    disabled={runAgent.isPending || agent.status === "running"}
                  >
                    <Play className="w-4 h-4" />
                  </Button>
                  <Link href={`/agents/${agent.id}`}>
                    <Button size="icon" variant="outline" className="h-8 w-8 border-border hover:bg-secondary">
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
