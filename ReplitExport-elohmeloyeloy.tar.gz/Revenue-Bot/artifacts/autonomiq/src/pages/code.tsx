import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Code2, Play, Terminal, Copy, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function CodeGenerator() {
  const [prompt, setPrompt] = useState("");
  const [code, setCode] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    
    setIsGenerating(true);
    setCode("");
    
    try {
      const response = await fetch('/api/ai/generate-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, language: "typescript" })
      });

      if (!response.body) throw new Error("No response body");

      const reader = response.body.getReader();
      const decoder = new TextDecoder("utf-8");

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split("\n").filter(Boolean);
        
        for (const line of lines) {
          if (line.startsWith("data: ")) {
            try {
              const data = JSON.parse(line.slice(6));
              if (data.done) {
                break;
              }
              if (data.content) {
                setCode((prev) => prev + data.content);
              }
            } catch (e) {
              // ignore
            }
          }
        }
      }
    } catch (error) {
      toast({
        title: "Generation Failed",
        description: "Could not connect to code generation stream.",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast({ title: "Copied to clipboard" });
  };

  return (
    <div className="space-y-6 h-full flex flex-col animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-5xl mx-auto">
      <div>
        <h1 className="text-3xl font-bold font-display tracking-tight text-white mb-2">Code Generator</h1>
        <p className="text-muted-foreground font-mono text-sm">AI-ASSISTED DEVELOPMENT TERMINAL</p>
      </div>

      <Card className="bg-card border-border shrink-0">
        <CardContent className="p-4 flex gap-4">
          <Input 
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe the component, script, or integration needed..."
            className="bg-secondary/50 border-border font-mono text-sm text-white placeholder:text-muted-foreground flex-1 h-12"
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleGenerate();
              }
            }}
          />
          <Button 
            onClick={handleGenerate} 
            disabled={isGenerating || !prompt.trim()}
            className="h-12 px-6 bg-primary text-primary-foreground font-bold font-mono tracking-wider"
          >
            {isGenerating ? <div className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin mr-2" /> : <Play className="w-4 h-4 mr-2" />}
            GENERATE
          </Button>
        </CardContent>
      </Card>

      <Card className="bg-[#0c0c0c] border-border flex-1 flex flex-col min-h-[400px] overflow-hidden">
        <CardHeader className="border-b border-border/50 bg-secondary/20 py-3 flex flex-row items-center justify-between space-y-0">
          <CardTitle className="font-mono text-sm flex items-center gap-2 text-primary">
            <Code2 className="w-4 h-4" />
            output.ts
          </CardTitle>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={handleCopy}
            disabled={!code}
            className="h-8 hover:bg-secondary text-muted-foreground hover:text-white"
          >
            {copied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
            {copied ? "COPIED" : "COPY"}
          </Button>
        </CardHeader>
        <CardContent className="p-0 flex-1 relative overflow-auto">
          {code ? (
            <pre className="p-6 font-mono text-sm text-white/90 leading-relaxed whitespace-pre-wrap">
              {code}
              {isGenerating && <span className="inline-block w-2 h-4 ml-1 align-middle bg-primary animate-pulse" />}
            </pre>
          ) : (
            <div className="absolute inset-0 flex items-center justify-center text-muted-foreground font-mono text-sm flex-col gap-4">
              <Terminal className="w-12 h-12 text-border" />
              WAITING FOR PROMPT INPUT...
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
