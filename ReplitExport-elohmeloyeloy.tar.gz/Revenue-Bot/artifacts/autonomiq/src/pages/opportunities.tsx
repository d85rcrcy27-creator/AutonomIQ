import { 
  useListOpportunities, 
  useApproveOpportunity, 
  useRejectOpportunity,
  useCreateOpportunity,
  useDeleteOpportunity,
  getListOpportunitiesQueryKey 
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { formatCurrency } from "../components/ui-helpers";
import { Check, Target, X, Plus, Trash2, Zap, Bot, ExternalLink, RefreshCw, Play, MessageSquare, CreditCard } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

type AutomationJob = {
  id: number;
  source: string;
  sourceUrl: string;
  sourceTitle: string;
  status: string;
  negotiatedOffer: string | null;
  quoteAmountCents: number | null;
  checkoutUrl: string | null;
  paymentStatus: string;
};

export default function Opportunities() {
  const { data: opportunities, isLoading } = useListOpportunities();
  const approveOpp = useApproveOpportunity();
  const rejectOpp = useRejectOpportunity();
  const createOpp = useCreateOpportunity();
  const deleteOpp = useDeleteOpportunity();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isDiscovering, setIsDiscovering] = useState(false);
  const [jobs, setJobs] = useState<AutomationJob[]>([]);
  const [jobBusy, setJobBusy] = useState<number | null>(null);
  const [newOpp, setNewOpp] = useState({ title: "", description: "", category: "saas" as any, estimatedMonthlyRevenue: 0 });

  const loadJobs = async () => {
    try {
      const res = await fetch("/api/automation/jobs");
      if (res.ok) setJobs(await res.json());
    } catch {
      // The opportunity list remains usable if the optional automation panel is offline.
    }
  };

  useEffect(() => {
    void loadJobs();
  }, []);

  const handleApprove = (id: number) => {
    approveOpp.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Opportunity Approved", description: "Executing deployment strategy." });
        queryClient.invalidateQueries({ queryKey: getListOpportunitiesQueryKey() });
      }
    });
  };

  const handleReject = (id: number) => {
    rejectOpp.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListOpportunitiesQueryKey() });
      }
    });
  };

  const handleDelete = (id: number) => {
    deleteOpp.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListOpportunitiesQueryKey() });
      }
    });
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    createOpp.mutate({ data: newOpp }, {
      onSuccess: () => {
        toast({ title: "Opportunity Logged" });
        setIsCreateOpen(false);
        setNewOpp({ title: "", description: "", category: "saas", estimatedMonthlyRevenue: 0 });
        queryClient.invalidateQueries({ queryKey: getListOpportunitiesQueryKey() });
      }
    });
  };

  const handleAIDiscover = async () => {
    setIsDiscovering(true);
    toast({ title: "AI Discovery Initiated", description: "Agents are scanning markets..." });
    try {
      const res = await fetch('/api/ai/discover-opportunities', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ count: 2 })
      });
      // The endpoint uses SSE, but it also creates the entities in DB.
      // So we can just wait for it to finish and refetch.
      if (res.body) {
        const reader = res.body.getReader();
        while (true) {
          const { done } = await reader.read();
          if (done) break;
        }
      }
      queryClient.invalidateQueries({ queryKey: getListOpportunitiesQueryKey() });
      toast({ title: "Discovery Complete", description: "New opportunities identified." });
    } catch (e) {
      toast({ title: "Discovery Failed", variant: "destructive" });
    } finally {
      setIsDiscovering(false);
    }
  };

  const handlePublicDiscover = async () => {
    setIsDiscovering(true);
    toast({ title: "Public Discovery Initiated", description: "Scanning Hacker News and GitHub public APIs — no account registrations required." });
    try {
      const res = await fetch("/api/automation/discover-public", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ source: "all", count: 6 }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Public discovery failed");
      await loadJobs();
      queryClient.invalidateQueries({ queryKey: getListOpportunitiesQueryKey() });
      toast({ title: "Public Discovery Complete", description: `${data.created} new bot handoff${data.created === 1 ? "" : "s"} created.` });
    } catch (error) {
      toast({ title: "Discovery Failed", description: error instanceof Error ? error.message : "Public sources unavailable.", variant: "destructive" });
    } finally {
      setIsDiscovering(false);
    }
  };

  const advanceJob = async (job: AutomationJob) => {
    setJobBusy(job.id);
    try {
      let path = "";
      let body: Record<string, string> | undefined;
      if (job.status === "discovered") {
        path = `/api/automation/jobs/${job.id}/negotiate`;
        body = { customerRequest: job.sourceTitle };
      } else if (job.status === "negotiated") {
        path = `/api/automation/jobs/${job.id}/execute`;
      } else if (job.status === "execution_queued") {
        path = `/api/automation/jobs/${job.id}/run`;
      } else if (job.status === "awaiting_payment" && !job.checkoutUrl) {
        path = `/api/automation/jobs/${job.id}/checkout`;
      } else if (job.status === "awaiting_payment") {
        path = `/api/automation/jobs/${job.id}/payment`;
      }
      if (!path) return;
      const res = await fetch(path, {
        method: path.endsWith("/payment") ? "GET" : "POST",
        headers: body ? { "Content-Type": "application/json" } : undefined,
        body: body ? JSON.stringify(body) : undefined,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Bot handoff failed");
      await loadJobs();
      if (data.checkoutUrl) {
        window.open(data.checkoutUrl, "_blank", "noopener,noreferrer");
        toast({ title: "Stripe Checkout Ready", description: "Customer can complete payment in the hosted checkout." });
      } else if (data.paid) {
        toast({ title: "Payment Verified", description: "Stripe confirms this job is paid." });
      } else {
        toast({ title: "Bot Handoff Complete", description: "The next stage is ready." });
      }
    } catch (error) {
      toast({ title: "Handoff Blocked", description: error instanceof Error ? error.message : "Try again.", variant: "destructive" });
    } finally {
      setJobBusy(null);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  const pendingOpps = opportunities?.filter(o => o.status === "pending") || [];
  const handledOpps = opportunities?.filter(o => o.status !== "pending") || [];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold font-display tracking-tight text-white mb-2">Revenue Opportunities</h1>
          <p className="text-muted-foreground font-mono text-sm">AI-DISCOVERED MARKET INEFFICIENCIES</p>
        </div>
        <div className="flex gap-3">
          <Button
            variant="outline"
            className="border-primary/60 text-primary hover:bg-primary hover:text-primary-foreground font-mono"
            onClick={handlePublicDiscover}
            disabled={isDiscovering}
          >
            {isDiscovering ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : <Bot className="w-4 h-4 mr-2" />}
            PUBLIC DISCOVERY
          </Button>
          <Button 
            variant="outline"
            className="border-primary text-primary hover:bg-primary hover:text-primary-foreground font-mono"
            onClick={handleAIDiscover}
            disabled={isDiscovering}
          >
            {isDiscovering ? <div className="w-4 h-4 mr-2 border-2 border-primary border-t-transparent rounded-full animate-spin" /> : <Zap className="w-4 h-4 mr-2" />}
            RUN DISCOVERY
          </Button>
          
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary text-primary-foreground font-mono tracking-wider">
                <Plus className="w-4 h-4 mr-2" /> MANUAL LOG
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-border">
              <DialogHeader>
                <DialogTitle className="font-display tracking-tight">Log Opportunity</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleCreate} className="space-y-4 pt-4">
                <div className="space-y-2">
                  <label className="text-xs font-mono text-muted-foreground">TITLE</label>
                  <Input required value={newOpp.title} onChange={e => setNewOpp({...newOpp, title: e.target.value})} className="bg-secondary/50 font-mono" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-mono text-muted-foreground">CATEGORY</label>
                  <Select value={newOpp.category} onValueChange={v => setNewOpp({...newOpp, category: v as any})}>
                    <SelectTrigger className="bg-secondary/50 font-mono uppercase">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {['affiliate','saas','content','api','automation','ecommerce','consulting'].map(c => (
                        <SelectItem key={c} value={c}>{c}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-mono text-muted-foreground">EST. MONTHLY REVENUE ($)</label>
                  <Input type="number" required value={newOpp.estimatedMonthlyRevenue} onChange={e => setNewOpp({...newOpp, estimatedMonthlyRevenue: Number(e.target.value)})} className="bg-secondary/50 font-mono" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-mono text-muted-foreground">DESCRIPTION</label>
                  <Input required value={newOpp.description} onChange={e => setNewOpp({...newOpp, description: e.target.value})} className="bg-secondary/50" />
                </div>
                <Button type="submit" className="w-full font-bold font-mono">SUBMIT TO QUEUE</Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card className="bg-card border-primary/20 overflow-hidden">
        <CardHeader className="pb-3 border-b border-border/60">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg text-white flex items-center gap-2">
                <Bot className="w-5 h-5 text-primary" /> Autonomous Delivery Pipeline
              </CardTitle>
              <p className="text-xs text-muted-foreground font-mono mt-1">
                DISCOVER → NEGOTIATE → EXECUTE → CHECKOUT → VERIFY
              </p>
            </div>
            <Button variant="ghost" size="icon" onClick={() => void loadJobs()} className="text-muted-foreground hover:text-white">
              <RefreshCw className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="pt-4">
          {jobs.length === 0 ? (
            <div className="py-6 text-center text-xs text-muted-foreground font-mono">
              NO PUBLIC-SOURCE JOBS YET — RUN PUBLIC DISCOVERY TO START THE BOT HANDOFF
            </div>
          ) : (
            <div className="space-y-3">
              {jobs.slice(0, 6).map(job => {
                const nextLabel =
                  job.status === "discovered" ? "NEGOTIATE" :
                  job.status === "negotiated" ? "QUEUE EXECUTION" :
                  job.status === "execution_queued" ? "RUN EXECUTION BOT" :
                  job.status === "awaiting_payment" && !job.checkoutUrl ? "CREATE CHECKOUT" :
                  job.status === "awaiting_payment" ? "VERIFY PAYMENT" : "PAID";
                const stageIcon =
                  job.status === "paid" ? <Check className="w-3.5 h-3.5" /> :
                  job.status === "awaiting_payment" ? <CreditCard className="w-3.5 h-3.5" /> :
                  job.status === "execution_queued" ? <Play className="w-3.5 h-3.5" /> :
                  job.status === "negotiated" ? <MessageSquare className="w-3.5 h-3.5" /> :
                  <Bot className="w-3.5 h-3.5" />;
                return (
                  <div key={job.id} className="flex flex-col md:flex-row md:items-center gap-3 p-3 rounded-lg border border-border bg-secondary/20">
                    <div className="w-8 h-8 rounded-md bg-primary/10 border border-primary/20 flex items-center justify-center text-primary shrink-0">
                      {stageIcon}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <p className="text-sm text-white font-medium truncate">{job.sourceTitle}</p>
                        <Badge variant="outline" className="text-[9px] font-mono uppercase shrink-0">{job.status.replace("_", " ")}</Badge>
                      </div>
                      <p className="text-[10px] text-muted-foreground font-mono mt-1">
                        {job.source} · {job.quoteAmountCents ? formatCurrency(job.quoteAmountCents / 100) : "QUOTE PENDING"}
                      </p>
                    </div>
                    <div className="flex gap-2 shrink-0">
                      <a href={job.sourceUrl} target="_blank" rel="noreferrer" className="inline-flex items-center justify-center h-9 w-9 rounded-md border border-border text-muted-foreground hover:text-white">
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                      {job.status !== "paid" && (
                        <Button size="sm" onClick={() => void advanceJob(job)} disabled={jobBusy === job.id} className="font-mono text-[10px]">
                          {jobBusy === job.id ? <RefreshCw className="w-3.5 h-3.5 mr-1 animate-spin" /> : null}
                          {nextLabel}
                        </Button>
                      )}
                      {job.status === "paid" && <span className="inline-flex items-center gap-1 text-xs text-primary font-mono"><Check className="w-3.5 h-3.5" /> VERIFIED</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <div className="space-y-4">
        <h2 className="text-lg font-display uppercase tracking-wider text-primary border-b border-border pb-2">Pending Approval ({pendingOpps.length})</h2>
        {pendingOpps.length === 0 ? (
          <div className="p-8 text-center border border-dashed border-border rounded-lg text-muted-foreground font-mono">
            NO PENDING OPPORTUNITIES FOUND IN DATA STREAM
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {pendingOpps.map(opp => (
              <Card key={opp.id} className="bg-card border-primary/20 relative overflow-hidden">
                <div className="absolute top-0 left-0 w-1 h-full bg-primary" />
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <Badge variant="outline" className="mb-2 text-[10px] uppercase font-mono border-primary/20 text-primary">
                        {opp.category}
                      </Badge>
                      <CardTitle className="text-xl text-white">{opp.title}</CardTitle>
                    </div>
                    <div className="text-right">
                      <div className="text-xs text-muted-foreground font-mono mb-1">Est. Monthly</div>
                      <div className="font-bold font-mono text-lg text-primary">{formatCurrency(opp.estimatedMonthlyRevenue)}</div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-6 line-clamp-2">{opp.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground font-mono">
                      Found {formatDistanceToNow(new Date(opp.createdAt), { addSuffix: true })}
                    </span>
                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        className="border-destructive/50 text-destructive hover:bg-destructive hover:text-destructive-foreground"
                        onClick={() => handleReject(opp.id)}
                        disabled={rejectOpp.isPending || approveOpp.isPending}
                      >
                        <X className="w-4 h-4 mr-2" /> REJECT
                      </Button>
                      <Button 
                        className="bg-primary text-primary-foreground hover:bg-primary/90 font-bold"
                        onClick={() => handleApprove(opp.id)}
                        disabled={rejectOpp.isPending || approveOpp.isPending}
                      >
                        <Check className="w-4 h-4 mr-2" /> APPROVE & EXECUTE
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      <div className="space-y-4 pt-8">
        <h2 className="text-lg font-display uppercase tracking-wider text-muted-foreground border-b border-border pb-2">History</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {handledOpps.map(opp => (
            <Card key={opp.id} className="bg-secondary/30 border-border opacity-70 hover:opacity-100 transition-opacity">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-base text-white">{opp.title}</CardTitle>
                    <Badge variant="outline" className={`mt-2 text-[10px] uppercase font-mono ${
                      opp.status === 'approved' ? 'text-primary border-primary/20' : 
                      opp.status === 'rejected' ? 'text-destructive border-destructive/20' : 
                      'text-muted-foreground border-border'
                    }`}>
                      {opp.status}
                    </Badge>
                  </div>
                  <Button variant="ghost" size="icon" className="h-6 w-6 text-muted-foreground hover:text-destructive hover:bg-destructive/10" onClick={() => handleDelete(opp.id)}>
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mt-4">
                  <span className="text-xs text-muted-foreground font-mono">{formatCurrency(opp.estimatedMonthlyRevenue)}/mo</span>
                  <span className="text-xs text-muted-foreground font-mono">
                    {formatDistanceToNow(new Date(opp.updatedAt), { addSuffix: true })}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
