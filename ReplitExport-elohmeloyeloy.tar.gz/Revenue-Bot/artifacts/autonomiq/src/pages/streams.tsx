import { 
  useListRevenueStreams, 
  useCreateRevenueStream, 
  useDeleteRevenueStream,
  useUpdateRevenueStream,
  useAiAnalyzeStream,
  getListRevenueStreamsQueryKey 
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatCurrency } from "../components/ui-helpers";
import { LineChart, Line, ResponsiveContainer } from 'recharts';
import { BarChart3, Zap, Plus, Trash2, Settings, AlertTriangle, TrendingUp, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

const generateSparkline = (base: number) => {
  return Array.from({ length: 7 }, (_, i) => ({
    name: `Day ${i+1}`,
    value: base * (0.8 + Math.random() * 0.4)
  }));
};

function AnalysisDialog({ streamId, streamName }: { streamId: number, streamName: string }) {
  const analysis = useAiAnalyzeStream();

  useEffect(() => {
    if (streamId) analysis.mutate({ data: { streamId } });
  }, [streamId]); // eslint-disable-line react-hooks/exhaustive-deps

  const { data, isPending: isLoading } = analysis;
  
  return (
    <DialogContent className="bg-card border-border max-w-2xl">
      <DialogHeader>
        <DialogTitle className="font-display flex items-center gap-2">
          <Zap className="w-5 h-5 text-primary" /> AI Analysis: {streamName}
        </DialogTitle>
        <DialogDescription>Automated tactical review of revenue channel</DialogDescription>
      </DialogHeader>
      
      {isLoading ? (
        <div className="p-12 flex flex-col items-center justify-center text-muted-foreground font-mono">
          <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin mb-4" />
          ANALYZING DATAPOINTS...
        </div>
      ) : data ? (
        <div className="space-y-6 pt-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 rounded-lg bg-secondary/50 border border-border">
              <div className="text-xs text-muted-foreground font-mono mb-1">PROJECTED GROWTH</div>
              <div className="text-2xl font-bold text-primary font-mono">+{data.projectedGrowth}%</div>
            </div>
            <div className="p-4 rounded-lg bg-secondary/50 border border-border">
              <div className="text-xs text-muted-foreground font-mono mb-1">RISK LEVEL</div>
              <div className="flex items-center gap-2 text-lg font-bold font-mono uppercase text-white">
                {data.riskLevel === 'high' ? <AlertTriangle className="text-destructive w-5 h-5"/> : 
                 data.riskLevel === 'medium' ? <AlertTriangle className="text-amber-500 w-5 h-5"/> : 
                 <CheckCircle2 className="text-primary w-5 h-5"/>}
                {data.riskLevel}
              </div>
            </div>
          </div>
          <div>
            <h4 className="text-sm font-bold text-white mb-2 uppercase font-mono tracking-wider">Summary</h4>
            <p className="text-sm text-muted-foreground leading-relaxed">{data.summary}</p>
          </div>
          <div>
            <h4 className="text-sm font-bold text-white mb-2 uppercase font-mono tracking-wider">Recommendations</h4>
            <ul className="space-y-2">
              {data.recommendations.map((rec, i) => (
                <li key={i} className="flex gap-3 text-sm text-muted-foreground">
                  <TrendingUp className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                  <span>{rec}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      ) : null}
    </DialogContent>
  );
}

export default function Streams() {
  const { data: streams, isLoading } = useListRevenueStreams();
  const createStream = useCreateRevenueStream();
  const updateStream = useUpdateRevenueStream();
  const deleteStream = useDeleteRevenueStream();
  
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [newStream, setNewStream] = useState({ name: "", type: "saas" as any, description: "", monthlyRevenue: 0 });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    createStream.mutate({ data: newStream }, {
      onSuccess: () => {
        toast({ title: "Stream Ingested" });
        setIsCreateOpen(false);
        setNewStream({ name: "", type: "saas", description: "", monthlyRevenue: 0 });
        queryClient.invalidateQueries({ queryKey: getListRevenueStreamsQueryKey() });
      }
    });
  };

  const handleToggleStatus = (id: number, currentStatus: string) => {
    const newStatus = currentStatus === "active" ? "paused" : "active";
    updateStream.mutate({ id, data: { status: newStatus as any } }, {
      onSuccess: () => {
        toast({ title: `Stream ${newStatus}` });
        queryClient.invalidateQueries({ queryKey: getListRevenueStreamsQueryKey() });
      }
    });
  };

  const handleDelete = (id: number) => {
    deleteStream.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Stream Removed" });
        queryClient.invalidateQueries({ queryKey: getListRevenueStreamsQueryKey() });
      }
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  const activeStreams = streams?.filter(s => s.status === 'active') || [];
  const otherStreams = streams?.filter(s => s.status !== 'active') || [];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold font-display tracking-tight text-white mb-2">Revenue Streams</h1>
          <p className="text-muted-foreground font-mono text-sm">ACTIVE CASH FLOW CHANNELS</p>
        </div>
        
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary text-primary-foreground font-mono tracking-wider">
              <Plus className="w-4 h-4 mr-2" /> ADD STREAM
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border">
            <DialogHeader>
              <DialogTitle className="font-display tracking-tight">Manual Stream Entry</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleCreate} className="space-y-4 pt-4">
              <div className="space-y-2">
                <label className="text-xs font-mono text-muted-foreground">IDENTIFIER</label>
                <Input required value={newStream.name} onChange={e => setNewStream({...newStream, name: e.target.value})} className="bg-secondary/50 font-mono" />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-mono text-muted-foreground">TYPE</label>
                <Select value={newStream.type} onValueChange={v => setNewStream({...newStream, type: v as any})}>
                  <SelectTrigger className="bg-secondary/50 font-mono uppercase">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {['affiliate','saas','content','api','automation','ecommerce','consulting'].map(c => (
                      <SelectItem key={c} value={c}>{c}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-mono text-muted-foreground">MONTHLY RUN RATE ($)</label>
                <Input type="number" required value={newStream.monthlyRevenue} onChange={e => setNewStream({...newStream, monthlyRevenue: Number(e.target.value)})} className="bg-secondary/50 font-mono" />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-mono text-muted-foreground">DESCRIPTION</label>
                <Input required value={newStream.description} onChange={e => setNewStream({...newStream, description: e.target.value})} className="bg-secondary/50" />
              </div>
              <Button type="submit" className="w-full font-bold font-mono">REGISTER SOURCE</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {activeStreams.map(stream => (
          <Card key={stream.id} className="bg-card border-border hover:border-primary/50 transition-colors">
            <CardHeader className="pb-2 border-b border-border/50">
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded bg-primary/10 border border-primary/20">
                    <TrendingUp className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-lg font-bold text-white">{stream.name}</CardTitle>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="outline" className="text-[10px] uppercase font-mono border-primary/20 text-primary">
                        {stream.type}
                      </Badge>
                      <span className="text-xs text-muted-foreground font-mono flex items-center">
                        <div className="w-1.5 h-1.5 rounded-full bg-primary mr-1.5 animate-pulse" />
                        ACTIVE
                      </span>
                    </div>
                  </div>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-white">
                      <Settings className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="bg-popover border-border">
                    <DropdownMenuItem onClick={() => handleToggleStatus(stream.id, stream.status)}>
                      Pause Stream
                    </DropdownMenuItem>
                    <DropdownMenuItem className="text-destructive focus:text-destructive focus:bg-destructive/10" onClick={() => handleDelete(stream.id)}>
                      <Trash2 className="w-4 h-4 mr-2" /> Delete Stream
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="grid grid-cols-2 gap-8 mb-6">
                <div>
                  <div className="text-xs text-muted-foreground font-mono mb-1 uppercase">Monthly Run Rate</div>
                  <div className="text-3xl font-bold font-mono text-white neon-text">{formatCurrency(stream.monthlyRevenue)}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground font-mono mb-1 uppercase">Total Generated</div>
                  <div className="text-xl font-bold font-mono text-primary">{formatCurrency(stream.totalRevenue)}</div>
                </div>
              </div>

              <div className="h-24 w-full mb-4">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={generateSparkline(stream.monthlyRevenue)}>
                    <Line type="monotone" dataKey="value" stroke="hsl(var(--primary))" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              <div className="flex justify-between items-center border-t border-border pt-4">
                <p className="text-sm text-muted-foreground truncate flex-1 mr-4">{stream.description}</p>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm" className="border-primary/50 text-primary hover:bg-primary hover:text-primary-foreground font-mono text-xs">
                      <Zap className="w-3 h-3 mr-2" /> AI ANALYSIS
                    </Button>
                  </DialogTrigger>
                  <AnalysisDialog streamId={stream.id} streamName={stream.name} />
                </Dialog>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {otherStreams.length > 0 && (
        <div className="pt-8">
          <h2 className="text-lg font-display uppercase tracking-wider text-muted-foreground border-b border-border pb-2 mb-4">Inactive Streams</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {otherStreams.map(stream => (
              <Card key={stream.id} className="bg-secondary/20 border-border opacity-70 relative group">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-base text-white">{stream.name}</CardTitle>
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                       <Button variant="ghost" size="icon" className="h-6 w-6 text-primary hover:bg-primary/10 hover:text-primary" onClick={() => handleToggleStatus(stream.id, stream.status)}>
                         <Zap className="w-3 h-3" />
                       </Button>
                       <Button variant="ghost" size="icon" className="h-6 w-6 text-destructive hover:bg-destructive/10 hover:text-destructive" onClick={() => handleDelete(stream.id)}>
                         <Trash2 className="w-3 h-3" />
                       </Button>
                    </div>
                  </div>
                  <Badge variant="outline" className="mt-2 text-[10px] w-fit uppercase font-mono text-muted-foreground border-border">
                    {stream.status}
                  </Badge>
                </CardHeader>
                <CardContent>
                  <div className="font-mono font-bold text-muted-foreground">{formatCurrency(stream.monthlyRevenue)}/mo</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
