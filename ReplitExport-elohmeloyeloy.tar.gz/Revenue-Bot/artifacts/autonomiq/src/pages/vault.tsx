/**
 * AutonomIQ Vault
 * ─────────────────────────────────────────────────────────────────────────────
 * Security model:
 * • Authentication uses server-side WebAuthn (FIDO2) — platform authenticator
 *   (Face ID, Touch ID, Windows Hello) required.
 * • The server verifies the cryptographic assertion and issues a 30-minute JWT.
 * • The JWT is held in React state only — never written to localStorage / cookies.
 * • All payment endpoints require the JWT in an Authorization header.
 * • Auto-locks after 5 min of inactivity.
 * ─────────────────────────────────────────────────────────────────────────────
 */
import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Lock, Fingerprint, ShieldCheck, Send, Bitcoin, Banknote,
  CreditCard, ChevronRight, Eye, EyeOff, AlertTriangle,
  Copy, Check, X, ExternalLink, Loader2, RotateCcw,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useGetDashboardSummary } from "@workspace/api-client-react";
import { useVaultAuth, vaultFetch } from "../hooks/use-vault-auth";
import { formatCurrency } from "../components/ui-helpers";

const AUTO_LOCK_MS = 5 * 60_000;

type VaultScreen = "checking" | "locked" | "setup" | "auth" | "unlocked";
type ActionModal = "send" | "bitcoin" | "withdraw" | null;

// ─── Helpers ──────────────────────────────────────────────────────────────────
function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      onClick={() => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 2000); }}
      className="p-1 rounded text-muted-foreground hover:text-white transition-colors"
    >
      {copied ? <Check className="w-3.5 h-3.5 text-primary" /> : <Copy className="w-3.5 h-3.5" />}
    </button>
  );
}

// ─── Lock / Setup Screen ──────────────────────────────────────────────────────
function LockScreen({ isNew, onSetup, onAuth }: { isNew: boolean; onSetup: () => void; onAuth: () => void }) {
  return (
    <motion.div key="lock" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="flex flex-col items-center justify-center h-full min-h-[72vh] text-center">
      <div className="relative mb-8">
        <div className="absolute inset-0 rounded-full bg-primary/20 blur-3xl scale-150" />
        <div className="relative w-28 h-28 rounded-full border-2 border-primary/30 bg-primary/5 flex items-center justify-center">
          <Lock className="w-12 h-12 text-primary" strokeWidth={1.5} />
        </div>
      </div>
      <h1 className="text-4xl font-bold font-display tracking-tight text-white mb-1">VAULT</h1>
      <p className="text-[11px] font-mono text-muted-foreground tracking-[0.25em] mb-10">
        BIOMETRIC SECURED · DEVICE ONLY
      </p>
      <div className="space-y-3 w-64">
        <Button onClick={isNew ? onSetup : onAuth}
          className="w-full bg-primary text-primary-foreground font-mono tracking-wider h-12 text-sm">
          <Fingerprint className="w-4 h-4 mr-2" />
          {isNew ? "SET UP VAULT ACCESS" : "AUTHENTICATE"}
        </Button>
        <p className="text-xs text-muted-foreground font-mono leading-relaxed">
          {isNew
            ? "Uses your device biometrics. Credentials verified server-side via WebAuthn."
            : "Use Face ID, Touch ID, or your device passkey."}
        </p>
      </div>
    </motion.div>
  );
}

// ─── Setup Screen ─────────────────────────────────────────────────────────────
function SetupScreen({
  onSuccess, onBack,
}: { onSuccess: (token: string) => void; onBack: () => void }) {
  const { state, error, register } = useVaultAuth();

  const handleRegister = async () => {
    const token = await register();
    if (token) onSuccess(token);
  };

  return (
    <motion.div key="setup" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
      className="flex flex-col items-center justify-center h-full min-h-[72vh] text-center">
      <div className="w-16 h-16 rounded-full border border-primary/30 bg-primary/5 flex items-center justify-center mb-6">
        <ShieldCheck className="w-8 h-8 text-primary" />
      </div>
      <h2 className="text-2xl font-bold font-display text-white mb-1">Set Up Vault</h2>
      <p className="text-xs text-muted-foreground font-mono mb-8 max-w-xs leading-relaxed">
        Your device biometric (Face ID, Touch ID, Windows Hello) will be registered.
        The private key never leaves your device — only a public key is stored.
      </p>
      <div className="space-y-4 w-64">
        <Button onClick={handleRegister} disabled={state === "loading"}
          className="w-full h-14 bg-primary text-primary-foreground font-mono tracking-wider">
          {state === "loading"
            ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> WAITING FOR DEVICE...</>
            : <><Fingerprint className="w-4 h-4 mr-2" /> REGISTER BIOMETRIC</>}
        </Button>
        {error && (
          <p className="text-xs text-destructive font-mono flex items-center gap-1.5 justify-center">
            <AlertTriangle className="w-3.5 h-3.5 shrink-0" /> {error}
          </p>
        )}
        {state === "error" && (
          <Button onClick={handleRegister} variant="outline" size="sm" className="w-full font-mono text-xs">
            TRY AGAIN
          </Button>
        )}
        <Button variant="ghost" size="sm" onClick={onBack} className="w-full text-muted-foreground font-mono text-xs">
          CANCEL
        </Button>
      </div>
    </motion.div>
  );
}

// ─── Auth Screen ──────────────────────────────────────────────────────────────
function AuthScreen({ onSuccess, onReset }: { onSuccess: (token: string) => void; onReset: () => void }) {
  const { state, error, authenticate, reset } = useVaultAuth();
  const triggered = useRef(false);

  const doAuth = useCallback(async () => {
    reset();
    const token = await authenticate();
    if (token) onSuccess(token);
  }, [authenticate, onSuccess, reset]);

  useEffect(() => {
    if (!triggered.current) { triggered.current = true; doAuth(); }
  }, []); // eslint-disable-line

  return (
    <motion.div key="auth" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
      className="flex flex-col items-center justify-center h-full min-h-[72vh] text-center">
      <div className="relative mb-8">
        <div className="absolute inset-0 rounded-full bg-primary/20 blur-3xl scale-150" />
        <div className="relative w-24 h-24 rounded-full border-2 border-primary/30 bg-primary/5 flex items-center justify-center">
          {state === "loading"
            ? <Loader2 className="w-10 h-10 text-primary animate-spin" />
            : <Fingerprint className="w-10 h-10 text-primary" />}
        </div>
      </div>
      <p className="text-xs text-muted-foreground font-mono tracking-widest mb-6">
        {state === "loading" ? "WAITING FOR DEVICE..." : "VAULT LOCKED"}
      </p>
      {error && (
        <p className="text-xs text-destructive font-mono flex items-center gap-1.5 justify-center mb-4 max-w-xs">
          <AlertTriangle className="w-3.5 h-3.5 shrink-0" /> {error}
        </p>
      )}
      {state !== "loading" && (
        <Button onClick={doAuth} className="w-48 font-mono h-11 mb-2">
          <Fingerprint className="w-4 h-4 mr-2" /> TRY AGAIN
        </Button>
      )}
      <Button variant="ghost" size="sm" onClick={onReset}
        className="mt-6 text-muted-foreground/40 hover:text-destructive font-mono text-xs">
        <RotateCcw className="w-3 h-3 mr-1" /> Reset vault access
      </Button>
    </motion.div>
  );
}

// ─── Send Modal ───────────────────────────────────────────────────────────────
function SendModal({ balance, sessionToken, onClose }: { balance: number; sessionToken: string; onClose: () => void }) {
  const [amount, setAmount] = useState("");
  const [recipient, setRecipient] = useState("");
  const [note, setNote] = useState("");
  const [step, setStep] = useState<"form" | "confirm" | "loading" | "done" | "error">("form");
  const [result, setResult] = useState<{ id: string; amountUsd: number } | null>(null);
  const [errMsg, setErrMsg] = useState("");
  const num = parseFloat(amount) || 0;

  const submit = async () => {
    setStep("loading");
    try {
      const res = await vaultFetch("/api/vault/transfer", sessionToken, {
        method: "POST",
        body: JSON.stringify({ amount: num, destination: recipient, note }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Transfer failed");
      setResult(data);
      setStep("done");
    } catch (e) {
      setErrMsg(e instanceof Error ? e.message : "Transfer failed");
      setStep("error");
    }
  };

  return (
    <DialogContent className="bg-card border-border max-w-md">
      <DialogHeader>
        <DialogTitle className="font-display flex items-center gap-2">
          <Send className="w-5 h-5 text-primary" /> Transfer Funds
        </DialogTitle>
      </DialogHeader>

      {step === "form" && (
        <div className="space-y-4 pt-2">
          <div className="p-3 rounded-lg bg-secondary/30 border border-border">
            <div className="text-xs text-muted-foreground font-mono">AVAILABLE BALANCE</div>
            <div className="text-2xl font-bold font-mono text-white">{formatCurrency(balance)}</div>
          </div>
          <div className="space-y-2">
            <label className="text-xs font-mono text-muted-foreground">RECIPIENT</label>
            <Input value={recipient} onChange={e => setRecipient(e.target.value)}
              placeholder="Bank account, email, or wallet address" className="bg-secondary/50 font-mono" />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-mono text-muted-foreground">AMOUNT (USD)</label>
            <Input type="number" value={amount} onChange={e => setAmount(e.target.value)}
              min={1} max={Math.min(balance, 50000)} step="0.01"
              placeholder="0.00" className="bg-secondary/50 font-mono text-lg" />
            <p className="text-[10px] text-muted-foreground font-mono">Min $1 · Max $50,000 per transaction</p>
          </div>
          <div className="space-y-2">
            <label className="text-xs font-mono text-muted-foreground">NOTE (OPTIONAL)</label>
            <Input value={note} onChange={e => setNote(e.target.value)}
              placeholder="Reference" className="bg-secondary/50" maxLength={200} />
          </div>
          <Button disabled={!recipient.trim() || num < 1 || num > Math.min(balance, 50000)}
            onClick={() => setStep("confirm")} className="w-full font-mono font-bold h-12">
            REVIEW TRANSFER
          </Button>
        </div>
      )}

      {step === "confirm" && (
        <div className="space-y-5 pt-2">
          <div className="rounded-lg border border-border divide-y divide-border">
            {[["To", recipient], ["Amount", formatCurrency(num)], ["Note", note || "—"]].map(([k, v]) => (
              <div key={k} className="flex justify-between px-4 py-3">
                <span className="text-xs font-mono text-muted-foreground">{k}</span>
                <span className="text-sm font-mono text-white font-medium truncate max-w-[60%]">{v}</span>
              </div>
            ))}
          </div>
          <p className="text-xs text-amber-500/80 font-mono flex items-start gap-2">
            <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
            A PaymentIntent is created via Stripe. Connect your Stripe payout account to execute the transfer.
          </p>
          <div className="flex gap-3">
            <Button variant="outline" onClick={() => setStep("form")} className="flex-1 font-mono">BACK</Button>
            <Button onClick={submit} className="flex-1 font-mono bg-primary font-bold">CONFIRM</Button>
          </div>
        </div>
      )}

      {step === "loading" && (
        <div className="flex flex-col items-center py-10 gap-3">
          <Loader2 className="w-8 h-8 text-primary animate-spin" />
          <p className="text-sm text-muted-foreground font-mono">Processing...</p>
        </div>
      )}

      {step === "done" && result && (
        <div className="flex flex-col items-center py-8 gap-4">
          <div className="w-16 h-16 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center">
            <Check className="w-8 h-8 text-primary" />
          </div>
          <div className="text-center">
            <p className="font-bold text-white font-display text-xl">Transfer Initiated</p>
            <p className="text-sm text-muted-foreground mt-1">{formatCurrency(result.amountUsd)} — ID: {result.id.slice(-8)}</p>
          </div>
          <Button onClick={onClose} className="font-mono mt-2 w-32">CLOSE</Button>
        </div>
      )}

      {step === "error" && (
        <div className="flex flex-col items-center py-8 gap-4">
          <AlertTriangle className="w-10 h-10 text-destructive" />
          <p className="text-destructive text-sm font-mono text-center">{errMsg}</p>
          <div className="flex gap-3">
            <Button variant="outline" onClick={() => setStep("form")} className="font-mono">BACK</Button>
            <Button onClick={onClose} className="font-mono">CLOSE</Button>
          </div>
        </div>
      )}
    </DialogContent>
  );
}

// ─── Bitcoin Modal ────────────────────────────────────────────────────────────
function BitcoinModal({ balance, sessionToken, onClose }: { balance: number; sessionToken: string; onClose: () => void }) {
  const [amount, setAmount] = useState("");
  const [walletAddress, setWalletAddress] = useState("");
  const [btcRate, setBtcRate] = useState<number | null>(null);
  const [step, setStep] = useState<"form" | "confirm" | "loading" | "done" | "error">("form");
  const [charge, setCharge] = useState<{ chargeId: string; hostedUrl: string; btcAddress: string | null; expiresAt: string; amountUsd: number } | null>(null);
  const [errMsg, setErrMsg] = useState("");
  const num = parseFloat(amount) || 0;
  const btcAmt = btcRate && num > 0 ? (num / btcRate) : null;

  // Fetch live BTC rate on mount (no auth needed)
  useEffect(() => {
    fetch("/api/vault/bitcoin/rate")
      .then(r => r.json())
      .then((d: { btcUsd?: number }) => { if (d.btcUsd) setBtcRate(d.btcUsd); })
      .catch(() => {});
  }, []);

  const submit = async () => {
    setStep("loading");
    try {
      const res = await vaultFetch("/api/vault/bitcoin/charge", sessionToken, {
        method: "POST",
        body: JSON.stringify({ amount: num }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Charge creation failed");
      setCharge(data);
      setStep("done");
    } catch (e) {
      setErrMsg(e instanceof Error ? e.message : "Failed to create Bitcoin charge");
      setStep("error");
    }
  };

  return (
    <DialogContent className="bg-card border-border max-w-md">
      <DialogHeader>
        <DialogTitle className="font-display flex items-center gap-2">
          <Bitcoin className="w-5 h-5 text-amber-400" /> Convert to Bitcoin
        </DialogTitle>
      </DialogHeader>

      {step === "form" && (
        <div className="space-y-4 pt-2">
          <div className="p-3 rounded-lg bg-amber-500/5 border border-amber-500/20 flex justify-between items-center">
            <div>
              <div className="text-xs text-muted-foreground font-mono">LIVE BTC / USD</div>
              <div className="text-xl font-bold font-mono text-amber-400">
                {btcRate ? `$${btcRate.toLocaleString()}` : <Loader2 className="w-4 h-4 animate-spin inline" />}
              </div>
            </div>
            <Bitcoin className="w-8 h-8 text-amber-400/30" />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-mono text-muted-foreground">AMOUNT TO CONVERT (USD)</label>
            <Input type="number" value={amount} onChange={e => setAmount(e.target.value)}
              min={1} max={Math.min(balance, 50000)} step="0.01"
              placeholder="0.00" className="bg-secondary/50 font-mono text-lg" />
            {btcAmt && btcAmt > 0 && (
              <p className="text-xs text-amber-400 font-mono">≈ {btcAmt.toFixed(8)} BTC</p>
            )}
          </div>
          <div className="space-y-2">
            <label className="text-xs font-mono text-muted-foreground">YOUR BTC WALLET ADDRESS</label>
            <Input value={walletAddress} onChange={e => setWalletAddress(e.target.value)}
              placeholder="bc1q..." className="bg-secondary/50 font-mono text-xs" />
          </div>
          <p className="text-[10px] text-muted-foreground font-mono">
            Powered by Coinbase Commerce. Requires COINBASE_COMMERCE_API_KEY in secrets.
          </p>
          <Button disabled={!walletAddress.trim() || num < 1 || num > Math.min(balance, 50000)}
            onClick={() => setStep("confirm")}
            className="w-full font-mono font-bold h-12 bg-amber-500 hover:bg-amber-400 text-black">
            PREVIEW CONVERSION
          </Button>
        </div>
      )}

      {step === "confirm" && (
        <div className="space-y-5 pt-2">
          <div className="rounded-lg border border-amber-500/20 bg-amber-500/5 divide-y divide-amber-500/10">
            {[
              ["USD Amount", formatCurrency(num)],
              ["BTC Amount", btcAmt ? `≈ ${btcAmt.toFixed(8)} BTC` : "—"],
              ["Rate", btcRate ? `$${btcRate.toLocaleString()} / BTC` : "—"],
              ["Destination", walletAddress.length > 16 ? `${walletAddress.slice(0, 10)}…${walletAddress.slice(-6)}` : walletAddress],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between px-4 py-3">
                <span className="text-xs font-mono text-muted-foreground">{k}</span>
                <span className="text-sm font-mono text-amber-300 font-medium">{v}</span>
              </div>
            ))}
          </div>
          <p className="text-xs text-amber-500/80 font-mono flex items-start gap-2">
            <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
            Bitcoin transactions are irreversible. Double-check your wallet address.
          </p>
          <div className="flex gap-3">
            <Button variant="outline" onClick={() => setStep("form")} className="flex-1 font-mono">BACK</Button>
            <Button onClick={submit} className="flex-1 font-mono bg-amber-500 hover:bg-amber-400 text-black font-bold">CONVERT</Button>
          </div>
        </div>
      )}

      {step === "loading" && (
        <div className="flex flex-col items-center py-10 gap-3">
          <Loader2 className="w-8 h-8 text-amber-400 animate-spin" />
          <p className="text-sm text-muted-foreground font-mono">Creating charge...</p>
        </div>
      )}

      {step === "done" && charge && (
        <div className="space-y-4 pt-2">
          <div className="w-14 h-14 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mx-auto">
            <Bitcoin className="w-7 h-7 text-amber-400" />
          </div>
          <p className="text-center font-bold text-white font-display text-lg">Charge Created</p>
          <div className="rounded-lg border border-amber-500/20 bg-amber-500/5 divide-y divide-amber-500/10 text-sm">
            <div className="flex justify-between px-4 py-3">
              <span className="text-xs font-mono text-muted-foreground">Charge ID</span>
              <span className="text-xs font-mono text-amber-300">{charge.chargeId.slice(0, 16)}…</span>
            </div>
            {charge.btcAddress && (
              <div className="px-4 py-3">
                <div className="text-xs font-mono text-muted-foreground mb-1">BTC DEPOSIT ADDRESS</div>
                <div className="flex items-center gap-2">
                  <code className="text-xs text-amber-400 font-mono flex-1 break-all">{charge.btcAddress}</code>
                  <CopyButton text={charge.btcAddress} />
                </div>
              </div>
            )}
            <div className="flex justify-between px-4 py-3">
              <span className="text-xs font-mono text-muted-foreground">Expires</span>
              <span className="text-xs font-mono text-amber-300">
                {new Date(charge.expiresAt).toLocaleTimeString()}
              </span>
            </div>
          </div>
          {charge.hostedUrl && (
            <a href={charge.hostedUrl} target="_blank" rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 text-xs text-amber-400 hover:text-amber-300 font-mono transition-colors">
              <ExternalLink className="w-3.5 h-3.5" /> OPEN COINBASE HOSTED PAGE
            </a>
          )}
          <Button onClick={onClose} className="w-full font-mono">CLOSE</Button>
        </div>
      )}

      {step === "error" && (
        <div className="flex flex-col items-center py-8 gap-4">
          <AlertTriangle className="w-10 h-10 text-destructive" />
          <p className="text-destructive text-sm font-mono text-center">{errMsg}</p>
          <div className="flex gap-3">
            <Button variant="outline" onClick={() => setStep("form")} className="font-mono">BACK</Button>
            <Button onClick={onClose} className="font-mono">CLOSE</Button>
          </div>
        </div>
      )}
    </DialogContent>
  );
}

// ─── Withdraw Modal ───────────────────────────────────────────────────────────
type WithdrawMethod = "applepay" | "bank" | "paypal" | "cashapp";
const METHODS: { id: WithdrawMethod; label: string; sub: string; icon: React.ReactNode }[] = [
  { id: "applepay", label: "Apple Pay", sub: "Instant · Apple Wallet", icon: <span className="text-white font-semibold text-lg leading-none"></span> },
  { id: "bank", label: "Bank Transfer", sub: "ACH / Wire · 1–3 business days", icon: <Banknote className="w-5 h-5 text-emerald-400" /> },
  { id: "paypal", label: "PayPal", sub: "Instant to PayPal balance", icon: <span className="text-blue-400 font-bold text-sm">PP</span> },
  { id: "cashapp", label: "Cash App", sub: "Instant · $Cashtag", icon: <span className="text-emerald-400 font-bold text-sm">$</span> },
];

function WithdrawModal({ balance, sessionToken, onClose }: { balance: number; sessionToken: string; onClose: () => void }) {
  const [method, setMethod] = useState<WithdrawMethod | null>(null);
  const [amount, setAmount] = useState("");
  const [dest, setDest] = useState("");
  const [step, setStep] = useState<"method" | "form" | "loading" | "done" | "pending" | "error">("method");
  const [errMsg, setErrMsg] = useState("");
  const [resultMsg, setResultMsg] = useState("");
  const num = parseFloat(amount) || 0;
  const selected = METHODS.find(m => m.id === method);

  const submit = async () => {
    if (!method) return;
    setStep("loading");
    try {
      const res = await vaultFetch("/api/vault/withdraw", sessionToken, {
        method: "POST",
        body: JSON.stringify({ amount: num, method, destination: dest }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Withdrawal failed");
      if (data.status === "pending_integration") {
        setResultMsg(data.message ?? "Pending integration setup.");
        setStep("pending");
      } else {
        setStep("done");
      }
    } catch (e) {
      setErrMsg(e instanceof Error ? e.message : "Withdrawal failed");
      setStep("error");
    }
  };

  return (
    <DialogContent className="bg-card border-border max-w-md">
      <DialogHeader>
        <DialogTitle className="font-display flex items-center gap-2">
          <CreditCard className="w-5 h-5 text-primary" /> Withdraw Funds
        </DialogTitle>
      </DialogHeader>

      {step === "method" && (
        <div className="space-y-2 pt-2">
          <p className="text-xs text-muted-foreground font-mono mb-3">SELECT METHOD</p>
          {METHODS.map(m => (
            <button key={m.id} onClick={() => { setMethod(m.id); setStep("form"); }}
              className="w-full flex items-center gap-4 p-4 rounded-lg border border-border bg-secondary/20 hover:bg-secondary/50 hover:border-primary/40 transition-all text-left group">
              <div className="w-10 h-10 rounded-lg bg-secondary border border-border flex items-center justify-center shrink-0">{m.icon}</div>
              <div className="flex-1">
                <div className="text-sm font-medium text-white">{m.label}</div>
                <div className="text-xs text-muted-foreground font-mono">{m.sub}</div>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
            </button>
          ))}
        </div>
      )}

      {step === "form" && selected && (
        <div className="space-y-4 pt-2">
          <button onClick={() => { setMethod(null); setStep("method"); }}
            className="flex items-center gap-1.5 text-xs text-muted-foreground font-mono hover:text-white transition-colors">
            <X className="w-3 h-3" /> {selected.label}
          </button>
          <div className="p-3 rounded-lg bg-secondary/30 border border-border">
            <div className="text-xs text-muted-foreground font-mono">AVAILABLE</div>
            <div className="text-2xl font-bold font-mono text-white">{formatCurrency(balance)}</div>
          </div>
          <div className="space-y-2">
            <label className="text-xs font-mono text-muted-foreground">
              {method === "applepay" ? "APPLE ID / DEVICE" : method === "bank" ? "ROUTING + ACCOUNT #" : method === "paypal" ? "PAYPAL EMAIL" : "$CASHTAG"}
            </label>
            <Input value={dest} onChange={e => setDest(e.target.value)}
              placeholder={method === "applepay" ? "your@apple.id" : method === "bank" ? "Routing + Account" : method === "paypal" ? "you@email.com" : "$YourCashtag"}
              className="bg-secondary/50 font-mono" />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-mono text-muted-foreground">AMOUNT (USD)</label>
            <Input type="number" value={amount} onChange={e => setAmount(e.target.value)}
              min={1} max={Math.min(balance, 50000)} step="0.01"
              placeholder="0.00" className="bg-secondary/50 font-mono text-lg" />
          </div>
          <Button disabled={!dest.trim() || num < 1 || num > Math.min(balance, 50000)}
            onClick={submit} className="w-full font-mono font-bold h-12">
            WITHDRAW {amount ? formatCurrency(num) : ""}
          </Button>
        </div>
      )}

      {step === "loading" && (
        <div className="flex flex-col items-center py-10 gap-3">
          <Loader2 className="w-8 h-8 text-primary animate-spin" />
          <p className="text-sm text-muted-foreground font-mono">Processing...</p>
        </div>
      )}

      {(step === "done" || step === "pending") && (
        <div className="flex flex-col items-center py-8 gap-4">
          <div className={`w-16 h-16 rounded-full flex items-center justify-center border ${step === "done" ? "bg-primary/10 border-primary/30" : "bg-amber-500/10 border-amber-500/30"}`}>
            {step === "done" ? <Check className="w-8 h-8 text-primary" /> : <AlertTriangle className="w-8 h-8 text-amber-400" />}
          </div>
          <div className="text-center">
            <p className="font-bold text-white font-display text-xl">
              {step === "done" ? "Withdrawal Queued" : "Integration Pending"}
            </p>
            <p className="text-sm text-muted-foreground mt-1 max-w-xs leading-relaxed">
              {step === "done" ? `${selected?.label} will process via Stripe.` : resultMsg}
            </p>
          </div>
          <Button onClick={onClose} className="font-mono mt-2 w-32">CLOSE</Button>
        </div>
      )}

      {step === "error" && (
        <div className="flex flex-col items-center py-8 gap-4">
          <AlertTriangle className="w-10 h-10 text-destructive" />
          <p className="text-destructive text-sm font-mono text-center">{errMsg}</p>
          <div className="flex gap-3">
            <Button variant="outline" onClick={() => setStep("form")} className="font-mono">BACK</Button>
            <Button onClick={onClose} className="font-mono">CLOSE</Button>
          </div>
        </div>
      )}
    </DialogContent>
  );
}

// ─── Unlocked Vault ───────────────────────────────────────────────────────────
function UnlockedVault({ sessionToken, onLock, onReset }: { sessionToken: string; onLock: () => void; onReset: () => void }) {
  const { data: summary } = useGetDashboardSummary();
  const [hideBalance, setHideBalance] = useState(false);
  const [activeModal, setActiveModal] = useState<ActionModal>(null);
  const lockTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const balance = summary?.totalRevenue ?? 0;
  const monthly = summary?.monthlyRevenue ?? 0;
  const growth = summary?.revenueGrowthPercent ?? 0;

  const resetTimer = useCallback(() => {
    if (lockTimer.current) clearTimeout(lockTimer.current);
    lockTimer.current = setTimeout(onLock, AUTO_LOCK_MS);
  }, [onLock]);

  useEffect(() => {
    resetTimer();
    const events = ["mousemove", "keydown", "pointerdown"];
    events.forEach(e => window.addEventListener(e, resetTimer));
    return () => {
      if (lockTimer.current) clearTimeout(lockTimer.current);
      events.forEach(e => window.removeEventListener(e, resetTimer));
    };
  }, [resetTimer]);

  const actions = [
    { id: "send" as ActionModal, label: "SEND", icon: Send, color: "text-primary" },
    { id: "bitcoin" as ActionModal, label: "BITCOIN", icon: Bitcoin, color: "text-amber-400" },
    { id: "withdraw" as ActionModal, label: "WITHDRAW", icon: Banknote, color: "text-emerald-400" },
  ];

  return (
    <motion.div key="unlocked" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
      className="space-y-6">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-3xl font-bold font-display tracking-tight text-white mb-1">Vault</h1>
          <div className="flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
            <p className="text-[11px] font-mono text-primary tracking-widest">ACCESS GRANTED · FIDO2 VERIFIED</p>
          </div>
        </div>
        <Button variant="outline" size="sm" onClick={onLock}
          className="border-border font-mono text-xs text-muted-foreground hover:text-white">
          <Lock className="w-3 h-3 mr-1" /> LOCK
        </Button>
      </div>

      {/* Balance Card */}
      <div className="relative rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-card to-card p-7 overflow-hidden">
        <div className="absolute top-0 right-0 w-72 h-72 bg-primary/5 rounded-full blur-3xl -translate-y-1/3 translate-x-1/4 pointer-events-none" />
        <div className="relative">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] text-muted-foreground font-mono tracking-widest">TOTAL VAULT BALANCE</span>
            <button onClick={() => setHideBalance(h => !h)} className="text-muted-foreground hover:text-white transition-colors">
              {hideBalance ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          <div className="text-5xl font-bold font-mono text-white tracking-tight mb-1">
            {hideBalance ? "●●●●●●" : formatCurrency(balance)}
          </div>
          <p className={`text-sm font-mono ${growth >= 0 ? "text-primary" : "text-destructive"}`}>
            {growth >= 0 ? "+" : ""}{growth}% · {hideBalance ? "●●●●" : formatCurrency(monthly)}/mo
          </p>

          <div className="flex gap-3 mt-7">
            {actions.map(({ id, label, icon: Icon, color }) => (
              <button key={id} onClick={() => setActiveModal(id)}
                className="flex-1 flex flex-col items-center gap-2 p-4 rounded-xl border border-border/50 bg-secondary/20 hover:bg-secondary/50 hover:border-primary/30 transition-all group">
                <div className="w-10 h-10 rounded-full border border-border flex items-center justify-center bg-background/50 group-hover:border-primary/40 transition-colors">
                  <Icon className={`w-5 h-5 ${color}`} />
                </div>
                <span className="text-xs font-mono text-muted-foreground group-hover:text-white transition-colors">{label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "ACTIVE STREAMS", value: summary?.activeStreams ?? 0 },
          { label: "MONTHLY RUN RATE", value: hideBalance ? "●●●●" : formatCurrency(monthly) },
          { label: "PENDING OPPS", value: summary?.pendingOpportunities ?? 0 },
        ].map(({ label, value }) => (
          <div key={label} className="p-4 rounded-xl border border-border bg-card">
            <div className="text-[10px] text-muted-foreground font-mono mb-1">{label}</div>
            <div className="text-xl font-bold font-mono text-white">{value}</div>
          </div>
        ))}
      </div>

      {/* Security Notice */}
      <div className="p-4 rounded-xl border border-border/50 bg-secondary/10 flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-primary shrink-0 mt-0.5" />
        <div className="flex-1">
          <p className="text-sm text-white font-medium">FIDO2 / WebAuthn verified</p>
          <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
            Server-side cryptographic verification. Session expires in 30 min. Auto-locks after 5 min of inactivity.
            Payment amounts validated server-side ($1–$50,000 limit).
          </p>
        </div>
        <Button variant="ghost" size="sm" onClick={onReset}
          className="shrink-0 text-xs font-mono text-muted-foreground/40 hover:text-destructive">
          Reset
        </Button>
      </div>

      {/* Payment Modals */}
      <Dialog open={activeModal === "send"} onOpenChange={open => !open && setActiveModal(null)}>
        <SendModal balance={balance} sessionToken={sessionToken} onClose={() => setActiveModal(null)} />
      </Dialog>
      <Dialog open={activeModal === "bitcoin"} onOpenChange={open => !open && setActiveModal(null)}>
        <BitcoinModal balance={balance} sessionToken={sessionToken} onClose={() => setActiveModal(null)} />
      </Dialog>
      <Dialog open={activeModal === "withdraw"} onOpenChange={open => !open && setActiveModal(null)}>
        <WithdrawModal balance={balance} sessionToken={sessionToken} onClose={() => setActiveModal(null)} />
      </Dialog>
    </motion.div>
  );
}

// ─── Main Export ──────────────────────────────────────────────────────────────
export default function Vault() {
  const { clearCredential, checkRegistered } = useVaultAuth();
  const [screen, setScreen] = useState<VaultScreen>("checking");
  const [isNew, setIsNew] = useState(false);
  const [sessionToken, setSessionToken] = useState<string>("");

  // Check registration status on mount
  useEffect(() => {
    checkRegistered().then(registered => {
      setIsNew(!registered);
      setScreen(registered ? "auth" : "locked");
    });
  }, []); // eslint-disable-line

  const handleAuthSuccess = (token: string) => {
    setSessionToken(token);
    setScreen("unlocked");
  };

  const handleLock = () => {
    setSessionToken("");
    setScreen("auth");
  };

  const handleReset = async () => {
    if (sessionToken) await clearCredential(sessionToken);
    setSessionToken("");
    setIsNew(true);
    setScreen("locked");
  };

  if (screen === "checking") {
    return (
      <div className="flex items-center justify-center min-h-[72vh]">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  return (
    <div className="h-full">
      <AnimatePresence mode="wait">
        {screen === "locked" && (
          <LockScreen key="lock" isNew={isNew}
            onSetup={() => setScreen("setup")}
            onAuth={() => setScreen("auth")} />
        )}
        {screen === "setup" && (
          <SetupScreen key="setup" onSuccess={handleAuthSuccess} onBack={() => setScreen("locked")} />
        )}
        {screen === "auth" && (
          <AuthScreen key="auth" onSuccess={handleAuthSuccess} onReset={handleReset} />
        )}
        {screen === "unlocked" && sessionToken && (
          <UnlockedVault key="unlocked" sessionToken={sessionToken} onLock={handleLock} onReset={handleReset} />
        )}
      </AnimatePresence>
    </div>
  );
}
