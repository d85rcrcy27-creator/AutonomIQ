# AutonomIQ

An autonomous AI revenue platform where AI agents discover opportunities, write code, and manage revenue streams with minimal human intervention.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/autonomiq run dev` — run the frontend (port 26089)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string
- Required env: `OPENAI_API_KEY` — OpenAI API key for AI agent features

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite + Wouter + TanStack Query + Tailwind CSS
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- AI: OpenAI SDK (gpt-4o-mini) for agents, opportunity discovery, code generation, stream analysis
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/api-spec/openapi.yaml` — API contract (source of truth)
- `lib/db/src/schema/` — DB tables: agents, opportunities, tasks, revenue-streams, agent-logs
- `artifacts/api-server/src/routes/` — API route handlers (agents, opportunities, tasks, revenue-streams, dashboard, ai)
- `artifacts/api-server/src/lib/openai.ts` — lazy OpenAI client wrapper
- `artifacts/autonomiq/src/` — React frontend (pages: Dashboard, Agents, Opportunities, Tasks, Streams, Code Generator)

## Product

- **Command Center (Dashboard)** — Total revenue, monthly run rate, active agents, tasks today, top streams, live activity feed
- **Agent Fleet** — Manage AI agents (finder/coder/manager/analyst), trigger SSE-streamed runs, view logs
- **Opportunities** — AI-discovered revenue ideas with approve/reject flow; AI discovery via SSE
- **Task Queue** — All agent tasks with status, output, and revenue impact tracking
- **Revenue Streams** — Active/paused streams with monthly revenue, AI analysis per stream
- **Code Generator** — Prompt-driven AI code generation streamed in terminal-style output

## AI Features (require OPENAI_API_KEY)

- Agent runs: each agent type (finder/coder/manager/analyst) gets a specialized system prompt
- Opportunity discovery: streams JSON opportunity objects, auto-saves to DB
- Code generation: streams code for revenue-generating scripts
- Stream analysis: returns summary, recommendations, projected growth %, risk level

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- AI features silently fail gracefully if `OPENAI_API_KEY` is missing (returns error in SSE stream)
- SSE endpoints (`/api/agents/:id/run`, `/api/ai/discover-opportunities`, `/api/ai/generate-code`) use `fetch` + `ReadableStream` on the client — Orval cannot generate typed hooks for streaming endpoints
- After any `lib/*` schema change, run `pnpm run typecheck:libs` before checking artifact packages

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
