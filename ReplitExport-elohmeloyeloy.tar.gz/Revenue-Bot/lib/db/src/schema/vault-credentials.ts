import { pgTable, text, integer, timestamp, boolean } from "drizzle-orm/pg-core";

/**
 * Stores WebAuthn public-key credentials for biometric vault access.
 * One row per registered authenticator (passkey / platform authenticator).
 * Never store the private key — it never leaves the device.
 */
export const vaultCredentialsTable = pgTable("vault_credentials", {
  /** base64url-encoded credential ID assigned by the authenticator */
  id: text("id").primaryKey(),
  /** base64url-encoded CBOR-encoded public key (COSE format) */
  publicKey: text("public_key").notNull(),
  /** Signature counter — incremented each authentication; replay-attack guard */
  counter: integer("counter").notNull().default(0),
  /** JSON-serialized AuthenticatorTransport[] e.g. ["internal"] */
  transports: text("transports").notNull().default("[]"),
  /** True if the credential is multi-device (backed up to iCloud/Google) */
  backedUp: boolean("backed_up").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  lastUsedAt: timestamp("last_used_at", { withTimezone: true }),
});

export type VaultCredential = typeof vaultCredentialsTable.$inferSelect;
