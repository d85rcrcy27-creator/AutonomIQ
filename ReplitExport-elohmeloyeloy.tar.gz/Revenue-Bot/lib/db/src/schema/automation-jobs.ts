import { pgTable, serial, integer, text, timestamp } from "drizzle-orm/pg-core";

/**
 * Durable handoff record for the autonomous revenue pipeline:
 * public discovery → negotiation → execution → Stripe checkout → paid.
 *
 * This deliberately stores no customer payment details. Stripe owns those.
 */
export const automationJobsTable = pgTable("automation_jobs", {
  id: serial("id").primaryKey(),
  opportunityId: integer("opportunity_id").notNull(),
  source: text("source").notNull(),
  sourceUrl: text("source_url").notNull().unique(),
  sourceTitle: text("source_title").notNull(),
  sourceExcerpt: text("source_excerpt").notNull().default(""),
  status: text("status").notNull().default("discovered"),
  negotiationSummary: text("negotiation_summary"),
  negotiatedOffer: text("negotiated_offer"),
  quoteAmountCents: integer("quote_amount_cents"),
  executionTaskId: integer("execution_task_id"),
  deliverable: text("deliverable"),
  discoveryAgentId: integer("discovery_agent_id"),
  negotiationAgentId: integer("negotiation_agent_id"),
  executionAgentId: integer("execution_agent_id"),
  paymentAgentId: integer("payment_agent_id"),
  stripeCheckoutSessionId: text("stripe_checkout_session_id"),
  checkoutUrl: text("checkout_url"),
  paymentStatus: text("payment_status").notNull().default("not_created"),
  paidAt: timestamp("paid_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export type AutomationJob = typeof automationJobsTable.$inferSelect;