import { pgTable, text, serial, timestamp, integer, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const revenueStreamsTable = pgTable("revenue_streams", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // affiliate | saas | content | api | automation | ecommerce | consulting
  status: text("status").notNull().default("active"), // active | paused | inactive
  monthlyRevenue: real("monthly_revenue").notNull().default(0),
  totalRevenue: real("total_revenue").notNull().default(0),
  opportunityId: integer("opportunity_id"),
  description: text("description").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertRevenueStreamSchema = createInsertSchema(revenueStreamsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertRevenueStream = z.infer<typeof insertRevenueStreamSchema>;
export type RevenueStream = typeof revenueStreamsTable.$inferSelect;
