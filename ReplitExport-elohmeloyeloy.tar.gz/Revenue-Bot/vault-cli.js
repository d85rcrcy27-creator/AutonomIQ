const readline = require('readline');
const https = require('https');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// LIVE NODE CONFIGURATION
const LN_HOST = '://lnbits.com'; 
const INVOICE_OR_ADMIN_KEY = process.env.LN_INVOICE_KEY || 'YOUR_KEY_HERE';

let vaultBalanceSats = 0;

function clearScreen() {
  process.stdout.write('\x1Bc');
}

function fetchRealBalance(callback) {
  const options = {
    hostname: LN_HOST,
    port: 443,
    path: '/api/v1/wallet', 
    method: 'GET',
    headers: {
      'X-Api-Key': INVOICE_OR_ADMIN_KEY,
      'Content-Type': 'application/json'
    }
  };

  const req = https.request(options, (res) => {
    let data = '';
    res.on('data', (chunk) => { data += chunk; });
    res.on('end', () => {
      try {
        const json = JSON.parse(data);
        if (res.statusCode === 200 && json.balance !== undefined) {
          vaultBalanceSats = Math.floor(json.balance / 1000);
          callback(null, vaultBalanceSats);
        } else {
          callback(`API Error (${res.statusCode}): ${data}`);
        }
      } catch (err) {
        callback(`Parsing failed: ${err.message}`);
      }
    });
  });

  req.on('error', (err) => { callback(`Network Connection Failed: ${err.message}`); });
  req.end();
}

function showMainMenu() {
  clearScreen();
  console.log('\x1b[36m==================================================\x1b[0m');
  console.log('\x1b[1m⚡ AUTONOMOUS VAULT BOT - TERMINAL CONTROL PANEL ⚡\x1b[0m');
  console.log('\x1b[36m==================================================\x1b[0m');
  console.log(`Current Vault Balance: \x1b[32m${vaultBalanceSats.toLocaleString()} Sats\x1b[0m\n`);
  console.log('Select an action:');
  console.log(' 1) 📤 Cash Out / Withdraw Funds');
  console.log(' 2) 🔄 Check System Logs');
  console.log(' 3) ❌ Exit Panel');
  console.log('\x1b[36m--------------------------------------------------\x1b[0m');
  
  rl.question('Enter option (1-3): ', (choice) => {
    if (choice === '1') {
      showWithdrawalMenu();
    } else if (choice === '2') {
      console.log('\n[Log] All automated vault nodes operating within nominal parameters...');
      pauseAndReturn();
    } else if (choice === '3') {
      console.log('\nGoodbye!');
      process.exit(0);
    } else {
      console.log('\x1b[31m\nInvalid option. Try again.\x1b[0m');
      setTimeout(showMainMenu, 1000);
    }
  });
}

function showWithdrawalMenu() {
  clearScreen();
  console.log('\x1b[33m==================================================\x1b[0m');
  console.log('\x1b[1m📤 WITHDRAWAL ROUTING OPTIONS\x1b[0m');
  console.log('\x1b[33m==================================================\x1b[0m');
  console.log(' 1) ⚡ Keep as Crypto: Send to Lightning Invoice (Instant)');
  console.log(' 2) ⛓  Keep as Crypto: Send to On-Chain BTC Address');
  console.log(' 3) 💳 Liquidate to Cash: Send Direct to Debit Card');
  console.log(' 4) ⬅️  Back to Main Menu');
  console.log('\x1b[33m--------------------------------------------------\x1b[0m');

  rl.question('Select withdrawal method (1-4): ', (method) => {
    switch (method) {
      case '1':
        handleLightningWithdrawal();
        break;
      case '2':
        handleOnChainWithdrawal();
        break;
      case '3':
        handleDebitCardWithdrawal();
        break;
      case '4':
        showMainMenu();
        break;
      default:
        console.log('\x1b[31m\nInvalid option.\x1b[0m');
        setTimeout(showWithdrawalMenu, 1000);
    }
  });
}

function handleLightningWithdrawal() {
  console.log('\n\x1b[33m--- LIGHTNING WITHDRAWAL ---\x1b[0m');
  rl.question('Paste destination BOLT11 Lightning Invoice: ', (invoice) => {
    if (!invoice.startsWith('lnbc')) {
      console.log('\x1b[31m❌ Error: Invalid Lightning Invoice string format.\x1b[0m');
      return pauseAndReturn();
    }
    
    console.log(`\n⏳ Routing payment to external wallet via provider network...`);
    setTimeout(() => {
      console.log('\x1b[32m✔ Success! Invoice settled out of vault assets.\x1b[0m');
      pauseAndReturn();
    }, 1500);
  });
}

function handleOnChainWithdrawal() {
  console.log('\n\x1b[33m--- ON-CHAIN BITCOIN WITHDRAWAL ---\x1b[0m');
  rl.question('Enter recipient BTC Address: ', (address) => {
    if (address.length < 26) {
      console.log('\x1b[31m❌ Error: Invalid Bitcoin address architecture.\x1b[0m');
      return pauseAndReturn();
    }
    
    rl.question('Enter amount of Satoshis to send: ', (amount) => {
      const sats = parseInt(amount, 10);
      if (isNaN(sats) || sats > vaultBalanceSats) {
        console.log('\x1b[31m❌ Error: Insufficient funds or invalid amount entry.\x1b[0m');
        return pauseAndReturn();
      }

      console.log(`\n⏳ Broadcasting transaction to mempool for confirmation...`);
      setTimeout(() => {
        console.log(`\x1b[32m✔ Broadcast Complete.\x1b[0m`);
        pauseAndReturn();
      }, 2000);
    });
  });
}

function handleDebitCardWithdrawal() {
  console.log('\n\x1b[33m--- FIAT OFF-RAMP DEBIT CARD WITHDRAWAL ---\x1b[0m');
  rl.question('Enter amount to cash out (in USD equivalent): $', (dollars) => {
    rl.question('Enter registered target Card Token ID: ', (token) => {
      console.log(`\n⏳ Converting crypto reserves and initiating Card Push Payout ($${dollars})...`);
      setTimeout(() => {
        console.log('\x1b[32m✔ Payment processed through banking settlement networks!\x1b[0m');
        pauseAndReturn();
      }, 2000);
    });
  });
}

function pauseAndReturn() {
  rl.question('\nPress [Enter] key to return to menu...', () => {
    showMainMenu();
  });
}

function startDashboard() {
  clearScreen();
  console.log('🔄 Syncing live vault balances from Lightning Network...');
  
  fetchRealBalance((err, balance) => {
    if (err) {
      console.log(`\n\x1b[31m❌ Balance Sync Failed: ${err}\x1b[0m`);
      console.log('Check your API connection keys or network status.');
      
      rl.question('\nPress [Enter] to try loading anyway with 0 balance...', () => {
        showMainMenu();
      });
    } else {
      showMainMenu();
    }
  });
}

startDashboard();
