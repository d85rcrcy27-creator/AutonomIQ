import { clerkClient, getAuth } from "@clerk/express";
import { ReplitConnectors } from "@replit/connectors-sdk";
import {
  GetRevenueStatusResponse,
  StartRevenueDiscoveryResponse,
} from "@workspace/api-zod";
import { Router, type IRouter, type RequestHandler } from "express";

type StripeAmount = {
  amount?: unknown;
  currency?: unknown;
};

type StripeBalance = {
  livemode?: unknown;
  available?: unknown;
  pending?: unknown;
};

type StripePaymentIntent = {
  id?: unknown;
  amount_received?: unknown;
  currency?: unknown;
  status?: unknown;
  created?: unknown;
  description?: unknown;
  livemode?: unknown;
};

type StripePaymentIntentList = {
  data?: unknown;
  has_more?: unknown;
};

class StripeRequestError extends Error {
  constructor(readonly status: number) {
    super(`Stripe request failed with status ${status}`);
    this.name = "StripeRequestError";
  }
}

const router: IRouter = Router();

const requireRevenueOwner: RequestHandler = async (req, res, next) => {
  const { userId } = getAuth(req);
  if (!userId) {
    res.status(401).json({ error: "Sign in to access revenue discovery." });
    return;
  }

  const ownerEmail = process.env.REVENUE_BOT_OWNER_EMAIL?.trim().toLowerCase();
  if (!ownerEmail) {
    res.status(503).json({
      error: "Revenue dashboard owner access has not been configured.",
    });
    return;
  }

  try {
    const user = await clerkClient.users.getUser(userId);
    const primaryEmail = user.emailAddresses.find(
      (address) => address.id === user.primaryEmailAddressId,
    );
    const isVerifiedOwner =
      primaryEmail?.verification?.status === "verified" &&
      primaryEmail.emailAddress.trim().toLowerCase() === ownerEmail;

    if (!isVerifiedOwner) {
      res.status(403).json({
        error: "This account is not authorized to view the revenue dashboard.",
      });
      return;
    }

    next();
  } catch (error) {
    req.log.error({ err: error }, "Could not verify revenue dashboard owner");
    res.status(503).json({
      error: "Could not verify dashboard access. Please try again.",
    });
  }
};

async function stripeGet<T>(path: string): Promise<T> {
  const response = await new ReplitConnectors().proxy("stripe", path, {
    method: "GET",
  });

  if (!response.ok) {
    throw new StripeRequestError(response.status);
  }

  return (await response.json()) as T;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null;
}

function normalizeStripeAmounts(value: unknown): Array<{
  currency: string;
  amount: number;
}> {
  if (!Array.isArray(value)) {
    throw new Error("Stripe returned an invalid balance response.");
  }

  return value.map((item: StripeAmount) => {
    if (
      typeof item.amount !== "number" ||
      !Number.isInteger(item.amount) ||
      typeof item.currency !== "string"
    ) {
      throw new Error("Stripe returned an invalid balance amount.");
    }

    return {
      currency: item.currency.toUpperCase(),
      amount: item.amount,
    };
  });
}

async function readBalance(): Promise<StripeBalance> {
  const balance = await stripeGet<StripeBalance>("/v1/balance");
  if (typeof balance.livemode !== "boolean") {
    throw new Error("Stripe did not return a verified account mode.");
  }
  return balance;
}

router.get("/revenue/status", requireRevenueOwner, async (req, res): Promise<void> => {
  try {
    const balance = await readBalance();
    const isLive = balance.livemode === true;

    res.json(
      GetRevenueStatusResponse.parse({
        mode: isLive ? "live" : "test",
        canStart: isLive,
        message: isLive
          ? "Live Stripe is connected. Discovery is ready."
          : "Stripe is connected in test mode. Live data is required to start discovery.",
      }),
    );
  } catch (error) {
    req.log.warn(
      {
        status: error instanceof StripeRequestError ? error.status : undefined,
        err: error instanceof StripeRequestError ? undefined : error,
      },
      "Could not check Stripe live-mode availability",
    );
    res.status(503).json({
      error: "Could not reach Stripe. Check the connection and try again.",
    });
  }
});

router.post(
  "/revenue/discovery/start",
  requireRevenueOwner,
  async (req, res): Promise<void> => {
    try {
      const balance = await readBalance();
      if (balance.livemode !== true) {
        res.status(409).json({
          error:
            "Discovery is blocked because this Stripe connection is in test mode. Connect a live account to view real funds.",
        });
        return;
      }

      const paymentList = await stripeGet<StripePaymentIntentList>(
        "/v1/payment_intents?limit=100",
      );
      if (!Array.isArray(paymentList.data)) {
        throw new Error("Stripe returned an invalid payment list.");
      }

      const successfulPayments = (paymentList.data as StripePaymentIntent[]).filter(
        (payment) =>
          payment.livemode === true &&
          payment.status === "succeeded" &&
          typeof payment.id === "string" &&
          typeof payment.currency === "string" &&
          typeof payment.amount_received === "number" &&
          Number.isInteger(payment.amount_received) &&
          typeof payment.created === "number" &&
          Number.isFinite(payment.created),
      );

      const capturedTotals = new Map<
        string,
        { amount: number; paymentCount: number }
      >();
      for (const payment of successfulPayments) {
        const currency = (payment.currency as string).toUpperCase();
        const existing = capturedTotals.get(currency) ?? {
          amount: 0,
          paymentCount: 0,
        };
        existing.amount += payment.amount_received as number;
        existing.paymentCount += 1;
        capturedTotals.set(currency, existing);
      }

      const response = {
        mode: "live" as const,
        discoveredAt: new Date().toISOString(),
        available: normalizeStripeAmounts(balance.available),
        pending: normalizeStripeAmounts(balance.pending),
        captured: Array.from(capturedTotals, ([currency, totals]) => ({
          currency,
          ...totals,
        })),
        inspectedPaymentCount: paymentList.data.length,
        hasMorePayments: paymentList.has_more === true,
        recentPayments: successfulPayments.slice(0, 10).map((payment) => ({
          id: payment.id as string,
          amount: payment.amount_received as number,
          currency: (payment.currency as string).toUpperCase(),
          status: "succeeded",
          createdAt: new Date((payment.created as number) * 1000).toISOString(),
          description:
            typeof payment.description === "string" ? payment.description : null,
        })),
      };

      res.json(StartRevenueDiscoveryResponse.parse(response));
    } catch (error) {
      req.log.error(
        {
          status: error instanceof StripeRequestError ? error.status : undefined,
          err: error instanceof StripeRequestError ? undefined : error,
        },
        "Live Stripe revenue discovery failed",
      );
      res.status(503).json({
        error: "Unable to read live Stripe data. Check the connection and try again.",
      });
    }
  },
);

export default router;
