import { useEffect, useRef, useState, type ReactNode } from 'react';
import { ClerkProvider, Show, SignIn, SignUp, useClerk, useUser } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { useGetRevenueStatus, useStartRevenueDiscovery } from '@workspace/api-client-react';
import { Activity, AlertCircle, ArrowDownToLine, Check, Clock3, LockKeyhole, LogOut, RefreshCw, ShieldCheck, WalletCards } from 'lucide-react';
import { Link, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || '/'
    : path;
}

if (!clerkPubKey) {
  throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in .env file');
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: '#236d5a',
    colorForeground: '#1e383b',
    colorMutedForeground: '#687674',
    colorDanger: '#a54e41',
    colorBackground: '#fbf9f3',
    colorInput: '#f5f2e9',
    colorInputForeground: '#1e383b',
    colorNeutral: '#d9d2c5',
    fontFamily: 'DM Sans, sans-serif',
    borderRadius: '0.8rem',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-[#fbf9f3] rounded-2xl w-[440px] max-w-full overflow-hidden',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'text-[#1e383b] font-semibold tracking-tight',
    headerSubtitle: 'text-[#687674]',
    socialButtonsBlockButtonText: 'text-[#294643] font-semibold',
    formFieldLabel: 'text-[#364d49] font-medium',
    footerActionLink: 'text-[#236d5a] font-semibold',
    footerActionText: 'text-[#687674]',
    dividerText: 'text-[#77817c]',
    identityPreviewEditButton: 'text-[#236d5a] font-semibold',
    formFieldSuccessText: 'text-[#236d5a]',
    alertText: 'text-[#844a39]',
    logoBox: 'h-10',
    logoImage: 'max-h-10',
    socialButtonsBlockButton: 'border-[#d9d2c5] bg-[#f8f6ef] hover:bg-[#f0ede4]',
    formButtonPrimary: 'bg-[#236d5a] text-[#fbf9f3] hover:bg-[#1d5c4c] font-semibold',
    formFieldInput: 'border-[#d9d2c5] bg-[#f8f6ef] text-[#1e383b]',
    footerAction: 'text-[#687674]',
    dividerLine: 'bg-[#e6e0d4]',
    alert: 'border-[#eed3c8] bg-[#faece7]',
    otpCodeFieldInput: 'border-[#d9d2c5] bg-[#f8f6ef] text-[#1e383b]',
    formFieldRow: 'text-[#364d49]',
    main: 'text-[#1e383b]',
  },
};

function formatMoney(amount: number, currency: string) {
  try {
    const fractionDigits = new Intl.NumberFormat('en', { style: 'currency', currency: currency.toUpperCase() })
      .resolvedOptions().maximumFractionDigits ?? 2;
    return new Intl.NumberFormat(undefined, { style: 'currency', currency: currency.toUpperCase() })
      .format(amount / (10 ** fractionDigits));
  } catch {
    return `${currency.toUpperCase()} ${(amount / 100).toFixed(2)}`;
  }
}

function formatTime(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(date);
}

function errorStatus(error: unknown) {
  if (error && typeof error === 'object' && 'status' in error) {
    const status = (error as { status?: unknown }).status;
    return typeof status === 'number' ? status : undefined;
  }
  return undefined;
}

function Brand() {
  return <div className="brand" data-testid="text-brand"><span className="brand-mark"><Activity size={17} strokeWidth={2.3} /></span>revenue.bot</div>;
}

function AuthHeader() {
  const { user } = useUser();
  const { signOut } = useClerk();
  const label = user?.firstName || user?.primaryEmailAddress?.emailAddress || 'Account';
  return <div className="auth-actions">
    <span className="auth-user" title={label}>{label}</span>
    <button className="signout-button" type="button" onClick={() => signOut({ redirectUrl: basePath || '/' })} data-testid="button-sign-out">
      <LogOut size={15} /> <span>Sign out</span>
    </button>
  </div>;
}

function Landing() {
  return <div className="app-shell landing-shell">
    <header className="topbar">
      <Brand />
      <div className="landing-nav">
        <Link href="/sign-in" className="landing-signin" data-testid="link-sign-in">Sign in</Link>
        <Link href="/sign-up" className="landing-signup" data-testid="link-sign-up">Create account</Link>
      </div>
    </header>
    <main className="landing-main">
      <div className="landing-copy">
        <div className="eyebrow"><span className="secure-dot" /> Private revenue intelligence</div>
        <h1 className="landing-title">Know what’s<br />available. <em>Right now.</em></h1>
        <p className="landing-description">A focused, read-only view of your Stripe balance and recent payments. Live funds, clearly separated from pending activity.</p>
        <div className="landing-actions">
          <Link href="/sign-up" className="landing-primary" data-testid="link-get-started">Get started <span aria-hidden="true">→</span></Link>
          <Link href="/sign-in" className="landing-secondary" data-testid="link-existing-account">I have an account</Link>
        </div>
        <div className="landing-trust"><ShieldCheck size={15} /> Read-only by design. Revenue Bot never creates charges or transfers.</div>
      </div>
      <aside className="landing-visual" aria-label="Revenue Bot privacy principles">
        <div className="visual-orbit orbit-one" /><div className="visual-orbit orbit-two" />
        <div className="visual-center"><Activity size={34} strokeWidth={1.6} /></div>
        <div className="visual-caption"><span>BUILT FOR CLARITY</span><span>LIVE DATA ONLY</span></div>
      </aside>
    </main>
  </div>;
}

function AuthLoading() {
  return <main className="auth-state" data-testid="auth-loading">
    <div className="auth-state-card"><Brand /><div className="skeleton auth-skeleton" /><p>Checking your session…</p></div>
  </main>;
}

function AccessLoading() {
  return <div className="app-shell">
    <header className="topbar"><Brand /><div className="top-meta"><span className="secure-dot" /> Verifying access</div></header>
    <main className="workspace access-workspace">
      <div className="eyebrow">Private account</div><h1 className="page-title">Confirming access.</h1>
      <p className="page-subtitle">Your account data stays hidden until access is verified.</p>
      <div className="access-loading-panel"><div className="skeleton skeleton-line" /><div className="skeleton skeleton-line" style={{ width: '44%' }} /></div>
    </main>
  </div>;
}

function AccessProblem({ statusCode, retry }: { statusCode?: number; retry: () => void }) {
  const heading = statusCode === 403
    ? 'This account isn’t on the owner list.'
    : statusCode === 503
      ? 'Owner access hasn’t been configured.'
      : statusCode === 401
        ? 'We couldn’t verify your session.'
        : 'Account access could not be verified.';
  const detail = statusCode === 403
    ? 'Revenue Bot is limited to its verified owner. If you believe this is a mistake, contact the account owner.'
    : statusCode === 503
      ? 'The owner email setting is missing on the server. Ask the administrator to configure access before trying again.'
      : statusCode === 401
        ? 'Your sign-in may have expired. Sign in again to continue.'
        : 'The access check did not complete. Your Stripe data has not been shown.';
  return <div className="app-shell">
    <header className="topbar"><Brand /><AuthHeader /></header>
    <main className="access-main">
      <section className="access-card" data-testid={`access-error-${statusCode ?? 'unknown'}`}>
        <div className="access-symbol"><LockKeyhole size={20} /></div>
        <div className="eyebrow">Access check · {statusCode ?? 'unavailable'}</div>
        <h1>{heading}</h1><p>{detail}</p>
        <div className="access-actions">
          {statusCode === 401 ? <Link href="/sign-in" className="landing-primary" data-testid="link-access-sign-in">Sign in again</Link> :
            <button className="landing-primary" type="button" onClick={retry} data-testid="button-retry-access"><RefreshCw size={15} /> Try again</button>}
          <Link href="/" className="access-home-link" data-testid="link-access-home">Back to Revenue Bot</Link>
        </div>
      </section>
    </main>
  </div>;
}

function MoneyList({ values, tone = '', discovered = false }: { values: { currency: string; amount: number }[]; tone?: string; discovered?: boolean }) {
  if (!values.length) return <div className="no-values" data-testid={`empty-currencies-${tone || 'available'}`}>{discovered ? 'No funds reported' : 'Run discovery to view'}</div>;
  return <div>{values.map((item) => <div className="currency-line" key={item.currency} data-testid={`currency-${tone || 'available'}-${item.currency}`}>
    <span className="currency-code">{item.currency.toUpperCase()}</span>
    <span className={`currency-amount ${tone}`}>{formatMoney(item.amount, item.currency)}</span>
  </div>)}</div>;
}

function Dashboard() {
  const statusQuery = useGetRevenueStatus({ request: { credentials: 'include' } });
  const discoveryMutation = useStartRevenueDiscovery({ request: { credentials: 'include' } });
  const [discovery, setDiscovery] = useState<Awaited<ReturnType<typeof discoveryMutation.mutateAsync>> | null>(null);
  const [blockedStatus, setBlockedStatus] = useState<number | null>(null);
  const status = statusQuery.data;
  const canStart = status?.canStart === true;
  const accessError = statusQuery.isError ? errorStatus(statusQuery.error) : undefined;

  const startDiscovery = () => {
    if (!canStart || discoveryMutation.isPending) return;
    discoveryMutation.mutate(undefined, {
      onSuccess: (result) => setDiscovery(result),
      onError: (error) => {
        const code = errorStatus(error);
        if (code === 401 || code === 403 || code === 503) {
          setDiscovery(null);
          setBlockedStatus(code);
          void statusQuery.refetch();
        }
      },
    });
  };

  if (blockedStatus !== null) return <AccessProblem statusCode={blockedStatus} retry={() => {
    setBlockedStatus(null);
    void statusQuery.refetch();
  }} />;
  if (statusQuery.isError) return <AccessProblem statusCode={accessError} retry={() => { void statusQuery.refetch(); }} />;
  if (statusQuery.isLoading || !status) return <AccessLoading />;

  return <div className="app-shell">
    <header className="topbar">
      <Brand />
      <div className="dashboard-header-meta"><div className="top-meta"><span className="secure-dot" /> Stripe connection</div><AuthHeader /></div>
    </header>
    <main className="workspace">
      <div className="page-intro">
        <div><div className="eyebrow">Account overview / 01</div><h1 className="page-title">Revenue, in focus.</h1><p className="page-subtitle">A clear view of the money moving through your Stripe account.</p></div>
        {discovery && <div className="updated" data-testid="text-last-discovered">Last checked · {formatTime(discovery.discoveredAt)}</div>}
      </div>

      <div className="status-banner" data-testid="status-account">
        <div className="status-icon">{status.mode === 'live' ? <ShieldCheck size={18} /> : <AlertCircle size={18} />}</div>
        <div className="status-copy"><strong>{status.mode === 'live' ? 'Live account connected' : 'Test mode — no live funds'}</strong><span>{status.message}</span></div>
        <span className={`mode-pill ${status.mode === 'test' ? 'test' : ''}`} data-testid="text-account-mode">{status.mode === 'live' ? 'Live data' : 'Test mode'}</span>
      </div>

      {discoveryMutation.isError && <div className="alert" role="alert" data-testid="discovery-error">
        <span><AlertCircle size={16} style={{ verticalAlign: 'middle', marginRight: 7 }} />{errorStatus(discoveryMutation.error) === 403
          ? 'This account is not authorized to view revenue data.'
          : errorStatus(discoveryMutation.error) === 503
            ? 'Owner access is not configured on the server. No revenue data was returned.'
            : errorStatus(discoveryMutation.error) === 401
              ? 'Your session could not be verified. Sign in again to continue.'
              : 'Revenue discovery didn’t complete. Your account has not been changed.'}</span>
        <button className="retry" onClick={startDiscovery} disabled={!canStart || discoveryMutation.isPending || [401, 403, 503].includes(errorStatus(discoveryMutation.error) ?? 0)} data-testid="button-retry-discovery">Retry</button>
      </div>}

      <div className="dashboard-grid">
        <section className="panel hero-panel" aria-label="Available funds">
          <div className="hero-label"><i /> Live balance</div>
          {discovery?.mode === 'live' ? <>
            <p className="hero-heading">Available to your business</p>
            {discovery.available.length ? <div className="currency-list">{discovery.available.map((item) => <p className="hero-amount" key={item.currency} data-testid={`text-live-balance-${item.currency}`}>{formatMoney(item.amount, item.currency)}</p>)}</div> :
              <p className="hero-heading" data-testid="empty-live-balance">No available funds reported</p>}
          </> : <><p className="hero-heading">Available to your business</p><p className="hero-amount" style={{ color: '#a9bdb3', fontSize: 25 }} data-testid="text-balance-not-loaded">{status.mode === 'test' ? 'Unavailable in test mode' : 'Run a live check to see funds'}</p></>}
          <div className="hero-foot">
            <span>{status.mode === 'test' ? 'Live balance unavailable in test mode' : 'Read-only · no money moves'}</span>
            <button className="discover-button" onClick={startDiscovery} disabled={!canStart || discoveryMutation.isPending} data-testid="button-start-discovery">
              {discoveryMutation.isPending ? <><RefreshCw size={15} className="spin" /> Checking…</> : <><RefreshCw size={15} /> Discover revenue</>}
            </button>
          </div>
        </section>
        <section className="panel side-panel">
          <div className="side-head"><h2 className="panel-title">Connection details</h2><span className="lock-tag"><LockKeyhole size={12} /> Read only</span></div>
          <div className="data-row"><span className="data-label">Account mode</span><span className="data-value" data-testid="text-detail-mode">{status.mode.toUpperCase()}</span></div>
          <div className="data-row"><span className="data-label">Discovery</span><span className="data-value">{discoveryMutation.isPending ? 'In progress' : discovery ? 'Complete' : canStart ? 'Ready when you are' : status.mode === 'test' ? 'Unavailable' : 'Not available'}</span></div>
          <div className="data-row"><span className="data-label">Payments inspected</span><span className="data-value" data-testid="text-inspected-count">{discovery ? discovery.inspectedPaymentCount.toLocaleString() : '—'}</span></div>
          <div className="data-row"><span className="data-label">Scope</span><span className="data-value">Balances + payments</span></div>
        </section>
      </div>

      <div className="discovery-top"><h2 className="section-heading">Funds by status</h2><span className="section-note">{discovery ? `As of ${formatTime(discovery.discoveredAt)}` : 'Run discovery to retrieve live figures'}</span></div>
      <div className="totals-grid">
        <section className="panel total-card"><div className="total-head"><i className="total-indicator" /> Available <span className="lock-tag"><LockKeyhole size={11} /></span></div><MoneyList values={discovery?.available ?? []} discovered={!!discovery} /></section>
        <section className="panel total-card"><div className="total-head"><i className="total-indicator pending" /> Pending <span className="lock-tag"><Clock3 size={11} /></span></div><MoneyList values={discovery?.pending ?? []} tone="pending" discovered={!!discovery} /></section>
        <section className="panel total-card"><div className="total-head"><i className="total-indicator captured" /> Captured <span className="lock-tag"><Check size={11} /></span></div>
          {discovery?.captured.length ? discovery.captured.map((item) => <div className="currency-line" key={item.currency} data-testid={`currency-captured-${item.currency}`}><span className="currency-code">{item.currency.toUpperCase()}<div className="currency-count">{item.paymentCount.toLocaleString()} payments</div></span><span className="currency-amount captured">{formatMoney(item.amount, item.currency)}</span></div>) : <div className="no-values" data-testid="empty-currencies-captured">{discovery ? 'No funds reported' : 'Run discovery to view'}</div>}
        </section>
      </div>

      <section className="panel recent-panel">
        <div className="recent-header"><h2 className="panel-title">Recent payments</h2><span className="count-note">{discovery ? `${discovery.inspectedPaymentCount.toLocaleString()} inspected${discovery.hasMorePayments ? ' · more available' : ''}` : 'Live account only'}</span></div>
        {discovery?.recentPayments.length ? <div>{discovery.recentPayments.map((payment) => <div className="payment-row" key={payment.id} data-testid={`row-payment-${payment.id}`}>
          <div className="payment-main"><span className="payment-mark"><WalletCards size={16} /></span><div style={{ minWidth: 0 }}><div className="payment-description">{payment.description || 'Payment'}</div><div className="payment-time">{formatTime(payment.createdAt)} · {payment.currency.toUpperCase()}</div></div></div>
          <span className={`payment-state ${payment.status.toLowerCase() === 'succeeded' ? '' : 'other'}`}>{payment.status}</span>
          <span className="payment-amount">{formatMoney(payment.amount, payment.currency)}</span>
        </div>)}</div> : <div className="empty-state" data-testid="empty-recent-payments"><ArrowDownToLine size={19} /><strong>{discovery ? 'No recent payments found' : 'Your payment activity will appear here'}</strong><span>{discovery ? 'The live account returned no recent payments in this discovery.' : 'Start a live discovery to inspect recent payments from Stripe.'}</span></div>}
      </section>
      <div className="footer-note"><ShieldCheck size={14} /> Read-only discovery. No charges, transfers, or Stripe records are created.</div>
    </main>
  </div>;
}

function SignInPage() {
  return <div className="auth-page"><Link href="/" className="auth-home-link" data-testid="link-auth-home"><Brand /></Link><SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} /></div>;
}

function SignUpPage() {
  return <div className="auth-page"><Link href="/" className="auth-home-link" data-testid="link-auth-home"><Brand /></Link><SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} /></div>;
}

function HomeRoute() {
  const { isLoaded } = useUser();
  if (!isLoaded) return <AuthLoading />;
  return <>
    <Show when="signed-in"><Dashboard /></Show>
    <Show when="signed-out"><Landing /></Show>
  </>;
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const cache = useQueryClient();
  const prevUserIdRef = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (prevUserIdRef.current !== undefined && prevUserIdRef.current !== userId) {
        cache.clear();
      }
      prevUserIdRef.current = userId;
    });
    return unsubscribe;
  }, [addListener, cache]);

  return null;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();
  return <ClerkProvider
    publishableKey={clerkPubKey}
    proxyUrl={clerkProxyUrl}
    appearance={clerkAppearance}
    signInUrl={`${basePath}/sign-in`}
    signUpUrl={`${basePath}/sign-up`}
    localization={{
      signIn: { start: { title: 'Welcome back', subtitle: 'Sign in to access your revenue view' } },
      signUp: { start: { title: 'Create your account', subtitle: 'Get a clear view of your business revenue' } },
    }}
    routerPush={(to) => setLocation(stripBase(to))}
    routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
  >
    <ClerkQueryClientCacheInvalidator />
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={HomeRoute} />
        <Route path="/sign-in/*?" component={SignInPage} />
        <Route path="/sign-up/*?" component={SignUpPage} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  </ClerkProvider>;
}

function App() {
  return <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <WouterRouter base={basePath}>
        <ClerkProviderWithRoutes />
      </WouterRouter>
      <Toaster />
    </TooltipProvider>
  </QueryClientProvider>;
}

export default App;
