---
name: Solana custody model
description: Product constraint for private-key handling in Solana Vault.
---

Solana Vault is intended to remain non-custodial. Wallet owners control their keys; the app stores them only in device secure storage and does not send them to a server.

**Why:** The user chose a non-custodial Solana app instead of app-managed custody.

**How to apply:** Keep key generation, backup, import, and transaction signing on the user's device. Do not add server-side private-key storage or automated transfers.
