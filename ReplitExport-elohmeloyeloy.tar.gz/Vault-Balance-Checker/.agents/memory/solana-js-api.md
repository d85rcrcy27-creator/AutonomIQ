---
name: Solana JS API compatibility
description: Solana client library version choice for this Expo app.
---

Use the web3.js v1 API expected by the wallet implementation. The newer v2 API changes keypair methods and uses different typed RPC results.

**Why:** Resolving the latest major version caused type incompatibilities in the Expo wallet client.

**How to apply:** Keep the library version explicit and check the selected major version before changing Solana client code.
