import { useState } from 'react';
import {
  ActivityIndicator,
  Platform,
  Pressable,
  RefreshControl,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Feather, Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { useColors } from '@/hooks/useColors';
import { useWallets, type WalletMetadata } from '@/src/context/wallet-context';
import { ReceiveSheet, SendSheet } from '@/components/WalletSheets';
import { solFromLamports } from '@/src/lib/solana';

function shortAddress(address: string) {
  return `${address.slice(0, 5)}…${address.slice(-5)}`;
}

export default function VaultScreen() {
  const colors = useColors();
  const router = useRouter();
  const {
    wallets,
    balances,
    ready,
    creating,
    refreshing,
    error,
    balanceError,
    isNativeDevice,
    createWallet,
    refreshBalances,
  } = useWallets();
  const [receiveWallet, setReceiveWallet] = useState<WalletMetadata | null>(null);
  const [sendWallet, setSendWallet] = useState<WalletMetadata | null>(null);
  const [expandedWallet, setExpandedWallet] = useState<string | null>(null);
  const totalLamports = wallets.reduce(
    (sum, wallet) => sum + (balances[wallet.address]?.lamports ?? 0),
    0,
  );
  const totalTokens = wallets.reduce(
    (sum, wallet) => sum + (balances[wallet.address]?.tokens.length ?? 0),
    0,
  );
  const totalBalanceReady =
    wallets.length > 0 &&
    wallets.every((wallet) => balances[wallet.address] !== undefined);

  const onCreateWallet = async () => {
    try {
      await createWallet();
    } catch {
      // The context exposes the actionable error state.
    }
  };

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={[
          styles.content,
          Platform.OS === 'web' ? styles.webInsets : null,
        ]}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => void refreshBalances().catch(() => undefined)}
            tintColor={colors.primary}
          />
        }
      >
        <View style={styles.topBar}>
          <View style={styles.brandRow}>
            <View style={[styles.brandMark, { backgroundColor: colors.secondary }]}>
              <Ionicons name="shield-checkmark" size={19} color={colors.primary} />
            </View>
            <View>
              <Text style={[styles.eyebrow, { color: colors.mutedForeground }]}>
                SOLANA MAINNET
              </Text>
              <Text style={[styles.brandName, { color: colors.foreground }]}>Vault</Text>
            </View>
          </View>
          <Pressable
            accessibilityRole="button"
            testID="refresh-balances"
            onPress={() => void refreshBalances().catch(() => undefined)}
            style={[styles.iconButton, { backgroundColor: colors.card, borderColor: colors.border }]}
          >
            {refreshing ? (
              <ActivityIndicator size="small" color={colors.primary} />
            ) : (
              <Feather name="refresh-cw" size={18} color={colors.foreground} />
            )}
          </Pressable>
        </View>

        <LinearGradient
          colors={[colors.card, colors.secondary]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[styles.balanceCard, { borderColor: colors.border }]}
        >
          <View style={styles.balanceCardTop}>
            <Text style={[styles.eyebrow, { color: colors.mutedForeground }]}>
              TOTAL VAULT BALANCE
            </Text>
            <View style={[styles.networkPill, { backgroundColor: colors.background }]}>
              <View style={[styles.liveDot, { backgroundColor: wallets.length ? colors.primary : colors.mutedForeground }]} />
              <Text style={[styles.networkText, { color: colors.foreground }]}>
                {wallets.length ? 'Live' : 'No wallet'}
              </Text>
            </View>
          </View>
          <View style={styles.balanceLine}>
            <Text style={[styles.balanceAmount, { color: colors.foreground }]}>
              {ready && totalBalanceReady ? solFromLamports(totalLamports) : '—'}
            </Text>
            <Text style={[styles.balanceUnit, { color: colors.primary }]}>SOL</Text>
          </View>
          <Text style={[styles.balanceCaption, { color: colors.mutedForeground }]}>
            {wallets.length
              ? `Across ${wallets.length} ${wallets.length === 1 ? 'wallet' : 'wallets'} · ${totalTokens} SPL ${totalTokens === 1 ? 'token' : 'tokens'}`
              : 'Add or import a wallet to view its real balance.'}
          </Text>
          <View style={[styles.balanceDivider, { backgroundColor: colors.border }]} />
          <View style={styles.feeNote}>
            <Feather name="info" size={14} color={colors.accent} />
            <Text style={[styles.feeText, { color: colors.mutedForeground }]}>
              SOL pays network fees; creating token accounts can also need SOL.
            </Text>
          </View>
        </LinearGradient>

        {Platform.OS === 'web' ? (
          <View style={[styles.notice, { backgroundColor: colors.secondary }]}>
            <Feather name="smartphone" size={17} color={colors.primary} />
            <Text style={[styles.noticeText, { color: colors.foreground }]}>
              Open this app on iOS or Android to create or import wallets securely.
            </Text>
          </View>
        ) : null}

        {balanceError || error ? (
          <View style={[styles.errorBanner, { backgroundColor: colors.card, borderColor: colors.destructive }]}>
            <Text style={[styles.errorText, { color: colors.destructive }]}>{balanceError ?? error}</Text>
            <Pressable accessibilityRole="button" onPress={() => void refreshBalances().catch(() => undefined)}>
              <Text style={[styles.retryText, { color: colors.primary }]}>Retry</Text>
            </Pressable>
          </View>
        ) : null}

        <View style={styles.sectionHeader}>
          <View>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Your wallets</Text>
            <Text style={[styles.sectionSubtitle, { color: colors.mutedForeground }]}>
              {wallets.length ? 'Keys stay on this device' : 'No wallet loaded'}
            </Text>
          </View>
          <Pressable
            accessibilityRole="button"
            testID="create-wallet"
            disabled={!isNativeDevice || creating}
            onPress={() => void onCreateWallet()}
            style={[
              styles.addButton,
              { backgroundColor: colors.primary, opacity: !isNativeDevice || creating ? 0.5 : 1 },
            ]}
          >
            {creating ? (
              <ActivityIndicator size="small" color={colors.primaryForeground} />
            ) : (
              <>
                <Feather name="plus" size={16} color={colors.primaryForeground} />
                <Text style={[styles.addButtonText, { color: colors.primaryForeground }]}>New wallet</Text>
              </>
            )}
          </Pressable>
        </View>

        {!ready ? (
          <View style={[styles.emptyCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <ActivityIndicator color={colors.primary} />
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Loading wallets from this device…</Text>
          </View>
        ) : wallets.length === 0 ? (
          <View style={[styles.emptyCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={[styles.emptyIcon, { backgroundColor: colors.secondary }]}>
              <Feather name="layers" size={22} color={colors.primary} />
            </View>
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Start your vault</Text>
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
              Create an on-device Solana wallet, then share its address to receive SOL and SPL tokens.
            </Text>
            <Pressable
              accessibilityRole="button"
              testID="create-first-wallet"
              disabled={!isNativeDevice || creating}
              onPress={() => void onCreateWallet()}
              style={[styles.primaryButton, { backgroundColor: colors.primary, opacity: !isNativeDevice || creating ? 0.5 : 1 }]}
            >
              <Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>
                {creating ? 'Creating…' : 'Create first wallet'}
              </Text>
            </Pressable>
          </View>
        ) : (
          <View style={styles.walletList}>
            <View style={[styles.backupReminder, { backgroundColor: colors.secondary }]}>
              <Feather name="key" size={16} color={colors.accent} />
              <Text style={[styles.backupReminderText, { color: colors.foreground }]}>
                Back up each key offline before adding funds.
              </Text>
              <Pressable
                accessibilityRole="button"
                onPress={() => router.push('/(tabs)/security')}
                hitSlop={8}
              >
                <Text style={[styles.retryText, { color: colors.primary }]}>Backup</Text>
              </Pressable>
            </View>
            {wallets.map((wallet, index) => {
              const balance = balances[wallet.address];
              const expanded = expandedWallet === wallet.address;
              return (
                <View
                  key={wallet.address}
                  style={[styles.walletCard, { backgroundColor: colors.card, borderColor: colors.border }]}
                >
                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel={`Show tokens for ${wallet.name}`}
                    onPress={() => setExpandedWallet(expanded ? null : wallet.address)}
                    style={styles.walletCardMain}
                  >
                    <View style={[styles.walletIcon, { backgroundColor: colors.secondary }]}>
                      <Text style={[styles.walletNumber, { color: colors.primary }]}>{String(index + 1).padStart(2, '0')}</Text>
                    </View>
                    <View style={styles.walletIdentity}>
                      <Text style={[styles.walletName, { color: colors.foreground }]}>{wallet.name}</Text>
                      <Text style={[styles.walletAddress, { color: colors.mutedForeground }]}>
                        {shortAddress(wallet.address)}
                      </Text>
                    </View>
                    <View style={styles.walletBalance}>
                      <Text style={[styles.walletAmount, { color: colors.foreground }]}>
                        {balance ? solFromLamports(balance.lamports) : '—'}
                      </Text>
                      <Text style={[styles.walletUnit, { color: colors.mutedForeground }]}>SOL</Text>
                    </View>
                  </Pressable>
                  {expanded ? (
                    <View style={[styles.tokenPanel, { borderTopColor: colors.border }]}>
                      <Text style={[styles.tokenHeading, { color: colors.mutedForeground }]}>SPL TOKEN BALANCES</Text>
                      {balance?.tokens.length ? balance.tokens.map((token) => (
                        <View key={token.mint} style={styles.tokenRow}>
                          <View style={[styles.tokenDot, { backgroundColor: colors.accent }]} />
                          <Text style={[styles.tokenName, { color: colors.foreground }]}>{token.name}</Text>
                          <Text style={[styles.tokenAmount, { color: colors.foreground }]}>{token.amount}</Text>
                        </View>
                      )) : (
                        <Text style={[styles.noTokens, { color: colors.mutedForeground }]}>
                          {balance ? 'No SPL token balances found.' : 'Refresh to load token balances.'}
                        </Text>
                      )}
                    </View>
                  ) : null}
                  <View style={[styles.walletActions, { borderTopColor: colors.border }]}>
                    <Pressable
                      accessibilityRole="button"
                      testID={`receive-${index}`}
                      onPress={() => setReceiveWallet(wallet)}
                      style={[styles.walletAction, { backgroundColor: colors.secondary }]}
                    >
                      <Feather name="arrow-down-left" size={15} color={colors.primary} />
                      <Text style={[styles.walletActionText, { color: colors.foreground }]}>Receive</Text>
                    </Pressable>
                    <Pressable
                      accessibilityRole="button"
                      testID={`send-${index}`}
                      onPress={() => setSendWallet(wallet)}
                      style={[styles.walletAction, { backgroundColor: colors.secondary }]}
                    >
                      <Feather name="arrow-up-right" size={15} color={colors.primary} />
                      <Text style={[styles.walletActionText, { color: colors.foreground }]}>Send SOL</Text>
                    </Pressable>
                  </View>
                </View>
              );
            })}
          </View>
        )}
        <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>
          Non-custodial wallet. This app cannot recover lost keys or reverse a confirmed transfer.
        </Text>
      </ScrollView>
      <ReceiveSheet wallet={receiveWallet} onClose={() => setReceiveWallet(null)} />
      <SendSheet wallet={sendWallet} onClose={() => setSendWallet(null)} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1 },
  content: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 36, gap: 22 },
  webInsets: { paddingTop: 67, paddingBottom: 120 },
  topBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  brandRow: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  brandMark: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  eyebrow: { fontSize: 10, fontWeight: '700', letterSpacing: 1.5 },
  brandName: { fontSize: 22, fontWeight: '700', marginTop: 1 },
  iconButton: { width: 42, height: 42, borderRadius: 15, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  balanceCard: { borderRadius: 26, padding: 21, borderWidth: 1, overflow: 'hidden' },
  balanceCardTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  networkPill: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 20 },
  liveDot: { width: 6, height: 6, borderRadius: 3 },
  networkText: { fontSize: 11, fontWeight: '600' },
  balanceLine: { flexDirection: 'row', alignItems: 'baseline', gap: 9, marginTop: 16 },
  balanceAmount: { fontSize: 43, fontWeight: '700', letterSpacing: -1.8 },
  balanceUnit: { fontSize: 16, fontWeight: '700' },
  balanceCaption: { fontSize: 13, marginTop: 5 },
  balanceDivider: { height: 1, marginTop: 18, marginBottom: 13 },
  feeNote: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  feeText: { fontSize: 12 },
  notice: { flexDirection: 'row', gap: 10, alignItems: 'center', padding: 14, borderRadius: 16 },
  noticeText: { flex: 1, fontSize: 13, lineHeight: 19 },
  errorBanner: { borderWidth: 1, borderRadius: 14, padding: 13, flexDirection: 'row', gap: 12, alignItems: 'center' },
  errorText: { flex: 1, fontSize: 13, lineHeight: 19 },
  retryText: { fontSize: 12, fontWeight: '700' },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 2 },
  sectionTitle: { fontSize: 20, fontWeight: '700' },
  sectionSubtitle: { fontSize: 12, marginTop: 3 },
  addButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, minHeight: 42, paddingHorizontal: 13, borderRadius: 14 },
  addButtonText: { fontSize: 12, fontWeight: '700' },
  walletList: { gap: 12 },
  backupReminder: { flexDirection: 'row', alignItems: 'center', gap: 9, paddingHorizontal: 13, paddingVertical: 12, borderRadius: 14 },
  backupReminderText: { flex: 1, fontSize: 12, fontWeight: '500' },
  walletCard: { borderWidth: 1, borderRadius: 21, overflow: 'hidden' },
  walletCardMain: { flexDirection: 'row', alignItems: 'center', padding: 15, gap: 11 },
  walletIcon: { width: 39, height: 39, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  walletNumber: { fontSize: 12, fontWeight: '700' },
  walletIdentity: { flex: 1, gap: 4 },
  walletName: { fontSize: 14, fontWeight: '700' },
  walletAddress: { fontSize: 11, fontFamily: 'monospace' },
  walletBalance: { alignItems: 'flex-end', gap: 2 },
  walletAmount: { fontSize: 15, fontWeight: '700' },
  walletUnit: { fontSize: 10, fontWeight: '600' },
  tokenPanel: { borderTopWidth: 1, paddingHorizontal: 16, paddingVertical: 12, gap: 9 },
  tokenHeading: { fontSize: 9, letterSpacing: 1.2, fontWeight: '700' },
  tokenRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  tokenDot: { width: 7, height: 7, borderRadius: 4 },
  tokenName: { flex: 1, fontSize: 12, fontWeight: '600' },
  tokenAmount: { fontSize: 12, fontWeight: '600' },
  noTokens: { fontSize: 12 },
  walletActions: { flexDirection: 'row', gap: 9, padding: 12, borderTopWidth: 1 },
  walletAction: { flex: 1, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 7, minHeight: 40, borderRadius: 13 },
  walletActionText: { fontSize: 12, fontWeight: '600' },
  emptyCard: { alignItems: 'center', borderWidth: 1, borderRadius: 22, padding: 23, gap: 12 },
  emptyIcon: { width: 52, height: 52, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  emptyTitle: { fontSize: 17, fontWeight: '700' },
  emptyText: { fontSize: 13, lineHeight: 20, textAlign: 'center' },
  primaryButton: { minHeight: 48, alignSelf: 'stretch', borderRadius: 15, alignItems: 'center', justifyContent: 'center', marginTop: 4 },
  primaryButtonText: { fontSize: 14, fontWeight: '700' },
  disclaimer: { fontSize: 11, lineHeight: 17, textAlign: 'center', paddingHorizontal: 7 },
});
