import { useState } from 'react';
import * as Clipboard from 'expo-clipboard';
import {
  ActivityIndicator,
  Platform,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useColors } from '@/hooks/useColors';
import { useWallets } from '@/src/context/wallet-context';

export default function SecurityScreen() {
  const colors = useColors();
  const {
    wallets,
    ready,
    error,
    isNativeDevice,
    getBackupJson,
    importWallet,
  } = useWallets();
  const [selectedAddress, setSelectedAddress] = useState<string | null>(null);
  const [backup, setBackup] = useState<string | null>(null);
  const [backupError, setBackupError] = useState<string | null>(null);
  const [showBackup, setShowBackup] = useState(false);
  const [importText, setImportText] = useState('');
  const [importError, setImportError] = useState<string | null>(null);
  const [importing, setImporting] = useState(false);
  const [copied, setCopied] = useState(false);

  const revealBackup = async (address: string) => {
    setSelectedAddress(address);
    setBackup(null);
    setBackupError(null);
    setShowBackup(false);
    try {
      setBackup(await getBackupJson(address));
    } catch (problem) {
      setBackupError(problem instanceof Error ? problem.message : 'Could not read this device backup.');
    }
  };

  const handleImport = async () => {
    setImporting(true);
    setImportError(null);
    try {
      await importWallet(importText);
      setImportText('');
    } catch (problem) {
      setImportError(problem instanceof Error ? problem.message : 'The wallet could not be imported.');
    } finally {
      setImporting(false);
    }
  };

  const copyBackup = async () => {
    if (!backup) return;
    await Clipboard.setStringAsync(backup);
    setCopied(true);
  };

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={[styles.content, Platform.OS === 'web' ? styles.webInsets : null]}>
        <Text style={[styles.kicker, { color: colors.mutedForeground }]}>DEVICE SECURITY</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>Keys & backups</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          Your private keys are stored in this device’s secure storage. They are not uploaded to a server.
        </Text>

        {!isNativeDevice ? (
          <View style={[styles.notice, { backgroundColor: colors.secondary }]}>
            <Feather name="smartphone" size={18} color={colors.primary} />
            <Text style={[styles.noticeText, { color: colors.foreground }]}>
              Create, import, and back up wallets from the iOS or Android app. Browser storage is not used for private keys.
            </Text>
          </View>
        ) : null}

        <View style={[styles.warningCard, { backgroundColor: colors.card, borderColor: colors.accent }]}>
          <Feather name="alert-triangle" size={18} color={colors.accent} />
          <View style={styles.warningCopy}>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>Back up before adding funds</Text>
            <Text style={[styles.cardBody, { color: colors.mutedForeground }]}>
              If this device is lost and you have no offline copy, the wallet cannot be recovered. Never share a private key or store it in a photo or cloud note.
            </Text>
          </View>
        </View>

        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Wallet backups</Text>
        {!ready ? (
          <View style={[styles.walletRow, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <ActivityIndicator color={colors.primary} />
            <Text style={[styles.cardBody, { color: colors.mutedForeground }]}>Loading wallets…</Text>
          </View>
        ) : wallets.length === 0 ? (
          <View style={[styles.emptyCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.cardBody, { color: colors.mutedForeground }]}>
              Wallets you create or import will appear here.
            </Text>
          </View>
        ) : wallets.map((wallet) => (
          <View key={wallet.address} style={[styles.walletRow, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={[styles.keyIcon, { backgroundColor: colors.secondary }]}>
              <Feather name="key" size={17} color={colors.primary} />
            </View>
            <View style={styles.walletInfo}>
              <Text style={[styles.walletName, { color: colors.foreground }]}>{wallet.name}</Text>
              <Text numberOfLines={1} style={[styles.walletAddress, { color: colors.mutedForeground }]}>{wallet.address}</Text>
            </View>
            <Pressable
              accessibilityRole="button"
              testID={`backup-${wallet.address}`}
              disabled={!isNativeDevice}
              onPress={() => void revealBackup(wallet.address)}
              style={[styles.smallButton, { backgroundColor: colors.secondary, opacity: isNativeDevice ? 1 : 0.5 }]}
            >
              <Text style={[styles.smallButtonText, { color: colors.foreground }]}>Backup</Text>
            </Pressable>
          </View>
        ))}
        {error ? <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text> : null}

        {selectedAddress ? (
          <View style={[styles.backupCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.backupHeader}>
              <Text style={[styles.cardTitle, { color: colors.foreground }]}>Private key backup</Text>
              <Pressable accessibilityRole="button" onPress={() => { setSelectedAddress(null); setBackup(null); setShowBackup(false); }}>
                <Feather name="x" size={19} color={colors.mutedForeground} />
              </Pressable>
            </View>
            {backupError ? (
              <Text style={[styles.errorText, { color: colors.destructive }]}>{backupError}</Text>
            ) : backup ? (
              <>
                <Text style={[styles.cardBody, { color: colors.mutedForeground }]}>
                  This is a Solana keypair JSON array. Anyone who gets it can control this wallet.
                </Text>
                {showBackup ? (
                  <Text selectable style={[styles.secretText, { color: colors.foreground, backgroundColor: colors.background, borderColor: colors.border }]}>
                    {backup}
                  </Text>
                ) : (
                  <View style={[styles.hiddenSecret, { backgroundColor: colors.background, borderColor: colors.border }]}>
                    <Feather name="eye-off" size={16} color={colors.mutedForeground} />
                    <Text style={[styles.cardBody, { color: colors.mutedForeground }]}>Hidden until you reveal it</Text>
                  </View>
                )}
                <Pressable
                  accessibilityRole="button"
                  testID="reveal-private-key"
                  onPress={() => { setShowBackup(true); setCopied(false); }}
                  style={[styles.secondaryButton, { borderColor: colors.border }]}
                >
                  <Text style={[styles.secondaryButtonText, { color: colors.foreground }]}>
                    {showBackup ? 'Backup visible' : 'Reveal backup'}
                  </Text>
                </Pressable>
                <Pressable
                  accessibilityRole="button"
                  testID="copy-private-key"
                  disabled={!showBackup}
                  onPress={() => void copyBackup()}
                  style={[styles.primaryButton, { backgroundColor: colors.primary, opacity: showBackup ? 1 : 0.5 }]}
                >
                  <Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>
                    {copied ? 'Copied — store it offline' : 'Copy recovery key'}
                  </Text>
                </Pressable>
              </>
            ) : (
              <ActivityIndicator color={colors.primary} />
            )}
          </View>
        ) : null}

        <View style={styles.importSection}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Restore a wallet</Text>
          <Text style={[styles.cardBody, { color: colors.mutedForeground }]}>
            Import a 64-byte Solana keypair JSON array or base58 private key. It will be saved only on this device.
          </Text>
          <TextInput
            accessibilityLabel="Private key backup"
            testID="import-private-key"
            multiline
            value={importText}
            onChangeText={setImportText}
            editable={isNativeDevice && !importing}
            autoCapitalize="none"
            autoCorrect={false}
            placeholder="[12, 34, …] or base58 key"
            placeholderTextColor={colors.mutedForeground}
            style={[styles.importInput, { backgroundColor: colors.card, borderColor: colors.border, color: colors.foreground }]}
          />
          {importError ? <Text style={[styles.errorText, { color: colors.destructive }]}>{importError}</Text> : null}
          <Pressable
            accessibilityRole="button"
            testID="import-wallet"
            disabled={!isNativeDevice || importing || !importText.trim()}
            onPress={() => void handleImport()}
            style={[styles.primaryButton, { backgroundColor: colors.primary, opacity: !isNativeDevice || importing || !importText.trim() ? 0.5 : 1 }]}
          >
            {importing ? (
              <ActivityIndicator color={colors.primaryForeground} />
            ) : (
              <Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>Import to this device</Text>
            )}
          </Pressable>
        </View>
        <Text style={[styles.footer, { color: colors.mutedForeground }]}>
          Keep backups offline and private. Never paste a key into chat, support requests, or an untrusted website.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1 },
  content: { paddingHorizontal: 20, paddingTop: 20, paddingBottom: 40, gap: 13 },
  webInsets: { paddingTop: 67, paddingBottom: 120 },
  kicker: { fontSize: 10, letterSpacing: 1.4, fontWeight: '700', marginTop: 5 },
  title: { fontSize: 30, fontWeight: '700' },
  subtitle: { fontSize: 14, lineHeight: 21, marginBottom: 5 },
  notice: { flexDirection: 'row', gap: 10, padding: 14, borderRadius: 16, alignItems: 'flex-start' },
  noticeText: { flex: 1, fontSize: 13, lineHeight: 19 },
  warningCard: { borderWidth: 1, borderRadius: 18, padding: 15, flexDirection: 'row', gap: 11 },
  warningCopy: { flex: 1, gap: 5 },
  cardTitle: { fontSize: 14, fontWeight: '700' },
  cardBody: { fontSize: 12, lineHeight: 18 },
  sectionTitle: { fontSize: 17, fontWeight: '700', marginTop: 6 },
  walletRow: { borderWidth: 1, borderRadius: 16, padding: 11, flexDirection: 'row', alignItems: 'center', gap: 10 },
  keyIcon: { width: 37, height: 37, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  walletInfo: { flex: 1, gap: 4 },
  walletName: { fontSize: 13, fontWeight: '700' },
  walletAddress: { fontSize: 10, fontFamily: 'monospace' },
  smallButton: { paddingHorizontal: 12, paddingVertical: 9, borderRadius: 12 },
  smallButtonText: { fontSize: 11, fontWeight: '700' },
  emptyCard: { padding: 17, borderWidth: 1, borderRadius: 16 },
  backupCard: { borderWidth: 1, borderRadius: 19, padding: 15, gap: 12 },
  backupHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  hiddenSecret: { minHeight: 46, borderWidth: 1, borderRadius: 13, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 8 },
  secretText: { borderWidth: 1, borderRadius: 13, padding: 11, fontSize: 11, lineHeight: 16, fontFamily: 'monospace' },
  secondaryButton: { minHeight: 45, borderWidth: 1, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  secondaryButtonText: { fontSize: 13, fontWeight: '600' },
  primaryButton: { minHeight: 49, borderRadius: 15, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 14 },
  primaryButtonText: { fontSize: 13, fontWeight: '700' },
  importSection: { gap: 10, marginTop: 3 },
  importInput: { minHeight: 90, textAlignVertical: 'top', borderWidth: 1, borderRadius: 14, padding: 12, fontSize: 12, lineHeight: 18 },
  errorText: { fontSize: 12, lineHeight: 18 },
  footer: { fontSize: 11, lineHeight: 17, textAlign: 'center', marginTop: 6 },
});
