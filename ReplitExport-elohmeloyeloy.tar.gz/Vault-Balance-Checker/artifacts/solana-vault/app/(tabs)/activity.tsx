import { useCallback, useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Linking,
  Platform,
  Pressable,
  RefreshControl,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useColors } from '@/hooks/useColors';
import { useWallets } from '@/src/context/wallet-context';
import { fetchRecentActivity, type WalletActivity } from '@/src/lib/solana';

function formatTime(blockTime: number | null) {
  if (!blockTime) return 'Time unavailable';
  return new Date(blockTime * 1000).toLocaleString(undefined, {
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  });
}

export default function ActivityScreen() {
  const colors = useColors();
  const { wallets, ready } = useWallets();
  const [items, setItems] = useState<WalletActivity[]>([]);
  const [loading, setLoading] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!wallets.length) {
      setItems([]);
      setLoaded(true);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      setItems(await fetchRecentActivity(wallets.map((wallet) => wallet.address)));
      setLoaded(true);
    } catch (problem) {
      setError(problem instanceof Error ? problem.message : 'Could not load transaction activity.');
    } finally {
      setLoading(false);
    }
  }, [wallets]);

  useEffect(() => {
    if (ready) void load();
  }, [ready, wallets.length, load]);

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={[styles.content, Platform.OS === 'web' ? styles.webInsets : null]}
        refreshControl={
          <RefreshControl refreshing={loading} onRefresh={() => void load()} tintColor={colors.primary} />
        }
      >
        <Text style={[styles.kicker, { color: colors.mutedForeground }]}>SOLANA MAINNET</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>Activity</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          Recent transactions across your device wallets.
        </Text>

        {!ready || (loading && !loaded) ? (
          <View style={[styles.stateCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <ActivityIndicator color={colors.primary} />
            <Text style={[styles.stateText, { color: colors.mutedForeground }]}>Checking the Solana network…</Text>
          </View>
        ) : error ? (
          <View style={[styles.stateCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Feather name="wifi-off" size={22} color={colors.destructive} />
            <Text style={[styles.stateText, { color: colors.foreground }]}>{error}</Text>
            <Pressable accessibilityRole="button" onPress={() => void load()} style={[styles.retryButton, { backgroundColor: colors.secondary }]}>
              <Text style={[styles.retryText, { color: colors.foreground }]}>Try again</Text>
            </Pressable>
          </View>
        ) : items.length === 0 ? (
          <View style={[styles.stateCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={[styles.emptyIcon, { backgroundColor: colors.secondary }]}>
              <Feather name="activity" size={21} color={colors.primary} />
            </View>
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
              {wallets.length ? 'No transactions yet' : 'Your activity will appear here'}
            </Text>
            <Text style={[styles.stateText, { color: colors.mutedForeground }]}>
              Once a wallet receives or sends a transaction, you can review it here.
            </Text>
          </View>
        ) : (
          <View style={styles.list}>
            {items.map((item) => {
              const wallet = wallets.find((entry) => entry.address === item.address);
              return (
                <Pressable
                  key={`${item.address}-${item.signature}`}
                  accessibilityRole="button"
                  onPress={() => void Linking.openURL(`https://solscan.io/tx/${item.signature}`)}
                  style={[styles.activityRow, { backgroundColor: colors.card, borderColor: colors.border }]}
                >
                  <View style={[styles.activityIcon, { backgroundColor: item.failed ? colors.destructive : colors.secondary }]}>
                    <Feather name={item.failed ? 'alert-circle' : 'arrow-up-right'} size={17} color={item.failed ? colors.destructiveForeground : colors.primary} />
                  </View>
                  <View style={styles.activityMain}>
                    <Text style={[styles.activityTitle, { color: colors.foreground }]}>
                      {item.failed ? 'Failed transaction' : 'Solana transaction'}
                    </Text>
                    <Text style={[styles.activityMeta, { color: colors.mutedForeground }]}>
                      {wallet?.name ?? 'Wallet'} · {formatTime(item.blockTime)}
                    </Text>
                    <Text numberOfLines={1} style={[styles.signature, { color: colors.mutedForeground }]}>
                      {item.signature}
                    </Text>
                  </View>
                  <Feather name="external-link" size={16} color={colors.mutedForeground} />
                </Pressable>
              );
            })}
          </View>
        )}
        <Text style={[styles.footnote, { color: colors.mutedForeground }]}>
          Transaction details open on Solscan, a third-party block explorer.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1 },
  content: { paddingHorizontal: 20, paddingTop: 20, paddingBottom: 38, gap: 12 },
  webInsets: { paddingTop: 67, paddingBottom: 120 },
  kicker: { fontSize: 10, letterSpacing: 1.4, fontWeight: '700', marginTop: 5 },
  title: { fontSize: 30, fontWeight: '700', marginTop: 2 },
  subtitle: { fontSize: 14, lineHeight: 20, marginBottom: 10 },
  stateCard: { minHeight: 170, borderWidth: 1, borderRadius: 22, alignItems: 'center', justifyContent: 'center', padding: 24, gap: 12 },
  stateText: { textAlign: 'center', fontSize: 13, lineHeight: 20 },
  emptyIcon: { width: 48, height: 48, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  emptyTitle: { fontSize: 16, fontWeight: '700' },
  retryButton: { paddingHorizontal: 17, paddingVertical: 11, borderRadius: 13 },
  retryText: { fontSize: 13, fontWeight: '700' },
  list: { gap: 10, marginTop: 5 },
  activityRow: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderRadius: 18, padding: 13, gap: 11 },
  activityIcon: { width: 39, height: 39, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  activityMain: { flex: 1, gap: 4 },
  activityTitle: { fontSize: 13, fontWeight: '700' },
  activityMeta: { fontSize: 11 },
  signature: { fontSize: 10, fontFamily: 'monospace' },
  footnote: { fontSize: 11, lineHeight: 17, textAlign: 'center', marginTop: 10 },
});
