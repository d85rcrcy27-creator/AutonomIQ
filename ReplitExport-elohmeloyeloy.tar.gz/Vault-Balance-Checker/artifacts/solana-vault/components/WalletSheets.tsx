import * as Clipboard from 'expo-clipboard';
import { useState } from 'react';
import {
  ActivityIndicator,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import QRCode from 'react-native-qrcode-svg';
import { PublicKey } from '@solana/web3.js';
import { useColors } from '@/hooks/useColors';
import { useWallets, type WalletMetadata } from '@/src/context/wallet-context';

interface SheetProps {
  wallet: WalletMetadata | null;
  onClose: () => void;
}

function SheetFrame({
  title,
  onClose,
  children,
}: {
  title: string;
  onClose: () => void;
  children: React.ReactNode;
}) {
  const colors = useColors();
  return (
    <Modal animationType="slide" transparent visible onRequestClose={onClose}>
      <View style={styles.backdrop}>
        <View style={[styles.sheet, { backgroundColor: colors.background }]}>
          <View style={[styles.handle, { backgroundColor: colors.border }]} />
          <View style={styles.sheetHeader}>
            <Text style={[styles.sheetTitle, { color: colors.foreground }]}>{title}</Text>
            <Pressable accessibilityRole="button" onPress={onClose} hitSlop={12}>
              <Text style={[styles.closeText, { color: colors.mutedForeground }]}>Close</Text>
            </Pressable>
          </View>
          {children}
        </View>
      </View>
    </Modal>
  );
}

export function ReceiveSheet({ wallet, onClose }: SheetProps) {
  const colors = useColors();
  const [copied, setCopied] = useState(false);
  if (!wallet) return null;
  const receiveUri = `solana:${wallet.address}`;

  const copyAddress = async () => {
    await Clipboard.setStringAsync(wallet.address);
    setCopied(true);
  };

  return (
    <SheetFrame title="Receive SOL or tokens" onClose={onClose}>
      <ScrollView contentContainerStyle={styles.sheetContent}>
        <Text style={[styles.sheetDescription, { color: colors.mutedForeground }]}>
          Send Solana assets to this address. Network fees are paid in SOL.
        </Text>
        <View style={[styles.qrFrame, { backgroundColor: '#ffffff' }]}>
          <QRCode value={receiveUri} size={190} color="#10231b" backgroundColor="#ffffff" />
        </View>
        <Text style={[styles.addressLabel, { color: colors.mutedForeground }]}>PUBLIC ADDRESS</Text>
        <Text selectable style={[styles.fullAddress, { color: colors.foreground }]}>
          {wallet.address}
        </Text>
        <Pressable
          accessibilityRole="button"
          testID="copy-receive-address"
          onPress={() => void copyAddress()}
          style={[styles.primaryButton, { backgroundColor: colors.primary }]}
        >
          <Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>
            {copied ? 'Address copied' : 'Copy address'}
          </Text>
        </Pressable>
        {Platform.OS === 'web' ? (
          <Text style={[styles.sheetFootnote, { color: colors.mutedForeground }]}>
            Scan this code from a Solana wallet app.
          </Text>
        ) : null}
      </ScrollView>
    </SheetFrame>
  );
}

export function SendSheet({ wallet, onClose }: SheetProps) {
  const colors = useColors();
  const { sendSol, refreshBalances } = useWallets();
  const [recipient, setRecipient] = useState('');
  const [amount, setAmount] = useState('');
  const [review, setReview] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [signature, setSignature] = useState<string | null>(null);

  if (!wallet) return null;
  const amountNumber = Number(amount);

  const reviewTransfer = () => {
    setError(null);
    try {
      const destination = new PublicKey(recipient.trim());
      if (destination.toBase58() === wallet.address) {
        throw new Error('The recipient address is the same as this wallet.');
      }
      if (!Number.isFinite(amountNumber) || amountNumber <= 0) {
        throw new Error('Enter an amount greater than zero.');
      }
      setReview(true);
    } catch (problem) {
      setError(problem instanceof Error ? problem.message : 'Enter a valid Solana recipient address.');
    }
  };

  const confirmTransfer = async () => {
    setSending(true);
    setError(null);
    try {
      const sentSignature = await sendSol(wallet.address, recipient.trim(), amountNumber);
      setSignature(sentSignature);
      void refreshBalances().catch(() => undefined);
    } catch (problem) {
      setError(problem instanceof Error ? problem.message : 'The transfer could not be sent.');
    } finally {
      setSending(false);
    }
  };

  return (
    <SheetFrame
      title={signature ? 'Transfer submitted' : review ? 'Review transfer' : 'Send SOL'}
      onClose={onClose}
    >
      {signature ? (
        <View style={styles.sheetContent}>
          <View style={[styles.successMark, { backgroundColor: colors.secondary }]}>
            <Text style={[styles.successCheck, { color: colors.primary }]}>✓</Text>
          </View>
          <Text style={[styles.sheetDescription, { color: colors.foreground }]}>
            {amountNumber} SOL sent from {wallet.name}. The transaction was confirmed on Solana mainnet.
          </Text>
          <Text style={[styles.addressLabel, { color: colors.mutedForeground }]}>TRANSACTION SIGNATURE</Text>
          <Text selectable style={[styles.fullAddress, { color: colors.foreground }]}>{signature}</Text>
          <Pressable
            accessibilityRole="button"
            onPress={() => void Clipboard.setStringAsync(signature)}
            style={[styles.secondaryButton, { borderColor: colors.border }]}
          >
            <Text style={[styles.secondaryButtonText, { color: colors.foreground }]}>Copy signature</Text>
          </Pressable>
        </View>
      ) : review ? (
        <View style={styles.sheetContent}>
          <Text style={[styles.sheetDescription, { color: colors.mutedForeground }]}>
            This transfer will be signed with the key stored on this device and submitted to Solana mainnet.
            Transfers cannot be reversed.
          </Text>
          <View style={[styles.reviewCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.reviewAmount, { color: colors.foreground }]}>{amountNumber} SOL</Text>
            <Text style={[styles.addressLabel, { color: colors.mutedForeground }]}>TO</Text>
            <Text selectable style={[styles.fullAddress, { color: colors.foreground }]}>{recipient.trim()}</Text>
            <Text style={[styles.sheetFootnote, { color: colors.mutedForeground }]}>
              A network fee is also paid in SOL. The exact fee is set by the network when submitted.
            </Text>
          </View>
          {error ? <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text> : null}
          <Pressable
            accessibilityRole="button"
            testID="confirm-sol-transfer"
            disabled={sending}
            onPress={() => void confirmTransfer()}
            style={[styles.primaryButton, { backgroundColor: colors.primary, opacity: sending ? 0.65 : 1 }]}
          >
            {sending ? (
              <ActivityIndicator color={colors.primaryForeground} />
            ) : (
              <Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>
                Confirm and send
              </Text>
            )}
          </Pressable>
          <Pressable accessibilityRole="button" onPress={() => setReview(false)} style={styles.textButton}>
            <Text style={[styles.secondaryButtonText, { color: colors.mutedForeground }]}>Edit details</Text>
          </Pressable>
        </View>
      ) : (
        <View style={styles.sheetContent}>
          <Text style={[styles.sheetDescription, { color: colors.mutedForeground }]}>
            Send from {wallet.name}. Only SOL transfers are supported; SPL tokens can be viewed and received.
          </Text>
          <Text style={[styles.addressLabel, { color: colors.mutedForeground }]}>RECIPIENT ADDRESS</Text>
          <TextInput
            accessibilityLabel="Recipient Solana address"
            testID="send-recipient"
            autoCapitalize="none"
            autoCorrect={false}
            value={recipient}
            onChangeText={setRecipient}
            placeholder="Paste a Solana address"
            placeholderTextColor={colors.mutedForeground}
            style={[styles.input, { backgroundColor: colors.card, borderColor: colors.border, color: colors.foreground }]}
          />
          <Text style={[styles.addressLabel, { color: colors.mutedForeground }]}>AMOUNT IN SOL</Text>
          <TextInput
            accessibilityLabel="Amount in SOL"
            testID="send-amount"
            value={amount}
            onChangeText={setAmount}
            keyboardType="decimal-pad"
            placeholder="0.00"
            placeholderTextColor={colors.mutedForeground}
            style={[styles.input, { backgroundColor: colors.card, borderColor: colors.border, color: colors.foreground }]}
          />
          {error ? <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text> : null}
          <Pressable
            accessibilityRole="button"
            testID="review-sol-transfer"
            onPress={reviewTransfer}
            style={[styles.primaryButton, { backgroundColor: colors.primary }]}
          >
            <Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>Review transfer</Text>
          </Pressable>
        </View>
      )}
    </SheetFrame>
  );
}

const styles = StyleSheet.create({
  backdrop: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(0,0,0,0.52)',
  },
  sheet: {
    maxHeight: '92%',
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    paddingHorizontal: 22,
    paddingTop: 12,
    paddingBottom: 32,
  },
  handle: {
    width: 42,
    height: 5,
    borderRadius: 4,
    alignSelf: 'center',
    marginBottom: 18,
  },
  sheetHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  sheetTitle: { fontSize: 22, fontWeight: '700' },
  closeText: { fontSize: 14, fontWeight: '600' },
  sheetContent: { gap: 14, paddingBottom: 8 },
  sheetDescription: { fontSize: 14, lineHeight: 21 },
  qrFrame: {
    alignSelf: 'center',
    padding: 18,
    borderRadius: 20,
    marginVertical: 4,
  },
  addressLabel: { fontSize: 10, fontWeight: '700', letterSpacing: 1.3 },
  fullAddress: { fontSize: 13, lineHeight: 20, fontFamily: 'monospace' },
  primaryButton: {
    minHeight: 52,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 18,
    marginTop: 4,
  },
  primaryButtonText: { fontSize: 15, fontWeight: '700' },
  secondaryButton: {
    minHeight: 48,
    borderWidth: 1,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 16,
  },
  secondaryButtonText: { fontSize: 14, fontWeight: '600' },
  sheetFootnote: { fontSize: 12, lineHeight: 18 },
  reviewCard: {
    borderWidth: 1,
    borderRadius: 18,
    padding: 16,
    gap: 10,
  },
  reviewAmount: { fontSize: 27, fontWeight: '700' },
  errorText: { fontSize: 13, lineHeight: 18, fontWeight: '500' },
  input: {
    minHeight: 50,
    borderWidth: 1,
    borderRadius: 14,
    paddingHorizontal: 14,
    fontSize: 14,
  },
  textButton: { alignItems: 'center', padding: 10 },
  successMark: {
    width: 54,
    height: 54,
    borderRadius: 27,
    alignItems: 'center',
    justifyContent: 'center',
  },
  successCheck: { fontSize: 28, fontWeight: '700' },
});
