/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    text: '#10231b',
    tint: '#197a56',
    background: '#f3f7f4',
    foreground: '#10231b',
    card: '#ffffff',
    cardForeground: '#10231b',
    primary: '#187a55',
    primaryForeground: '#ffffff',
    secondary: '#e4eee8',
    secondaryForeground: '#18392a',
    muted: '#e9f0eb',
    mutedForeground: '#60746a',
    accent: '#c69a53',
    accentForeground: '#17251d',
    destructive: '#c33f4b',
    destructiveForeground: '#ffffff',
    border: '#d9e4dc',
    input: '#d9e4dc',
  },
  dark: {
    text: '#e6f3eb',
    tint: '#83e5b3',
    background: '#0c1410',
    foreground: '#e6f3eb',
    card: '#15211a',
    cardForeground: '#e6f3eb',
    primary: '#83e5b3',
    primaryForeground: '#0c2116',
    secondary: '#1d2c23',
    secondaryForeground: '#e0efe5',
    muted: '#1b2921',
    mutedForeground: '#94a79b',
    accent: '#dbb66f',
    accentForeground: '#1b211b',
    destructive: '#f27880',
    destructiveForeground: '#241014',
    border: '#2a3a30',
    input: '#2a3a30',
  },
  radius: 18,
};

export default colors;
