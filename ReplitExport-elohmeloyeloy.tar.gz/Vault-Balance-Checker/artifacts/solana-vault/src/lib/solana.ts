import {
  Connection,
  Keypair,
  LAMPORTS_PER_SOL,
  PublicKey,
  SystemProgram,
  Transaction,
} from '@solana/web3.js';

export const SOLANA_RPC_URL = 'https://api.mainnet-beta.solana.com';

const TOKEN_PROGRAMS = [
  new PublicKey('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA'),
  new PublicKey('TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb'),
];

const TOKEN_NAMES: Record<string, string> = {
  EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v: 'USDC',
  Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB: 'USDT',
};

export interface TokenHolding {
  mint: string;
  name: string;
  amount: string;
  decimals: number;
}

export interface WalletBalance {
  lamports: number;
  tokens: TokenHolding[];
  checkedAt: string;
}

export interface WalletActivity {
  address: string;
  signature: string;
  blockTime: number | null;
  status: string;
  failed: boolean;
}

function connection() {
  return new Connection(SOLANA_RPC_URL, 'confirmed');
}

export async function fetchWalletBalance(address: string): Promise<WalletBalance> {
  const owner = new PublicKey(address);
  const rpc = connection();
  const [lamports, ...tokenResponses] = await Promise.all([
    rpc.getBalance(owner, 'confirmed'),
    ...TOKEN_PROGRAMS.map((programId) =>
      rpc.getParsedTokenAccountsByOwner(owner, { programId }, 'confirmed'),
    ),
  ]);

  const totals = new Map<string, { amount: number; decimals: number }>();
  for (const response of tokenResponses) {
    for (const entry of response.value) {
      const info = entry.account.data.parsed.info as {
        mint: string;
        tokenAmount: { uiAmountString?: string; decimals: number };
      };
      const previous = totals.get(info.mint);
      totals.set(info.mint, {
        amount:
          (previous?.amount ?? 0) +
          Number(info.tokenAmount.uiAmountString ?? '0'),
        decimals: info.tokenAmount.decimals,
      });
    }
  }

  const tokens = [...totals.entries()]
    .filter(([, holding]) => holding.amount > 0)
    .map(([mint, holding]) => ({
      mint,
      name: TOKEN_NAMES[mint] ?? `Token ${mint.slice(0, 4)}`,
      amount: holding.amount.toLocaleString(undefined, {
        maximumFractionDigits: holding.decimals,
      }),
      decimals: holding.decimals,
    }))
    .sort((a, b) => a.name.localeCompare(b.name));

  return { lamports, tokens, checkedAt: new Date().toISOString() };
}

export async function fetchRecentActivity(
  addresses: string[],
): Promise<WalletActivity[]> {
  const rpc = connection();
  const results = await Promise.all(
    addresses.map(async (address) => {
      const signatures = await rpc.getSignaturesForAddress(
        new PublicKey(address),
        { limit: 12 },
        'confirmed',
      );
      return signatures.map((item) => ({
        address,
        signature: item.signature,
        blockTime: item.blockTime ?? null,
        status: item.err
          ? 'Failed'
          : item.confirmationStatus ?? 'Confirmed',
        failed: Boolean(item.err),
      }));
    }),
  );

  return results
    .flat()
    .sort((a, b) => (b.blockTime ?? 0) - (a.blockTime ?? 0));
}

export async function transferSol(
  secretKey: Uint8Array,
  recipientAddress: string,
  amountSol: number,
): Promise<string> {
  if (!Number.isFinite(amountSol) || amountSol <= 0) {
    throw new Error('Enter an amount greater than zero.');
  }

  const recipient = new PublicKey(recipientAddress);
  const sender = Keypair.fromSecretKey(secretKey);
  const lamports = Math.floor(amountSol * LAMPORTS_PER_SOL);
  if (lamports < 1) {
    throw new Error('The amount is smaller than one lamport.');
  }

  const rpc = connection();
  const latest = await rpc.getLatestBlockhash('confirmed');
  const transaction = new Transaction({
    feePayer: sender.publicKey,
    recentBlockhash: latest.blockhash,
  }).add(
    SystemProgram.transfer({
      fromPubkey: sender.publicKey,
      toPubkey: recipient,
      lamports,
    }),
  );

  const feeResponse = await rpc.getFeeForMessage(
    transaction.compileMessage(),
    'confirmed',
  );
  const fee = feeResponse.value ?? 5_000;
  const available = await rpc.getBalance(sender.publicKey, 'confirmed');
  if (available < lamports + fee) {
    throw new Error('This wallet does not have enough SOL to cover the amount and network fee.');
  }

  const signature = await rpc.sendTransaction(transaction, [sender], {
    preflightCommitment: 'confirmed',
  });
  const confirmation = await rpc.confirmTransaction(
    {
      signature,
      blockhash: latest.blockhash,
      lastValidBlockHeight: latest.lastValidBlockHeight,
    },
    'confirmed',
  );
  if (confirmation.value.err) {
    throw new Error('The Solana network reported that this transfer failed.');
  }
  return signature;
}

export function solFromLamports(lamports: number): string {
  return (lamports / LAMPORTS_PER_SOL).toLocaleString(undefined, {
    minimumFractionDigits: 0,
    maximumFractionDigits: 6,
  });
}
