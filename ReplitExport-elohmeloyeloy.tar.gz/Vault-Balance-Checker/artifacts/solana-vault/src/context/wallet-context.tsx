import AsyncStorage from '@react-native-async-storage/async-storage';
import bs58 from 'bs58';
import * as Crypto from 'expo-crypto';
import * as SecureStore from 'expo-secure-store';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import { Platform } from 'react-native';
import { Keypair } from '@solana/web3.js';
import {
  fetchWalletBalance,
  transferSol as submitSolTransfer,
  type WalletBalance,
} from '@/src/lib/solana';

export interface WalletMetadata {
  address: string;
  name: string;
  createdAt: string;
}

interface WalletContextValue {
  wallets: WalletMetadata[];
  balances: Record<string, WalletBalance>;
  ready: boolean;
  creating: boolean;
  refreshing: boolean;
  error: string | null;
  balanceError: string | null;
  isNativeDevice: boolean;
  createWallet: () => Promise<WalletMetadata>;
  importWallet: (input: string) => Promise<WalletMetadata>;
  getBackupJson: (address: string) => Promise<string>;
  refreshBalances: () => Promise<void>;
  sendSol: (
    address: string,
    recipient: string,
    amount: number,
  ) => Promise<string>;
}

const WalletContext = createContext<WalletContextValue | null>(null);
const WALLET_INDEX_KEY = 'solana-vault-wallet-index-v1';
const SECRET_KEY_PREFIX = 'solana-vault-secret-v1-';

function messageFromError(error: unknown): string {
  return error instanceof Error ? error.message : 'Something went wrong. Please try again.';
}

function validateSecretKey(value: unknown): Uint8Array | null {
  if (
    !Array.isArray(value) ||
    value.length !== 64 ||
    !value.every(
      (entry) =>
        typeof entry === 'number' &&
        Number.isInteger(entry) &&
        entry >= 0 &&
        entry <= 255,
    )
  ) {
    return null;
  }
  return Uint8Array.from(value);
}

function parseSecretKey(input: string): Uint8Array {
  const trimmed = input.trim();
  if (!trimmed) {
    throw new Error('Paste a Solana keypair JSON array or base58 secret key.');
  }

  try {
    const parsed: unknown = JSON.parse(trimmed);
    const key = validateSecretKey(parsed);
    if (key) return key;
    if (Array.isArray(parsed)) {
      throw new Error('The keypair JSON must contain exactly 64 byte values.');
    }
  } catch (error) {
    if (error instanceof Error && error.message.includes('64 byte values')) {
      throw error;
    }
  }

  try {
    const decoded = bs58.decode(trimmed);
    if (decoded.length !== 64) {
      throw new Error('The base58 key must decode to 64 bytes.');
    }
    return decoded;
  } catch (error) {
    if (error instanceof Error && error.message.includes('64 bytes')) {
      throw error;
    }
    throw new Error('That key could not be read. Use a Solana 64-byte keypair JSON array or base58 secret key.');
  }
}

export function WalletProvider({ children }: { children: React.ReactNode }) {
  const [wallets, setWallets] = useState<WalletMetadata[]>([]);
  const [balances, setBalances] = useState<Record<string, WalletBalance>>({});
  const [ready, setReady] = useState(false);
  const [creating, setCreating] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [balanceError, setBalanceError] = useState<string | null>(null);
  const isNativeDevice = Platform.OS !== 'web';

  useEffect(() => {
    let active = true;
    void (async () => {
      try {
        const saved = await AsyncStorage.getItem(WALLET_INDEX_KEY);
        const parsed: WalletMetadata[] = saved ? JSON.parse(saved) : [];
        if (!Array.isArray(parsed)) {
          throw new Error('The saved wallet list could not be read.');
        }
        if (active) {
          setWallets(parsed);
          setReady(true);
        }
        if (active && Platform.OS !== 'web' && parsed.length > 0) {
          try {
            const entries = await Promise.all(
              parsed.map(async (wallet) => [
                wallet.address,
                await fetchWalletBalance(wallet.address),
              ] as const),
            );
            if (active) setBalances(Object.fromEntries(entries));
          } catch (balanceProblem) {
            if (active) setBalanceError(messageFromError(balanceProblem));
          }
        }
      } catch (loadProblem) {
        if (active) {
          setError(messageFromError(loadProblem));
          setReady(true);
        }
      }
    })();
    return () => {
      active = false;
    };
  }, []);

  const persistWallet = useCallback(
    async (secretKey: Uint8Array, keypair: Keypair): Promise<WalletMetadata> => {
      const address = keypair.publicKey.toBase58();
      const existing = wallets.some((wallet) => wallet.address === address);
      if (existing) throw new Error('This wallet is already on this device.');

      const metadata: WalletMetadata = {
        address,
        name: `Wallet ${wallets.length + 1}`,
        createdAt: new Date().toISOString(),
      };
      await SecureStore.setItemAsync(
        `${SECRET_KEY_PREFIX}${address}`,
        JSON.stringify(Array.from(secretKey)),
      );
      const updated = [...wallets, metadata];
      try {
        await AsyncStorage.setItem(WALLET_INDEX_KEY, JSON.stringify(updated));
      } catch (saveProblem) {
        await SecureStore.deleteItemAsync(`${SECRET_KEY_PREFIX}${address}`);
        throw saveProblem;
      }
      setWallets(updated);
      setBalances((current) => ({
        ...current,
        [address]: { lamports: 0, tokens: [], checkedAt: new Date().toISOString() },
      }));
      setError(null);
      return metadata;
    },
    [wallets],
  );

  const createWallet = useCallback(async () => {
    if (!isNativeDevice) {
      throw new Error('For your safety, create wallets in the iOS or Android app, not in a browser preview.');
    }
    setCreating(true);
    setError(null);
    try {
      const seed = await Crypto.getRandomBytesAsync(32);
      const pair = Keypair.fromSeed(seed);
      return await persistWallet(pair.secretKey, pair);
    } catch (createProblem) {
      const problem = messageFromError(createProblem);
      setError(problem);
      throw new Error(problem);
    } finally {
      setCreating(false);
    }
  }, [isNativeDevice, persistWallet]);

  const importWallet = useCallback(
    async (input: string) => {
      if (!isNativeDevice) {
        throw new Error('Import wallets in the iOS or Android app so the key can be stored securely.');
      }
      const secretKey = parseSecretKey(input);
      let pair: Keypair;
      try {
        pair = Keypair.fromSecretKey(secretKey);
      } catch {
        throw new Error('The keypair is invalid. Check the backup and try again.');
      }
      setError(null);
      return persistWallet(pair.secretKey, pair);
    },
    [isNativeDevice, persistWallet],
  );

  const getBackupJson = useCallback(async (address: string) => {
    if (!isNativeDevice) {
      throw new Error('Wallet backups are only available inside the iOS or Android app.');
    }
    const stored = await SecureStore.getItemAsync(`${SECRET_KEY_PREFIX}${address}`);
    if (!stored) throw new Error('The private key was not found in this device’s secure storage.');
    return JSON.stringify(JSON.parse(stored));
  }, [isNativeDevice]);

  const refreshBalances = useCallback(async () => {
    if (!isNativeDevice) {
      throw new Error('Live wallet access is available in the iOS or Android app.');
    }
    if (!wallets.length) return;
    setRefreshing(true);
    setBalanceError(null);
    try {
      const entries = await Promise.all(
        wallets.map(async (wallet) => [
          wallet.address,
          await fetchWalletBalance(wallet.address),
        ] as const),
      );
      setBalances(Object.fromEntries(entries));
    } catch (refreshProblem) {
      const problem = messageFromError(refreshProblem);
      setBalanceError(problem);
      throw new Error(problem);
    } finally {
      setRefreshing(false);
    }
  }, [isNativeDevice, wallets]);

  const sendSol = useCallback(
    async (address: string, recipient: string, amount: number) => {
      if (!isNativeDevice) {
        throw new Error('Transfers are only available in the iOS or Android app.');
      }
      const stored = await SecureStore.getItemAsync(`${SECRET_KEY_PREFIX}${address}`);
      if (!stored) throw new Error('This wallet’s key is not available on this device.');
      return submitSolTransfer(
        Uint8Array.from(JSON.parse(stored) as number[]),
        recipient,
        amount,
      );
    },
    [isNativeDevice],
  );

  const value = useMemo(
    () => ({
      wallets,
      balances,
      ready,
      creating,
      refreshing,
      error,
      balanceError,
      isNativeDevice,
      createWallet,
      importWallet,
      getBackupJson,
      refreshBalances,
      sendSol,
    }),
    [
      wallets,
      balances,
      ready,
      creating,
      refreshing,
      error,
      balanceError,
      isNativeDevice,
      createWallet,
      importWallet,
      getBackupJson,
      refreshBalances,
      sendSol,
    ],
  );

  return <WalletContext.Provider value={value}>{children}</WalletContext.Provider>;
}

export function useWallets() {
  const value = useContext(WalletContext);
  if (!value) throw new Error('useWallets must be used inside WalletProvider.');
  return value;
}
